package me.iradius.server.dao.helpdesk;

import java.util.Date;

import me.iradius.server.ctxt.AppContext;
import me.iradius.server.engine.QueryEngine;
import me.iradius.server.scheduler.Notification;
import me.iradius.shared.SharedConst;
import me.iradius.shared.db.Table;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;

public class HelpDeskDao {
	
	class TicketDef {
		
		Integer	id;
		String	subject;
		String	description;
		Integer	dealerId;
		Integer	employeeId;
		Integer	ticketStatusId;
		Boolean	notifyEmpBySMS		= Boolean.valueOf(false);
		Boolean	notifyEmpByMail		= Boolean.valueOf(true);
		Boolean	notifyDealerByMail	= Boolean.valueOf(true);
		Boolean	notifyDealerBySMS	= Boolean.valueOf(false);
	}
	
	class UserNotification {
		
		String	mobile;
		String	mailAddress;
	}
	
	private UserNotification getUserNotification(Integer userId) throws Exception {
		String sql = "SELECT  Mobile,  MailAddress FROM User WHERE Id  =" + userId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			UserNotification userNotification = new UserNotification();
			userNotification.mailAddress = record.getStringValue("MailAddress");
			userNotification.mobile = record.getStringValue("Mobile");
			return userNotification;
		}
		return null;
	}
	
	private void updateTicketStatus(Integer ticketId, Integer ticketStatusId) throws Exception {
		Table table = new Table("Ticket", "Id", Boolean.valueOf(false));
		table.setPkFieldValue(ticketId);
		table.addFieldValue("TicketStatusId", ticketStatusId);
		if (SharedConst.TICKET_CLOSED.equals(ticketStatusId)) {
			table.addFieldValue("ClosedDate", new Date());
		}
		(new QueryEngine()).updateData(table);
	}
	
	private void traceTicketLog(Integer ticketId, Integer userId, String description, Integer ticketStatusId) throws Exception {
		Table table = new Table("TicketLog", "Id", Boolean.valueOf(true));
		table.addFieldValue("TicketId", ticketId);
		table.addFieldValue("Description", description);
		table.addFieldValue("UpdateById", userId);
		if (ticketStatusId != null)
			table.addFieldValue("TicketStatusId", ticketStatusId);
		table.addFieldValue("CreatedDate", new Date());
		(new QueryEngine()).updateData(table);
	}
	
	private void updateTicketLog(Integer ticketLogId, String description) throws Exception {
		Table table = new Table("TicketLog", "Id", Boolean.valueOf(false));
		table.setPkFieldValue(ticketLogId);
		table.addFieldValue("Description", description);
		table.addFieldValue("UpdatedDate", new Date());
		(new QueryEngine()).updateData(table);
	}
	
	private TicketDef getTicketDef(Integer ticketId) throws Exception {
		String sql = "SELECT Ticket.Id, Ticket.Subject, Ticket.Description, TicketStatusId, AssignedToId, User.ParentId  FROM Ticket  Left Outer Join User On User.Id = Ticket.AssignedToId  WHERE Ticket.Id = " + ticketId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			TicketDef ticketDef = new TicketDef();
			ticketDef.id = ticketId;
			ticketDef.subject = record.getStringValue("Subject");
			ticketDef.description = record.getStringValue("Description");
			ticketDef.ticketStatusId = record.getIntegerValue("TicketStatusId");
			ticketDef.employeeId = record.getIntegerValue("AssignedToId");
			ticketDef.dealerId = record.getIntegerValue("ParentId");
			return ticketDef;
		}
		return null;
	}
	
	private void notifyIfSupport(TicketDef ticketDef, String mailSubject, String mailBody, String smsText) throws Exception {
		try {
			Notification notification = (Notification) AppContext.getBean("notification");
			if (ticketDef.notifyEmpByMail.booleanValue() || ticketDef.notifyEmpBySMS.booleanValue()) {
				Integer empId = ticketDef.employeeId;
				UserNotification userNotification = getUserNotification(empId);
				if (userNotification != null) {
					if (ticketDef.notifyEmpByMail.booleanValue()) {
						notification.sendMail(null, userNotification.mailAddress, mailSubject, mailBody);
					}
					ticketDef.notifyEmpBySMS.booleanValue();
				}
			}
			if (ticketDef.notifyDealerByMail.booleanValue() || ticketDef.notifyDealerBySMS.booleanValue()) {
				Integer dealerId = ticketDef.dealerId;
				UserNotification userNotification = getUserNotification(dealerId);
				if (userNotification != null) {
					if (ticketDef.notifyDealerByMail.booleanValue()) {
						notification.sendMail(null, userNotification.mailAddress, mailSubject, mailBody);
					}
					ticketDef.notifyDealerBySMS.booleanValue();
				}
			}
		} catch (Exception e) {
			System.out.println("Notification Problem : " + e.getMessage());
		}
	}
	
	private void notifyIfSupport(Integer ticketId, Integer ticketStatusId) throws Exception {
		TicketDef ticketDef = getTicketDef(ticketId);
		if (ticketDef != null) {
			String mailSubject = ticketDef.subject;
			String mailBody = ticketDef.description;
			String smsText = "Please Check Your Tickets";
			notifyIfSupport(ticketDef, mailSubject, mailBody, smsText);
		}
	}
	
	private void notifyIfSupportForTicketLog(TicketDef ticketDef, Integer ticketId, boolean Boolean) throws Exception {
		if (ticketDef == null) {
			ticketDef = getTicketDef(ticketId);
			if (ticketDef != null) {
				String mailSubject = "Ticket Log Changed For Ticket : " + ticketDef.subject;
				String mailBody = ticketDef.description;
				String smsText = "Ticket Log Changed, Please Check Your Tickets";
				notifyIfSupport(ticketDef, mailSubject, mailBody, smsText);
			}
		}
	}
	
	public void closeTicket(Integer userId, Integer ticketId, Integer currentTicketStatusId, String description) throws Exception {
		if (currentTicketStatusId == null || !SharedConst.TICKET_CLOSED.equals(currentTicketStatusId)) {
			updateTicketStatus(ticketId, SharedConst.TICKET_CLOSED);
			traceTicketLog(ticketId, userId, description, SharedConst.TICKET_CLOSED);
			notifyIfSupport(ticketId, SharedConst.TICKET_CLOSED);
		}
	}
	
	public void suspendTicket(Integer userId, Integer ticketId, Integer currentTicketStatusId, String description) throws Exception {
		if (currentTicketStatusId == null || !SharedConst.TICKET_SUSPENDED.equals(currentTicketStatusId)) {
			updateTicketStatus(ticketId, SharedConst.TICKET_SUSPENDED);
			traceTicketLog(ticketId, userId, description, SharedConst.TICKET_SUSPENDED);
			notifyIfSupport(ticketId, SharedConst.TICKET_SUSPENDED);
		}
	}
	
	public void inProgressTicket(Integer userId, Integer ticketId, Integer currentTicketStatusId, String description) throws Exception {
		if (currentTicketStatusId == null || !SharedConst.TICKET_INPROGRESS.equals(currentTicketStatusId)) {
			updateTicketStatus(ticketId, SharedConst.TICKET_INPROGRESS);
			traceTicketLog(ticketId, userId, description, SharedConst.TICKET_INPROGRESS);
			notifyIfSupport(ticketId, SharedConst.TICKET_INPROGRESS);
		}
	}
	
	public void traceTicketLog(Integer userId, Integer ticketId, Integer ticketLogId, String description, Integer assignedTo, Boolean inProgress, Boolean suspend, Boolean close) throws Exception {
		if (assignedTo != null) {
			Table table = new Table("Ticket", "Id", Boolean.valueOf(false));
			table.setPkFieldValue(ticketId);
			table.addFieldValue("AssignedToId", assignedTo);
			(new QueryEngine()).updateData(table);
			if (!inProgress.booleanValue() && !suspend.booleanValue() && !close.booleanValue()) {
				traceTicketLog(ticketId, userId, description, null);
				notifyIfSupport(ticketId, SharedConst.TICKET_INPROGRESS);
			}
		}
		if (inProgress.booleanValue()) {
			inProgressTicket(userId, ticketId, null, description);
			return;
		}
		if (suspend.booleanValue()) {
			suspendTicket(userId, ticketId, null, description);
			return;
		}
		if (close.booleanValue()) {
			closeTicket(userId, ticketId, null, description);
			return;
		}
		if (assignedTo != null) {
			return;
		}
		TicketDef ticketDef = null;
		if (ticketLogId != null) {
			updateTicketLog(ticketLogId, description);
		} else {
			ticketDef = getTicketDef(ticketId);
			traceTicketLog(ticketId, userId, description, ticketDef.ticketStatusId);
		}
		notifyIfSupportForTicketLog(ticketDef, ticketId, (ticketLogId == null));
	}
	
	public RecordSet getRadiusInfos(Integer userId, String searchText) throws Exception {
		String sql = "Select UserName, FirstName, LastName, Mobile, Address  From User  Where (ParentId = " + //
				userId + ") " + //
				" AND( (User.UserName like \"%" + searchText + "%\" " + //
				" OR User.FirstName like \"%" + searchText + "%\" " + //
				" OR User.LastName like \"%" + searchText + "%\" " + //
				" OR concat(User.FirstName, \" \" , User.lastName) like \"%" + searchText + "%\" ))" + //
				" limit 0 , 100";
		return (new QueryEngine()).executeSql(sql);
	}
	
	public RecordSet getUserGroups(String searchText, String sqlAddFilter) throws Exception {
		String sql = "Select Id, Name From UserGroup  Where  " + sqlAddFilter + //
				" AND( Name like \"%" + searchText + "%\" ) "; //
		return (new QueryEngine()).executeSql(sql);
	}
}
