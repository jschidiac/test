package me.iradius.server.dao.invoice;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.invoice.PosInf;
import me.iradius.shared.invoice.payment.CashPayment;
import me.iradius.shared.invoice.payment.CashPaymentCurrencyPart;
import me.iradius.shared.invoice.payment.CheckPayment;
import me.iradius.shared.invoice.payment.IPaymentType;
import me.iradius.shared.invoice.payment.InvoicePaymentType;
import me.iradius.shared.invoice.payment.PosOpenCloseShiftInf;
import me.iradius.shared.invoice.payment.VisaPayment;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.Session;

public class ShiftTransactionResumeManagement {
  protected Session session;
  protected Integer collectorId;
  private String startFilterDate;
  private String endFilterDate;
  private PosInf posInf;
  
  class Info {
    Integer id;
    HashMap<Integer, Double> amounts = new HashMap<>();


    
    String user;

    
    String note;
  }

  
  private ArrayList<IPaymentType> invoicesCashPayments = new ArrayList<>();
  private ArrayList<IPaymentType> invoicesRefundCashPayments = new ArrayList<>();
  private ArrayList<IPaymentType> openPosCashPayments = new ArrayList<>();
  private ArrayList<IPaymentType> InPosCashPayments = new ArrayList<>();
  private ArrayList<IPaymentType> OutPosCashPayments = new ArrayList<>();
  private ArrayList<IPaymentType> closePosCashPayments = new ArrayList<>();
  
  private ArrayList<IPaymentType> inVisaPayments = new ArrayList<>();
  private ArrayList<IPaymentType> inCheckPayments = new ArrayList<>();
  
  private ArrayList<IPaymentType> analyzedValuesPosCashPayments = new ArrayList<>();




  
  public ShiftTransactionResumeManagement(Session session) throws Exception {
    this.session = session;
    this.collectorId = session.getId();

    
    this.posInf = (new ShiftTransactionManagement(session)).ensureOpeningUserShift(this.collectorId);
    if (this.posInf == null) {
      throw new Exception("An Open Shift Is Required For This Operation.");
    }

    
    String format = "MM/dd/yyyy HH:mm:ss";
    String dbFormat = "%m/%d/%Y %H:%i:%s";
    DateFormat df = new SimpleDateFormat(format);
    String strStartFromDate = df.format(this.posInf.getStartShiftDate());
    String strEndFromDate = (this.posInf.getEndShiftDate() != null) ? df.format(this.posInf.getEndShiftDate()) : null;
    
    this.startFilterDate = " STR_TO_DATE('" + strStartFromDate + "', '" + dbFormat + "' )";
    if (strEndFromDate != null) {
      this.endFilterDate = "STR_TO_DATE('" + strEndFromDate + "',  '" + dbFormat + "' )";
    }
  }
  
  private IPaymentType getCashPaymentByCurencyId(ArrayList<IPaymentType> cashPayments, Integer currencyId) {
    for (IPaymentType cashPayment : cashPayments) {
      if (cashPayment.getCurrencyId().equals(currencyId))
        return cashPayment; 
    } 
    return null;
  }
  
  private void calculateInvoicePaymentCurrencyParts() throws Exception {
    String sql = "SELECT CashPayment.CurrencyId, CurrencyPartId, SUM(IFNULL(Count, 0)) AS CNT   FROM CashPaymentCurrencyPart   LEFT OUTER JOIN CashPayment  ON CashPayment.Id = CashPaymentCurrencyPart.CashPaymentId   LEFT OUTER JOIN InvoicePayment  ON InvoicePayment.Id = CashPayment.PaymentId   WHERE InvoicePayment.PointOfSaleId = " + 


      
      this.posInf.getId() + 
      " AND (CashPaymentCurrencyPart.IsRefund IS NULL OR CashPaymentCurrencyPart.IsRefund = 0) AND " + 
      "  InvoicePayment.PaymentDate  >= " + this.startFilterDate + (
      
      (this.posInf.getEndShiftDate() != null) ? (
      " AND InvoicePayment.PaymentDate  <= " + this.endFilterDate) : 
      
      " AND InvoicePayment.PaymentDate  <= now() ") + 

      
      " AND InvoicePayment.CollectorId = " + this.collectorId + 
      " GROUP BY CashPayment.CurrencyId, CurrencyPartId ";

    
    RecordSet recordSet = (new QueryEngine()).executeSql(sql);
    for (Record record : recordSet) {
      Integer CurrencyId = record.getIntegerValue("CurrencyId");
      Integer CurrencyPartId = record.getIntegerValue("CurrencyPartId");
      Integer CNT = record.getIntegerValue("CNT");
      CashPayment cashPayment = (CashPayment)getCashPaymentByCurencyId(this.invoicesCashPayments, CurrencyId);
      if (cashPayment == null) {
        cashPayment = new CashPayment();
        cashPayment.setCurrencyId(CurrencyId);
        this.invoicesCashPayments.add(cashPayment);
      } 
      CashPaymentCurrencyPart currencyPart = cashPayment.getCashPaymentCurrencyPart(CurrencyPartId);
      if (currencyPart == null) {
        currencyPart = new CashPaymentCurrencyPart();
        currencyPart.setCurrencyPartId(CurrencyPartId);
        cashPayment.add(currencyPart);
      } 
      currencyPart.setCount(CNT);
    } 


    
    sql = "SELECT CashPayment.CurrencyId, CurrencyPartId, SUM(IFNULL(Count, 0)) AS CNT   FROM CashPaymentCurrencyPart   LEFT OUTER JOIN CashPayment  ON CashPayment.Id = CashPaymentCurrencyPart.CashPaymentId   LEFT OUTER JOIN InvoicePayment  ON InvoicePayment.Id = CashPayment.PaymentId   WHERE InvoicePayment.PointOfSaleId = " + 


      
      this.posInf.getId() + 
      " AND (CashPaymentCurrencyPart.IsRefund = 1) AND " + 
      "  InvoicePayment.PaymentDate  >= " + this.startFilterDate + (
      
      (this.posInf.getEndShiftDate() != null) ? (
      " AND InvoicePayment.PaymentDate  <= " + this.endFilterDate) : 
      
      " AND InvoicePayment.PaymentDate  <= now() ") + 

      
      " AND InvoicePayment.CollectorId = " + this.collectorId + 
      " GROUP BY CashPayment.CurrencyId, CurrencyPartId ";

    
    recordSet = (new QueryEngine()).executeSql(sql);
    for (Record record : recordSet) {
      Integer CurrencyId = record.getIntegerValue("CurrencyId");
      Integer CurrencyPartId = record.getIntegerValue("CurrencyPartId");
      Integer CNT = record.getIntegerValue("CNT");
      CashPayment cashPayment = (CashPayment)getCashPaymentByCurencyId(this.invoicesRefundCashPayments, CurrencyId);
      if (cashPayment == null) {
        cashPayment = new CashPayment();
        cashPayment.setCurrencyId(CurrencyId);
        this.invoicesRefundCashPayments.add(cashPayment);
      } 
      CashPaymentCurrencyPart currencyPart = cashPayment.getCashPaymentCurrencyPart(CurrencyPartId);
      if (currencyPart == null) {
        currencyPart = new CashPaymentCurrencyPart();
        currencyPart.setCurrencyPartId(CurrencyPartId);
        cashPayment.add(currencyPart);
      } 
      currencyPart.setCount(CNT);
    } 
  }
  
  private void calculateVisaCheck() throws Exception {
    String sql = "SELECT CheckPayment.CurrencyId, CheckPayment.Amount, CheckPayment.AmountByBaseCurrency, CheckNumber , BankName, DueDate   FROM CheckPayment   LEFT OUTER JOIN InvoicePayment  ON InvoicePayment.Id = CheckPayment.PaymentId   WHERE InvoicePayment.PointOfSaleId = " + 

      
      this.posInf.getId() + 
      " AND " + 
      "  InvoicePayment.PaymentDate  >= " + this.startFilterDate + (
      
      (this.posInf.getEndShiftDate() != null) ? (
      " AND InvoicePayment.PaymentDate  <= " + this.endFilterDate) : 
      
      " AND InvoicePayment.PaymentDate  <= now() ") + 

      
      " AND InvoicePayment.CollectorId = " + this.collectorId;
    
    RecordSet recordSet = (new QueryEngine()).executeSql(sql);
    for (Record record : recordSet) {
      addInCheckPayment(record);
    }

    
    sql = "SELECT VisaPayment.CurrencyId, ReferenceNumber, VisaNumber, VisaPayment.Amount, VisaPayment.AmountByBaseCurrency  FROM VisaPayment   LEFT OUTER JOIN InvoicePayment  ON InvoicePayment.Id = VisaPayment.PaymentId  WHERE InvoicePayment.PointOfSaleId = " + 

      
      this.posInf.getId() + 
      " AND InvoicePayment.PaymentDate  >= " + this.startFilterDate + (
      
      (this.posInf.getEndShiftDate() != null) ? (
      " AND InvoicePayment.PaymentDate  <= " + this.endFilterDate) : 
      
      " AND InvoicePayment.PaymentDate  <= now() ") + 

      
      " AND InvoicePayment.CollectorId = " + this.collectorId;
    
    recordSet = (new QueryEngine()).executeSql(sql);
    for (Record record : recordSet) {
      addInVisaPayments(record);
    }



    
    sql = "SELECT PosShifyTransType.Guid,   VisaNumber, ReferenceNumber, VisaOpenCloseShift.CurrencyId, VisaOpenCloseShift.Amount, VisaOpenCloseShift.AmountByBaseCurrency  FROM VisaOpenCloseShift  LEFT OUTER JOIN PointOfSaleShiftTransaction  ON PointOfSaleShiftTransaction.Id = VisaOpenCloseShift.PointOfSaleShiftTransactionId   LEFT OUTER JOIN PosShifyTransType on PosShifyTransType.Id = PointOfSaleShiftTransaction.PosShifyTransTypeId   LEFT OUTER JOIN PointOfSaleShift ON PointOfSaleShift.Id =  PointOfSaleShiftTransaction.PointOfSaleShiftId  WHERE PointOfSaleShift.UserId = " + 



      
      this.collectorId + 
      " AND PointOfSaleShift.Id = " + this.posInf.getPointOfSaleShiftId();
    
    recordSet = (new QueryEngine()).executeSql(sql);
    ArrayList<String> outVisaNumbers = new ArrayList<>();
    for (Record record : recordSet) {
      String guid = record.getStringValue("Guid");
      if ("b1717fd7-e16e-11e7-930a-c45444b92ede".equals(guid)) {
        addInVisaPayments(record); continue;
      } 
      if ("b17183fa-e16e-11e7-930a-c45444b92ede".equals(guid)) {
        addInVisaPayments(record); continue;
      } 
      if ("b17184c8-e16e-11e7-930a-c45444b92ede".equals(guid)) {
        String visaNumber = record.getStringValue("VisaNumber");
        outVisaNumbers.add(visaNumber);
      } 
    } 
    
    for (String visaNumber : outVisaNumbers) {
      removeVisaNumber(visaNumber);
    }





    
    sql = "SELECT PosShifyTransType.Guid,   BankName, CheckNumber, DueDate, CheckOpenCloseShift.CurrencyId, CheckOpenCloseShift.Amount, CheckOpenCloseShift.AmountByBaseCurrency  FROM CheckOpenCloseShift  LEFT OUTER JOIN PointOfSaleShiftTransaction  ON PointOfSaleShiftTransaction.Id = CheckOpenCloseShift.PointOfSaleShiftTransactionId   LEFT OUTER JOIN PosShifyTransType on PosShifyTransType.Id = PointOfSaleShiftTransaction.PosShifyTransTypeId   LEFT OUTER JOIN PointOfSaleShift ON PointOfSaleShift.Id =  PointOfSaleShiftTransaction.PointOfSaleShiftId  WHERE PointOfSaleShift.UserId = " + 



      
      this.collectorId + 
      " AND PointOfSaleShift.Id = " + this.posInf.getPointOfSaleShiftId();
    
    recordSet = (new QueryEngine()).executeSql(sql);
    ArrayList<String> outCheckNumbers = new ArrayList<>();
    for (Record record : recordSet) {
      String guid = record.getStringValue("Guid");
      if ("b1717fd7-e16e-11e7-930a-c45444b92ede".equals(guid)) {
        addInCheckPayment(record); continue;
      } 
      if ("b17183fa-e16e-11e7-930a-c45444b92ede".equals(guid)) {
        addInCheckPayment(record); continue;
      } 
      if ("b17184c8-e16e-11e7-930a-c45444b92ede".equals(guid)) {
        String CheckNumber = record.getStringValue("CheckNumber");
        outCheckNumbers.add(CheckNumber);
      } 
    } 
    
    for (String checkNumber : outCheckNumbers) {
      removeCheckPayment(checkNumber);
    }
  }
  
  private void removeVisaNumber(String visaNumber) {
    for (int i = this.inVisaPayments.size() - 1; i >= 0; i--) {
      VisaPayment visaPayment = (VisaPayment)this.inVisaPayments.get(i);
      if (visaPayment.getVisaNumber() != null && visaPayment.getVisaNumber().equals(visaNumber)) {
        this.inVisaPayments.remove(visaPayment);
      }
    } 
  }
  
  private void addInVisaPayments(Record record) {
    VisaPayment visaPayment = new VisaPayment();
    visaPayment.setReferenceNumber(record.getStringValue("ReferenceNumber"));
    visaPayment.setVisaNumber(record.getStringValue("VisaNumber"));
    visaPayment.setCurrencyId(record.getIntegerValue("CurrencyId"));
    visaPayment.setAmount(record.getDoubleValue("Amount"));
    visaPayment.setAmountByBaseCurrency(record.getDoubleValue("AmountByBaseCurrency"));
    
    this.inVisaPayments.add(visaPayment);
  }
  
  private void removeCheckPayment(String checkNumber) {
    for (int i = this.inCheckPayments.size() - 1; i >= 0; i--) {
      CheckPayment checkPayment = (CheckPayment)this.inCheckPayments.get(i);
      if (checkPayment.getCheckNumber() != null && checkPayment.getCheckNumber().equals(checkNumber)) {
        this.inCheckPayments.remove(checkPayment);
      }
    } 
  }
  
  private void addInCheckPayment(Record record) {
    CheckPayment checkPayment = new CheckPayment();
    checkPayment.setBankName(record.getStringValue("BankName"));
    checkPayment.setCheckNumber(record.getStringValue("CheckNumber"));
    checkPayment.setDueDate(record.getDateValue("DueDate"));
    checkPayment.setCurrencyId(record.getIntegerValue("CurrencyId"));
    checkPayment.setAmount(record.getDoubleValue("Amount"));
    checkPayment.setAmountByBaseCurrency(record.getDoubleValue("AmountByBaseCurrency"));
    
    this.inCheckPayments.add(checkPayment);
  }
  
  private void calculateTransactionsPaymentCurrencyParts() throws Exception {
    String sql = "SELECT PosShifyTransType.Guid, CashOpenCloseShift.CurrencyId, CurrencyPartId ,  SUM(IFNULL(Count, 0)) as CNT   FROM CashOpenCloseShiftCurrencyPart   LEFT OUTER JOIN CashOpenCloseShift  ON CashOpenCloseShift.Id =  CashOpenCloseShiftCurrencyPart.CashOpenCloseShiftId   LEFT OUTER JOIN PointOfSaleShiftTransaction  ON PointOfSaleShiftTransaction.Id = CashOpenCloseShift.PointOfSaleShiftTransactionId   LEFT OUTER JOIN PosShifyTransType on PosShifyTransType.Id = PointOfSaleShiftTransaction.PosShifyTransTypeId   LEFT OUTER JOIN PointOfSaleShift ON PointOfSaleShift.Id =  PointOfSaleShiftTransaction.PointOfSaleShiftId  WHERE PointOfSaleShift.UserId = " + 





      
      this.collectorId + 
      " AND PointOfSaleShift.Id = " + this.posInf.getPointOfSaleShiftId() + 
      " GROUP BY PosShifyTransType.Id, CashOpenCloseShift.CurrencyId,  CurrencyPartId ";
    RecordSet recordSet = (new QueryEngine()).executeSql(sql);
    for (Record record : recordSet) {
      Integer CurrencyId = record.getIntegerValue("CurrencyId");
      Integer CurrencyPartId = record.getIntegerValue("CurrencyPartId");
      Integer CNT = record.getIntegerValue("CNT");
      
      String guid = record.getStringValue("Guid");
      ArrayList<IPaymentType> cashPayments = null;
      if ("b1717fd7-e16e-11e7-930a-c45444b92ede".equals(guid)) {
        cashPayments = this.openPosCashPayments;
      } else if ("b17183fa-e16e-11e7-930a-c45444b92ede".equals(guid)) {
        cashPayments = this.InPosCashPayments;
      } else if ("b17184c8-e16e-11e7-930a-c45444b92ede".equals(guid)) {
        cashPayments = this.OutPosCashPayments;
      } else if ("b1718356-e16e-11e7-930a-c45444b92ede".equals(guid)) {
        cashPayments = this.closePosCashPayments;
      } 
      if (cashPayments != null) {
        CashPayment cashPayment = (CashPayment)getCashPaymentByCurencyId(cashPayments, CurrencyId);
        if (cashPayment == null) {
          cashPayment = new CashPayment();
          cashPayment.setCurrencyId(CurrencyId);
          cashPayments.add(cashPayment);
        } 
        CashPaymentCurrencyPart currencyPart = cashPayment.getCashPaymentCurrencyPart(CurrencyPartId);
        if (currencyPart == null) {
          currencyPart = new CashPaymentCurrencyPart();
          currencyPart.setCurrencyPartId(CurrencyPartId);
          cashPayment.add(currencyPart);
          currencyPart.setCount(CNT); continue;
        } 
        Integer cntValue = currencyPart.getCount();
        cntValue = Integer.valueOf((cntValue != null) ? cntValue.intValue() : 0);
        cntValue = Integer.valueOf(cntValue.intValue() + CNT.intValue());
        currencyPart.setCount(cntValue);
      } 
    } 
  }


  
  private void analyzedValuesPosCashPayments() {
    for (IPaymentType cashPayment : this.invoicesCashPayments) {
      CashPayment newCashPayment = ((CashPayment)cashPayment).cloneCashPayment();
      this.analyzedValuesPosCashPayments.add(newCashPayment);
    } 

    
    for (IPaymentType cashPayment : this.invoicesRefundCashPayments) {
      CashPayment existingCashPayment = (CashPayment)getCashPaymentByCurencyId(this.analyzedValuesPosCashPayments, cashPayment.getCurrencyId());
      if (existingCashPayment == null) {
        existingCashPayment = ((CashPayment)cashPayment).cloneCashPayment();
        existingCashPayment.minusAllCounter();
        this.analyzedValuesPosCashPayments.add(existingCashPayment); continue;
      } 
      existingCashPayment.decrementCurrencyPart((CashPayment)cashPayment);
    } 

    
    for (IPaymentType cashPayment : this.openPosCashPayments) {
      CashPayment existingCashPayment = (CashPayment)getCashPaymentByCurencyId(this.analyzedValuesPosCashPayments, cashPayment.getCurrencyId());
      if (existingCashPayment == null) {
        existingCashPayment = ((CashPayment)cashPayment).cloneCashPayment();
        this.analyzedValuesPosCashPayments.add(existingCashPayment); continue;
      } 
      existingCashPayment.incrementCurrencyPart((CashPayment)cashPayment);
    } 
    
    for (IPaymentType cashPayment : this.InPosCashPayments) {
      CashPayment existingCashPayment = (CashPayment)getCashPaymentByCurencyId(this.analyzedValuesPosCashPayments, cashPayment.getCurrencyId());
      if (existingCashPayment == null) {
        existingCashPayment = ((CashPayment)cashPayment).cloneCashPayment();
        this.analyzedValuesPosCashPayments.add(existingCashPayment); continue;
      } 
      existingCashPayment.incrementCurrencyPart((CashPayment)cashPayment);
    } 

    
    for (IPaymentType cashPayment : this.OutPosCashPayments) {
      CashPayment existingCashPayment = (CashPayment)getCashPaymentByCurencyId(this.analyzedValuesPosCashPayments, cashPayment.getCurrencyId());
      if (existingCashPayment == null) {
        existingCashPayment = ((CashPayment)cashPayment).cloneCashPayment();
        existingCashPayment.minusAllCounter();
        this.analyzedValuesPosCashPayments.add(existingCashPayment); continue;
      } 
      existingCashPayment.decrementCurrencyPart((CashPayment)cashPayment);
    } 
  }







  
  public PosOpenCloseShiftInf getShiftTransactionsResume(Integer collectorId) throws Exception {
    PosOpenCloseShiftInf posOpenCloseShiftInf = new PosOpenCloseShiftInf();
    
    calculateInvoicePaymentCurrencyParts();
    
    calculateTransactionsPaymentCurrencyParts();
    
    calculateVisaCheck();
    
    analyzedValuesPosCashPayments();
    
    posOpenCloseShiftInf.put(InvoicePaymentType.CASH, this.analyzedValuesPosCashPayments);
    posOpenCloseShiftInf.put(InvoicePaymentType.VISA, this.inVisaPayments);
    posOpenCloseShiftInf.put(InvoicePaymentType.CHECK, this.inCheckPayments);
    
    return posOpenCloseShiftInf;
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\invoice\ShiftTransactionResumeManagement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */