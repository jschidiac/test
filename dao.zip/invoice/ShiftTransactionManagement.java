package me.iradius.server.dao.invoice;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.db.Table;
import me.iradius.shared.invoice.PosInf;
import me.iradius.shared.invoice.payment.CashPayment;
import me.iradius.shared.invoice.payment.CashPaymentCurrencyPart;
import me.iradius.shared.invoice.payment.CheckPayment;
import me.iradius.shared.invoice.payment.IPaymentType;
import me.iradius.shared.invoice.payment.InvoicePaymentType;
import me.iradius.shared.invoice.payment.PosOpenCloseShiftInf;
import me.iradius.shared.invoice.payment.ShiftTransactionType;
import me.iradius.shared.invoice.payment.VisaPayment;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.Session;

public class ShiftTransactionManagement {
	
	protected Session	session;
	protected Integer	userId;
	
	public ShiftTransactionManagement(Session session) {
		this.session = session;
		this.userId = session.getId();
	}
	
	private Integer getPosShifyTransTypeIdByGuid(String guid) throws Exception {
		String sql = "SELECT Id  from PosShifyTransType Where guid= '" + guid + "'";
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet.size() > 0) {
			return ((Record) recordSet.get(0)).getIntegerValue("Id");
		}
		return null;
	}
	
	private String getPosShifyTransTypeGuid(Integer posShifyTransTypeId) throws Exception {
		String sql = "SELECT Guid from PosShifyTransType Where Id = " + posShifyTransTypeId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet.size() > 0) {
			return ((Record) recordSet.get(0)).getStringValue("Guid");
		}
		return null;
	}
	
	private Integer newPointOfSaleShift(Date operationDate, Integer pointOfSaleId) throws Exception {
		Table table = new Table("PointOfSaleShift", "Id", Boolean.valueOf(true));
		table.addFieldValue("PointOfSaleId", pointOfSaleId);
		table.addFieldValue("UserId", this.userId);
		table.addFieldValue("StartShiftDate", operationDate);
		return (new QueryEngine()).updateData(table);
	}
	
	private void closeShift(Integer pointOfSaleShiftId, Date operationDate) throws Exception {
		Table table = new Table("PointOfSaleShift", "Id", Boolean.valueOf(false));
		table.setPkFieldValue(pointOfSaleShiftId);
		table.addFieldValue("EndShiftDate", operationDate);
		(new QueryEngine()).updateData(table);
	}
	
	public PosInf ensureOpeningUserShift(Integer userId) throws Exception {
		String sql = "SELECT PointOfSales.Id, PointOfSales.Name, StartShiftDate, EndShiftDate, PointOfSaleShift.Id as PointOfSaleShiftId   FROM PointOfSaleShift   LEFT OUTER JOIN  PointOfSales on PointOfSales.Id = PointOfSaleShift.PointOfSaleId  WHERE UserId = "
				+ userId + " AND  Date(StartShiftDate) = Date(now()) " + " AND now() <= case when  PointOfSaleShift.EndShiftDate IS NOT NULL THEN PointOfSaleShift.EndShiftDate  ELSE NOW()  END " + " ORDER BY StartShiftDate DESC ";
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		Iterator<Record> iterator = recordSet.iterator();
		if (iterator.hasNext()) {
			Record record = iterator.next();
			PosInf posInf = new PosInf();
			posInf.setId(record.getIntegerValue("Id"));
			posInf.setPointOfSaleShiftId(record.getIntegerValue("PointOfSaleShiftId"));
			posInf.setName(record.getStringValue("Name"));
			posInf.setStartShiftDate(record.getDateValue("StartShiftDate"));
			posInf.setEndShiftDate(record.getDateValue("EndShiftDate"));
			return posInf;
		}
		return null;
	}
	
	public PosInf getLastClosedUserShift(Integer collectorId) throws Exception {
		String sql = "SELECT PointOfSales.Id, PointOfSales.Name, StartShiftDate, EndShiftDate, PointOfSaleShift.Id as PointOfSaleShiftId   FROM PointOfSaleShift   LEFT OUTER JOIN  PointOfSales on PointOfSales.Id = PointOfSaleShift.PointOfSaleId  WHERE UserId = "
				+ collectorId + " AND  Date(StartShiftDate) = Date(now()) " + " ORDER BY StartShiftDate DESC limit 0 , 1 ";
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		Iterator<Record> iterator = recordSet.iterator();
		if (iterator.hasNext()) {
			Record record = iterator.next();
			PosInf posInf = new PosInf();
			posInf.setId(record.getIntegerValue("Id"));
			posInf.setPointOfSaleShiftId(record.getIntegerValue("PointOfSaleShiftId"));
			posInf.setName(record.getStringValue("Name"));
			posInf.setStartShiftDate(record.getDateValue("StartShiftDate"));
			posInf.setEndShiftDate(record.getDateValue("EndShiftDate"));
			return posInf;
		}
		return null;
	}
	
	private Integer getCurrentShift() throws Exception {
		String sql = "SELECT PointOfSaleShift.Id    FROM PointOfSaleShift   WHERE UserId = " + this.userId + " AND Date(StartShiftDate) = Date(now()) " + " AND now() <= " + " CASE " + " WHEN PointOfSaleShift.EndShiftDate IS NOT NULL " + " THEN "
				+ "  PointOfSaleShift.EndShiftDate  " + " ELSE " + " NOW()  " + " END ORDER BY StartShiftDate DESC limit 0 , 1  ";
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		Iterator<Record> iterator = recordSet.iterator();
		if (iterator.hasNext()) {
			Record record = iterator.next();
			return record.getIntegerValue("Id");
		}
		return null;
	}
	
	private Integer addPointOfSaleShiftTransaction(Integer pointOfSalesId, Integer pointOfSaleShiftId, Integer posShifyTransTypeId, Double amount, Date operationDate, Integer transUserId, String notes) throws Exception {
		Table table = new Table("PointOfSaleShiftTransaction", "Id", Boolean.valueOf(true));
		table.addFieldValue("PointOfSaleShiftId", pointOfSaleShiftId);
		table.addFieldValue("PosShifyTransTypeId", posShifyTransTypeId);
		table.addFieldValue("Amount", amount);
		table.addFieldValue("OperationDate", operationDate);
		table.addFieldValue("TransUserId", transUserId);
		table.addFieldValue("Notes", notes);
		return (new QueryEngine()).updateData(table);
	}
	
	private void traceVisaOpenCloseShiftPaymentType(Integer pointOfSaleShiftTransactionId, ArrayList<IPaymentType> value) throws Exception {
		for (IPaymentType paymentType : value) {
			VisaPayment visaPayment = (VisaPayment) paymentType;
			Table table = new Table("VisaOpenCloseShift", "Id", Boolean.valueOf(true));
			table.addFieldValue("PointOfSaleShiftTransactionId", pointOfSaleShiftTransactionId);
			table.addFieldValue("VisaNumber", visaPayment.getVisaNumber());
			table.addFieldValue("ReferenceNumber", visaPayment.getReferenceNumber());
			table.addFieldValue("CurrencyId", visaPayment.getCurrencyId());
			table.addFieldValue("Amount", visaPayment.getAmount());
			table.addFieldValue("AmountByBaseCurrency", visaPayment.getAmountByBaseCurrency());
			(new QueryEngine()).updateData(table);
		}
	}
	
	private void traceCheckOpenCloseShiftPaymentType(Integer pointOfSaleShiftTransactionId, ArrayList<IPaymentType> value) throws Exception {
		for (IPaymentType paymentType : value) {
			CheckPayment checkPayment = (CheckPayment) paymentType;
			Table table = new Table("CheckOpenCloseShift", "Id", Boolean.valueOf(true));
			table.addFieldValue("PointOfSaleShiftTransactionId", pointOfSaleShiftTransactionId);
			table.addFieldValue("BankName", checkPayment.getBankName());
			table.addFieldValue("CheckNumber", checkPayment.getCheckNumber());
			table.addFieldValue("DueDate", checkPayment.getDueDate());
			table.addFieldValue("CurrencyId", checkPayment.getCurrencyId());
			table.addFieldValue("Amount", checkPayment.getAmount());
			table.addFieldValue("AmountByBaseCurrency", checkPayment.getAmountByBaseCurrency());
			(new QueryEngine()).updateData(table);
		}
	}
	
	private void traceCashOpenCloseShiftCurrencyPart(Integer cashOpenCloseShiftid, CashPayment cashPayment, Integer collectorId, Integer pointOfSaleId) throws Exception {
		for (CashPaymentCurrencyPart part : cashPayment) {
			Table table = new Table("CashOpenCloseShiftCurrencyPart", "Id", Boolean.valueOf(true));
			table.addFieldValue("CashOpenCloseShiftId", cashOpenCloseShiftid);
			table.addFieldValue("CurrencyPartId", part.getCurrencyPartId());
			table.addFieldValue("Count", part.getCount());
			table.addFieldValue("CollectorId", collectorId);
			table.addFieldValue("PointOfSaleId", pointOfSaleId);
			(new QueryEngine()).updateData(table);
		}
	}
	
	private void traceCashOpenCloseShiftPaymentType(Integer collectorId, Integer pointOfSaleId, Integer pointOfSaleShiftTransactionId, ArrayList<IPaymentType> value) throws Exception {
		for (IPaymentType paymentType : value) {
			CashPayment cashPayment = (CashPayment) paymentType;
			Table table = new Table("CashOpenCloseShift", "Id", Boolean.valueOf(true));
			table.addFieldValue("PointOfSaleShiftTransactionId", pointOfSaleShiftTransactionId);
			table.addFieldValue("CurrencyId", cashPayment.getCurrencyId());
			table.addFieldValue("Amount", cashPayment.getAmount());
			table.addFieldValue("AmountByBaseCurrency", cashPayment.getAmountByBaseCurrency());
			Integer cashOpenCloseShiftid = (new QueryEngine()).updateData(table);
			traceCashOpenCloseShiftCurrencyPart(cashOpenCloseShiftid, cashPayment, collectorId, pointOfSaleId);
		}
	}
	
	private void traceOpenCloseShiftPaymentType(Integer collectorId, Integer pointOfSaleId, Integer pointOfSaleShiftTransactionId, InvoicePaymentType key, ArrayList<IPaymentType> value) throws Exception {
		switch (key) {
			case VISA:
				traceVisaOpenCloseShiftPaymentType(pointOfSaleShiftTransactionId, value);
				break;
			case CHECK:
				traceCheckOpenCloseShiftPaymentType(pointOfSaleShiftTransactionId, value);
				break;
			case CASH:
				traceCashOpenCloseShiftPaymentType(collectorId, pointOfSaleId, pointOfSaleShiftTransactionId, value);
				break;
		}
	}
	
	public void saveShiftTransaction(Date operationDate, Integer pointOfSalesId, Integer posShifyTransTypeId, Integer transUserId, String notes, PosOpenCloseShiftInf posOpenCloseShiftInf) throws Exception {
		String posShifyTransTypeGuid = getPosShifyTransTypeGuid(posShifyTransTypeId);
		if ("b1717fd7-e16e-11e7-930a-c45444b92ede".equals(posShifyTransTypeGuid)) {
			Integer pointOfSaleShiftId = newPointOfSaleShift(operationDate, pointOfSalesId);
			Integer pointOfSaleShiftTransactionId = addPointOfSaleShiftTransaction(pointOfSalesId, pointOfSaleShiftId, posShifyTransTypeId, posOpenCloseShiftInf.getAmount(), operationDate, transUserId, notes);
			for (Map.Entry<InvoicePaymentType, ArrayList<IPaymentType>> entry : (Iterable<Map.Entry<InvoicePaymentType, ArrayList<IPaymentType>>>) posOpenCloseShiftInf.entrySet()) {
				traceOpenCloseShiftPaymentType(posOpenCloseShiftInf.getCollectorId(), posOpenCloseShiftInf.getPointOfSaleId(), pointOfSaleShiftTransactionId, entry.getKey(), entry.getValue());
			}
		} else if ("b1718356-e16e-11e7-930a-c45444b92ede".equals(posShifyTransTypeGuid)) {
			Integer pointOfSaleShiftId = getCurrentShift();
			closeShift(pointOfSaleShiftId, operationDate);
			posShifyTransTypeId = getPosShifyTransTypeIdByGuid("b1718356-e16e-11e7-930a-c45444b92ede");
			Integer pointOfSaleShiftTransactionId = addPointOfSaleShiftTransaction(pointOfSalesId, pointOfSaleShiftId, posShifyTransTypeId, posOpenCloseShiftInf.getAmount(), operationDate, transUserId, notes);
			for (Map.Entry<InvoicePaymentType, ArrayList<IPaymentType>> entry : (Iterable<Map.Entry<InvoicePaymentType, ArrayList<IPaymentType>>>) posOpenCloseShiftInf.entrySet()) {
				traceOpenCloseShiftPaymentType(posOpenCloseShiftInf.getCollectorId(), posOpenCloseShiftInf.getPointOfSaleId(), pointOfSaleShiftTransactionId, entry.getKey(), entry.getValue());
			}
		} else {
			Integer pointOfSaleShiftId = getCurrentShift();
			Integer pointOfSaleShiftTransactionId = addPointOfSaleShiftTransaction(pointOfSalesId, pointOfSaleShiftId, posShifyTransTypeId, posOpenCloseShiftInf.getAmount(), operationDate, transUserId, notes);
			for (Map.Entry<InvoicePaymentType, ArrayList<IPaymentType>> entry : (Iterable<Map.Entry<InvoicePaymentType, ArrayList<IPaymentType>>>) posOpenCloseShiftInf.entrySet()) {
				traceOpenCloseShiftPaymentType(posOpenCloseShiftInf.getCollectorId(), posOpenCloseShiftInf.getPointOfSaleId(), pointOfSaleShiftTransactionId, entry.getKey(), entry.getValue());
			}
		}
	}
	
	private ShiftTransactionType getShiftTransactionTypeByGuid(String shiftTransTypeGuid) {
		if (shiftTransTypeGuid != null) {
			if (shiftTransTypeGuid.equalsIgnoreCase("b1717fd7-e16e-11e7-930a-c45444b92ede")) {
				return ShiftTransactionType.OPEN;
			}
			if (shiftTransTypeGuid.equalsIgnoreCase("b1718356-e16e-11e7-930a-c45444b92ede")) {
				return ShiftTransactionType.CLOSE;
			}
			return ShiftTransactionType.IN_OUT;
		}
		return ShiftTransactionType.IN_OUT;
	}
	
	public PosOpenCloseShiftInf getShiftTransaction(Integer shiftTransactionId) throws Exception {
		String sql = "SELECT PosShifyTransTypeId, PosShifyTransType.Guid, Amount,OperationDate, TransUserId, Notes  FROM PointOfSaleShiftTransaction  LEFT OUTER JOIN PosShifyTransType on PosShifyTransType.Id = PointOfSaleShiftTransaction.PosShifyTransTypeId  Where PointOfSaleShiftTransaction.Id = "
				+ shiftTransactionId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			PosOpenCloseShiftInf shiftTransactionInf = new PosOpenCloseShiftInf();
			shiftTransactionInf.setAmount(record.getDoubleValue("Amount"));
			shiftTransactionInf.setFromToUserId(record.getIntegerValue("TransUserId"));
			shiftTransactionInf.setNotes(record.getStringValue("Notes"));
			shiftTransactionInf.setOperationDate(record.getDateValue("OperationDate"));
			shiftTransactionInf.setShiftTransTypeId(record.getIntegerValue("PosShifyTransTypeId"));
			String shiftTransTypeGuid = record.getStringValue("Guid");
			shiftTransactionInf.setShiftTransactionType(getShiftTransactionTypeByGuid(shiftTransTypeGuid));
			Boolean remainingMode = Boolean.valueOf(false);
			if (!remainingMode.booleanValue()) {
				ArrayList<IPaymentType> visaPayments = new ArrayList<>();
				sql = "SELECT VisaNumber, ReferenceNumber, CurrencyId, Amount, AmountByBaseCurrency  FROM VisaOpenCloseShift  Where PointOfSaleShiftTransactionId = " + shiftTransactionId;
				RecordSet visaRecordSet = (new QueryEngine()).executeSql(sql);
				for (Record visaRecord : visaRecordSet) {
					VisaPayment visaPayment = new VisaPayment();
					visaPayment.setVisaNumber(visaRecord.getStringValue("VisaNumber"));
					visaPayment.setReferenceNumber(visaRecord.getStringValue("ReferenceNumber"));
					visaPayment.setCurrencyId(visaRecord.getIntegerValue("CurrencyId"));
					visaPayment.setAmount(visaRecord.getDoubleValue("Amount"));
					visaPayment.setAmountByBaseCurrency(visaRecord.getDoubleValue("AmountByBaseCurrency"));
					visaPayments.add(visaPayment);
				}
				if (visaPayments.size() > 0) {
					shiftTransactionInf.put(InvoicePaymentType.VISA, visaPayments);
				}
				ArrayList<IPaymentType> checkPayments = new ArrayList<>();
				sql = "SELECT BankName, CheckNumber, CurrencyId, DueDate, Amount, AmountByBaseCurrency  FROM CheckOpenCloseShift  Where PointOfSaleShiftTransactionId = " + shiftTransactionId;
				RecordSet checkRecordSet = (new QueryEngine()).executeSql(sql);
				for (Record checkRecord : checkRecordSet) {
					CheckPayment checkPayment = new CheckPayment();
					checkPayment.setBankName(checkRecord.getStringValue("BankName"));
					checkPayment.setCheckNumber(checkRecord.getStringValue("CheckNumber"));
					checkPayment.setDueDate(checkRecord.getDateValue("DueDate"));
					checkPayment.setCurrencyId(checkRecord.getIntegerValue("CurrencyId"));
					checkPayment.setAmount(checkRecord.getDoubleValue("Amount"));
					checkPayment.setAmountByBaseCurrency(checkRecord.getDoubleValue("AmountByBaseCurrency"));
					checkPayments.add(checkPayment);
				}
				if (checkPayments.size() > 0) {
					shiftTransactionInf.put(InvoicePaymentType.CHECK, checkPayments);
				}
			}
			ArrayList<IPaymentType> cashPayments = new ArrayList<>();
			sql = "SELECT  Id, CurrencyId,   Amount, AmountByBaseCurrency  FROM CashOpenCloseShift  Where PointOfSaleShiftTransactionId = " + shiftTransactionId;
			RecordSet cashrecordSet = (new QueryEngine()).executeSql(sql);
			for (Record cashRecord : cashrecordSet) {
				CashPayment cashPayment = new CashPayment();
				cashPayments.add(cashPayment);
				cashPayment.setCurrencyId(cashRecord.getIntegerValue("CurrencyId"));
				cashPayment.setAmount(cashRecord.getDoubleValue("Amount"));
				cashPayment.setAmountByBaseCurrency(cashRecord.getDoubleValue("AmountByBaseCurrency"));
				Integer cashPaymentid = cashRecord.getIntegerValue("Id");
				sql = "SELECT CurrencyPartId, Count  FROM  CashOpenCloseShiftCurrencyPart  Where CashOpenCloseShiftId = " + cashPaymentid;
				RecordSet partRecordSet = (new QueryEngine()).executeSql(sql);
				for (Record partRecord : partRecordSet) {
					CashPaymentCurrencyPart cashPaymentCurrencyPart = new CashPaymentCurrencyPart();
					cashPayment.add(cashPaymentCurrencyPart);
					cashPaymentCurrencyPart.setCount(partRecord.getIntegerValue("Count"));
					cashPaymentCurrencyPart.setCurrencyPartId(partRecord.getIntegerValue("CurrencyPartId"));
				}
			}
			if (cashPayments.size() > 0) {
				shiftTransactionInf.put(InvoicePaymentType.CASH, cashPayments);
			}
			return shiftTransactionInf;
		}
		return null;
	}
	
	public PosOpenCloseShiftInf getShiftTransactionsResume(Integer collectorId) {
		PosOpenCloseShiftInf posOpenCloseShiftInf = new PosOpenCloseShiftInf();
		return posOpenCloseShiftInf;
	}
}
/*
 * Location:
 * C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server
 * \dao\invoice\ShiftTransactionManagement.class Java compiler version: 7 (51.0)
 * JD-Core Version: 1.1.3
 */