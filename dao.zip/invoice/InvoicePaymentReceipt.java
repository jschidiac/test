package me.iradius.server.dao.invoice;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.invoice.InvoiceDef;
import me.iradius.shared.invoice.curr.CurrencyInf;
import me.iradius.shared.invoice.payment.InvoicePayment;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.Session;

public class InvoicePaymentReceipt
{
  public String printReceipt(Session session, ArrayList<InvoiceDef> invoices, InvoicePayment invoicePayment) throws Exception {
    Integer dealerId = null;
    if (session.isDealer()) {
      dealerId = session.getId();
    } else {
      dealerId = session.getDealerId();
    } 
    
    InvoiceDef invoiceDef = null;
    if (invoices != null && invoices.size() > 0) {
      invoiceDef = invoices.get(0);
    }
    
    CurrencyInf baseCurrencuInf = (new InvoicePaymentDao()).getBaseCurrencuInf();
    String currency = (baseCurrencuInf != null) ? baseCurrencuInf.getSymbol() : "LL";
    
    String sql = "select CompanyVatNumber, CompanyName, CompanyAddress, CompanyPhone, CompanyMobile from Dealer where UserId = " + dealerId;
    
    RecordSet partRecordSet = (new QueryEngine()).executeSql(sql);
    Iterator<Record> iterator = partRecordSet.iterator(); if (iterator.hasNext()) { Record record = iterator.next();
      
      String CompanyVatNumber = record.getStringValue("CompanyVatNumber");
      String CompanyName = record.getStringValue("CompanyName");
      String CompanyAddress = record.getStringValue("CompanyAddress");
      String CompanyPhone = record.getStringValue("CompanyPhone");
      String CompanyMobile = record.getStringValue("CompanyMobile");
      String receipt = "<Div style=\"width:100%;height100%;line-height:0.3;\">";
      
      CompanyAddress = (CompanyAddress != null) ? CompanyAddress : "";
      CompanyName = (CompanyName != null) ? CompanyName : "";
      CompanyVatNumber = (CompanyVatNumber != null) ? CompanyVatNumber : "";
      
      String phone = CompanyPhone;
      if (phone == null || phone.isEmpty()) {
        phone = CompanyMobile;
      }

      
      receipt = String.valueOf(receipt) + "<CENTER><B><H4>" + CompanyName + "</H4></B></CENTER> ";
      receipt = String.valueOf(receipt) + "<CENTER><B><H4>" + CompanyAddress + "</H4></B></CENTER> ";
      if (invoiceDef != null && invoiceDef.getDisplayFinancialInfoOnInvoice().booleanValue()) {
        receipt = String.valueOf(receipt) + "<CENTER><B><H4> VAT : " + CompanyVatNumber + "</H4></B></CENTER> ";
      }
      receipt = String.valueOf(receipt) + "<DIV><B>Tel : </B>" + phone + "</DIV>";
      receipt = String.valueOf(receipt) + "<BR/>";

      
      if (invoiceDef != null) {
        receipt = String.valueOf(receipt) + "<BR/>";
        receipt = String.valueOf(receipt) + "<DIV style=\"text-align: right;\"><B><H3>Receipt : " + invoiceDef.getInvoiceNbr() + "</H3></B></DIV> ";
      } 
      
      receipt = String.valueOf(receipt) + "<BR/>";
      receipt = String.valueOf(receipt) + "<table style=\"width:100%;line-height: 0.6;\">";
      receipt = String.valueOf(receipt) + addReceiptLine("Collector", session.getFullName());

      
      if (invoiceDef != null) {
        receipt = String.valueOf(receipt) + addReceiptLine("UserName", invoiceDef.getUserName());
        receipt = String.valueOf(receipt) + addReceiptLine("Name", invoiceDef.getUserFullName());
        receipt = String.valueOf(receipt) + addReceiptLine("Phone", invoiceDef.getUserPhone());
      } else {
        receipt = String.valueOf(receipt) + addReceiptLine("Name", "Guest");
      } 
      
      receipt = String.valueOf(receipt) + addReceiptLine("", "");
      receipt = String.valueOf(receipt) + addReceiptLine("", "");
      
      invoicePayment.assignInvoicePaymentValues();
      DecimalFormatSymbols symbols = new DecimalFormatSymbols();
      symbols.setGroupingSeparator(' ');
      DecimalFormat myFormatter = new DecimalFormat("#,###", symbols);
      receipt = String.valueOf(receipt) + addReceiptLine("Balance " + currency, myFormatter.format(invoicePayment.getBalanceBeforePayment()), Boolean.valueOf(true));
      receipt = String.valueOf(receipt) + addReceiptLine("Received Amount " + currency, myFormatter.format(invoicePayment.getReceviedAmount()), Boolean.valueOf(true));
      receipt = String.valueOf(receipt) + addReceiptLine("Refund Amount " + currency, myFormatter.format((invoicePayment.getRefundAmount() != null) ? invoicePayment.getRefundAmount().doubleValue() : 0.0D), Boolean.valueOf(true));
      receipt = String.valueOf(receipt) + addReceiptLine("Remaining " + currency, myFormatter.format(invoicePayment.getBalanceAfterPayment()), Boolean.valueOf(true));
      
      receipt = String.valueOf(receipt) + "</table>";
      receipt = String.valueOf(receipt) + "<BR/>";

      
      String format = "dd-MM-yyyy HH:mm";
      DateFormat df = new SimpleDateFormat(format);
      String strFromDate = df.format(invoicePayment.getPaymentDate());
      
      receipt = String.valueOf(receipt) + "<CENTER><B><H5>Date : " + strFromDate + "</H5></B></CENTER> ";
      
      receipt = String.valueOf(receipt) + "<CENTER><B><H4>Thank you</H4></B></CENTER> ";
      
      receipt = String.valueOf(receipt) + "</div>";
      
      return receipt; }
    
    return "";
  }
  
  private String addReceiptLine(String leftString, String rightString) {
    return addReceiptLine(leftString, rightString, Boolean.valueOf(false));
  }
  
  private String addReceiptLine(String leftString, String rightString, Boolean rightalign) {
    String rceipt = "";
    String align = rightalign.booleanValue() ? "style=\"width: 50%;text-align: right;\"" : "style=\"width: 50%;\"";
    rceipt = String.valueOf(rceipt) + "<tr><td " + align + "><div style=\"font-size: 12px;width: 100%;\">" + leftString + "</div></td> <td " + align + "><div  style=\"font-size: 14px;width: 100%;\">" + rightString + "</div></td>";
    return rceipt;
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\invoice\InvoicePaymentReceipt.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */