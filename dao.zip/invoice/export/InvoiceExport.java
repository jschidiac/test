package me.iradius.server.dao.invoice.export;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfGState;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import me.iradius.server.cfg.InvoiceNbrGenerated;
import me.iradius.server.ctxt.AppContext;
import me.iradius.server.dao.invoice.InvoicePaymentDao;
import me.iradius.shared.invoice.InvoiceDef;
import me.iradius.shared.invoice.InvoiceItem;
import me.iradius.shared.invoice.curr.CurrencyInf;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.Session;

public class InvoiceExport {
	
	protected static final String	PGET_NBR		= "Page No. ";
	protected static final String	footer1			= "\u00A9 Copyright Improve Data. All Rights Reserved.";
	protected static final String	CREATOR			= "Joseph Chidiac";
	protected Document				doc;
	protected PdfWriter				docWriter;
	protected PdfContentByte		cb;
	protected Rectangle				page;
	protected Integer				pageHeight;
	protected Integer				pageWidth;
	protected BaseFont				bfBold;
	protected BaseFont				bf;
	protected int					pageNumber		= 0;
	protected int					leftmargin		= 20;
	protected int					rowHeight		= 20;
	protected int					topDataGrid		= 200;
	protected int					headerHeight	= 100;
	protected int					bottomDataGrid	= 50;
	protected DateFormat			dateFormat;
	protected RecordSet				recordSet;
	protected String				fileName;
	protected String				pdfFileName;
	protected Session				session;
	protected ArrayList<InvoiceDef>	invoices;
	protected DecimalFormat			myFormatter;
	
	public InvoiceExport(Session session, ArrayList<InvoiceDef> invoices) {
		this.session = session;
		this.invoices = invoices;
		this.headerHeight = 20;
		this.topDataGrid = 355;
		this.bottomDataGrid = 100;
		this.leftmargin = 90;
		this.rowHeight = 30;
		Integer id = Integer.valueOf((int) Math.random());
		this.fileName = "PDF" + id + ".pdf";
		this.pdfFileName = ExportUtils.getPDFFileName(this.fileName);
		this.bfBold = ExportUtils.getBoldBaseFont();
		this.bf = ExportUtils.getBaseFont();
		this.dateFormat = new SimpleDateFormat("dd MMM yyyy");
		DecimalFormatSymbols symbols = new DecimalFormatSymbols();
		symbols.setGroupingSeparator(' ');
		this.myFormatter = new DecimalFormat("#,###", symbols);
	}
	
	protected void initializeDocument() throws Exception {
		this.doc = new Document();
		this.docWriter = PdfWriter.getInstance(this.doc, new FileOutputStream(this.pdfFileName));
		this.doc.addAuthor("Joseph Chidiac");
		this.doc.addCreationDate();
		this.doc.addProducer();
		this.doc.addCreator("Joseph Chidiac");
		this.doc.addTitle("");
		this.doc.setPageSize(PageSize.A5.rotate());
		this.doc.open();
		this.page = this.doc.getPageSize();
		this.pageHeight = Integer.valueOf((int) this.page.getHeight());
		this.pageWidth = Integer.valueOf((int) this.page.getWidth());
		this.cb = this.docWriter.getDirectContent();
	}
	
	private void closeDocument() {
		if (this.doc != null) {
			this.doc.close();
		}
		if (this.docWriter != null) {
			this.docWriter.close();
		}
	}
	
	public String exportToPDF() throws Exception {
		initializeDocument();
		generateInvoices();
		closeDocument();
		return "export/" + this.fileName;
	}
	
	private void generateInvoices() throws Exception {
		for (int i = 0; i < this.invoices.size(); i++) {
			InvoiceDef invoice = this.invoices.get(i);
			generateInvoice(invoice);
			if (i < this.invoices.size() - 1)
				this.doc.newPage();
		}
	}
	
	protected void drawText(float x, float y, float rotation, String text, BaseFont baseFont, Integer fontSize, BaseColor baseColor, int alignement) throws Exception {
		text = (text != null) ? text : "";
		this.cb.beginText();
		this.cb.setFontAndSize(baseFont, fontSize.intValue());
		this.cb.setColorFill(baseColor);
		this.cb.showTextAligned(alignement, text, x, y, rotation);
		this.cb.endText();
	}
	
	private void generateInvoice(InvoiceDef invoice) throws Exception {
		BaseColor baseColor = BaseColor.BLACK;
		Float topMargin = Float.valueOf(30.0F);
		Float leftMargin = Float.valueOf(30.0F);
		float firstColumn = (this.pageWidth.intValue() / 5);
		float y = this.pageHeight.intValue() - topMargin.floatValue();
		CurrencyInf baseCurrencuInf = (new InvoicePaymentDao()).getBaseCurrencuInf();
		String currency = (baseCurrencuInf != null) ? baseCurrencuInf.getSymbol() : "LL";
		generateInvoiceLeft(invoice, baseColor, leftMargin, y, currency);
		drawRightColumns(invoice, baseColor, leftMargin, firstColumn, y, currency);
	}
	
	protected void generateLogo(Integer width) throws Exception, DocumentException {
		Image companyLogo = ExportUtils.getLogoImage();
		companyLogo.scaleToFit(width.intValue(), this.pageHeight.intValue());
		companyLogo.scaleAbsolute(width.intValue(), this.pageHeight.intValue());
		companyLogo.setAbsolutePosition((this.pageWidth.intValue() - width.intValue()), -70.0F);
		PdfContentByte canvas = this.docWriter.getDirectContentUnder();
		canvas.saveState();
		PdfGState state = new PdfGState();
		state.setFillOpacity(0.15F);
		canvas.setGState(state);
		canvas.addImage(companyLogo);
		canvas.restoreState();
	}
	
	protected void generateLine(float y, Integer marginWidth) {
		this.cb.moveTo(marginWidth.intValue(), y);
		this.cb.lineTo((this.pageWidth.intValue() - 20), y);
		this.cb.stroke();
	}
	
	private void drawRightColumns(InvoiceDef invoice, BaseColor baseColor, Float leftMargin, float firstColumn, float y, String currency) throws Exception {
		if (invoice.getDisplayFinancialInfoOnInvoice().booleanValue()) {
			generateLogo(Integer.valueOf((new Float(this.pageWidth.intValue() - leftMargin.floatValue() + firstColumn)).intValue()));
		}
		y = generateInvoiceHeader(invoice, baseColor, leftMargin, firstColumn, y, currency);
		generateInvoiceItems(invoice, baseColor, leftMargin, firstColumn, y);
		generateInvoiceFooter(invoice, baseColor, leftMargin, firstColumn, currency);
	}
	
	private float generateInvoiceHeader(InvoiceDef invoice, BaseColor baseColor, Float leftMargin, float firstColumn, float y, String currency) throws Exception {
		drawText(leftMargin.floatValue() + firstColumn, y, 0.0F, "IRADIUS", this.bfBold, Integer.valueOf(18), baseColor, 0);
		drawText((this.pageWidth.intValue() - 20), y, 0.0F, String.valueOf(invoice.getAutoGenerated().booleanValue() ? "Renew On : " : " Date : ") + this.dateFormat.format(invoice.getInvoiceDate()), this.bf, Integer.valueOf(10), baseColor, 2);
		y -= 15.0F;
		if (invoice.getExpiryDate() != null) {
			drawText((this.pageWidth.intValue() - 20), y, 0.0F, "Expiry On : " + this.dateFormat.format(invoice.getExpiryDate()), this.bf, Integer.valueOf(10), baseColor, 2);
			y -= 15.0F;
		}
		drawText(leftMargin.floatValue() + firstColumn, y, 0.0F, this.session.getAddress(), this.bf, Integer.valueOf(9), baseColor, 0);
		drawText((this.pageWidth.intValue() - 20), y - 10.0F, 0.0F, "Invoice " + invoice.getInvoiceNbr(), this.bf, Integer.valueOf(12), baseColor, 2);
		y -= 15.0F;
		drawText(leftMargin.floatValue() + firstColumn, y, 0.0F, "Tel : " + this.session.getPhone(), this.bf, Integer.valueOf(9), baseColor, 0);
		drawText((this.pageWidth.intValue() - 20), y - 10.0F, 0.0F, "Currency " + currency, this.bf, Integer.valueOf(10), baseColor, 2);
		y -= 20.0F;
		drawText(leftMargin.floatValue() + firstColumn, y, 0.0F, "VAT#:" + this.session.getCompanyVatNumber(), this.bf, Integer.valueOf(11), baseColor, 0);
		y -= 30.0F;
		drawText(3.0F * firstColumn - 50.0F, y + 25.0F, 0.0F, "Cash Sales", this.bfBold, Integer.valueOf(14), baseColor, 0);
		if (invoice.getAccountType() != null) {
			drawText(leftMargin.floatValue() + firstColumn, y + 5.0F, 0.0F, "Account", this.bfBold, Integer.valueOf(12), baseColor, 0);
			drawText(leftMargin.floatValue() + firstColumn + 60.0F, y + 5.0F, 0.0F, invoice.getAccountType(), this.bf, Integer.valueOf(12), baseColor, 0);
		}
		y -= 10.0F;
		drawText(leftMargin.floatValue() + firstColumn, y, 0.0F, "Bill To", this.bfBold, Integer.valueOf(12), baseColor, 0);
		drawText(leftMargin.floatValue() + firstColumn + 60.0F, y, 0.0F, invoice.getUserFullName(), this.bf, Integer.valueOf(12), baseColor, 0);
		if (invoice.getDisplayFinancialInfoOnInvoice().booleanValue()) {
			y -= 17.0F;
			drawText(leftMargin.floatValue() + firstColumn, y, 0.0F, "MOF", this.bfBold, Integer.valueOf(12), baseColor, 0);
			drawText(leftMargin.floatValue() + firstColumn + 60.0F, y, 0.0F, invoice.getUserMOF(), this.bf, Integer.valueOf(12), baseColor, 0);
		}
		y -= 17.0F;
		drawText(leftMargin.floatValue() + firstColumn, y, 0.0F, "Tel", this.bfBold, Integer.valueOf(12), baseColor, 0);
		drawText(leftMargin.floatValue() + firstColumn + 60.0F, y, 0.0F, invoice.getUserPhone(), this.bf, Integer.valueOf(12), baseColor, 0);
		y -= 17.0F;
		drawText(leftMargin.floatValue() + firstColumn, y, 0.0F, "Address", this.bfBold, Integer.valueOf(12), baseColor, 0);
		drawText(leftMargin.floatValue() + firstColumn + 60.0F, y, 0.0F, invoice.getUserAddress(), this.bf, Integer.valueOf(12), baseColor, 0);
		generateLine(y - 10.0F, Integer.valueOf((new Float(leftMargin.floatValue() + firstColumn)).intValue()));
		return y;
	}
	
	private void generateInvoiceFooter(InvoiceDef invoice, BaseColor baseColor, Float leftMargin, float firstColumn, String currency) throws Exception {
		InvoiceNbrGenerated invoiceNbrGenerated = (InvoiceNbrGenerated) AppContext.getBean("invoiceNbrGenerated");
		Integer dealerId = invoice.getDealerId();
		Float tva = invoiceNbrGenerated.getTva(dealerId);
		Integer vatValue = Integer.valueOf((tva != null) ? (new Float(tva.floatValue())).intValue() : 10);
		float y = 20.0F;
		Integer leftTitleMargin = Integer.valueOf(75);
		drawText((this.pageWidth.intValue() - 20), y, 0.0F, (new StringBuilder(String.valueOf(this.myFormatter.format(invoice.getTtc())))).toString(), this.bfBold, Integer.valueOf(12), baseColor, 2);
		drawText((this.pageWidth.intValue() - leftTitleMargin.intValue()), y, 0.0F, "Net Amount " + currency + " : ", this.bf, Integer.valueOf(12), baseColor, 2);
		if (invoice.getTax() != null && invoice.getTax().doubleValue() > 0.0D) {
			y += 17.0F;
			drawText((this.pageWidth.intValue() - 20), y, 0.0F, this.myFormatter.format(invoice.getTax()), this.bfBold, Integer.valueOf(12), baseColor, 2);
			drawText((this.pageWidth.intValue() - leftTitleMargin.intValue()), y, 0.0F, "Financial Tax " + currency + " : ", this.bf, Integer.valueOf(12), baseColor, 2);
		}
		y += 17.0F;
		drawText((this.pageWidth.intValue() - 20), y, 0.0F, (new StringBuilder(String.valueOf(this.myFormatter.format(invoice.getTva())))).toString(), this.bfBold, Integer.valueOf(12), baseColor, 2);
		drawText((this.pageWidth.intValue() - leftTitleMargin.intValue()), y, 0.0F, "VAT " + vatValue + "% " + currency + " : ", this.bf, Integer.valueOf(12), baseColor, 2);
		y += 17.0F;
		drawText((this.pageWidth.intValue() - 20), y, 0.0F, (new StringBuilder(String.valueOf(this.myFormatter.format(invoice.getDiscount())))).toString(), this.bfBold, Integer.valueOf(12), baseColor, 2);
		drawText((this.pageWidth.intValue() - leftTitleMargin.intValue()), y, 0.0F, "Discount " + currency + " : ", this.bf, Integer.valueOf(12), baseColor, 2);
		y += 17.0F;
		drawText((this.pageWidth.intValue() - 20), y, 0.0F, (new StringBuilder(String.valueOf(this.myFormatter.format(invoice.getTotal())))).toString(), this.bfBold, Integer.valueOf(12), baseColor, 2);
		drawText((this.pageWidth.intValue() - leftTitleMargin.intValue()), y, 0.0F, "Total " + currency + " : ", this.bf, Integer.valueOf(12), baseColor, 2);
	}
	
	private void generateInvoiceLeft(InvoiceDef invoice, BaseColor baseColor, Float leftMargin, float y, String currency) throws Exception {
		leftMargin = Float.valueOf(5.0F);
		drawText(leftMargin.floatValue(), y, 0.0F, "IRADIUS", this.bfBold, Integer.valueOf(18), baseColor, 0);
		y -= 20.0F;
		drawText(leftMargin.floatValue(), y, 0.0F, "Name", this.bf, Integer.valueOf(10), baseColor, 0);
		y -= 15.0F;
		drawText(leftMargin.floatValue(), y, 0.0F, invoice.getUserFullName(), this.bf, Integer.valueOf(10), baseColor, 0);
		y -= 20.0F;
		y -= 20.0F;
		y -= 20.0F;
		if (invoice.getDisplayFinancialInfoOnInvoice().booleanValue()) {
			drawText(leftMargin.floatValue(), y, 0.0F, "MOF : " + invoice.getUserMOF(), this.bf, Integer.valueOf(10), baseColor, 0);
			y -= 50.0F;
		}
		drawText(leftMargin.floatValue(), y, 0.0F, "Invoice # SI-" + invoice.getInvoiceNbr(), this.bf, Integer.valueOf(10), baseColor, 0);
		y = 40.0F;
		drawText(leftMargin.floatValue(), y, 0.0F, "Net Total " + currency + " : ", this.bfBold, Integer.valueOf(10), baseColor, 0);
		y = 25.0F;
		drawText(leftMargin.floatValue(), y, 0.0F, (new StringBuilder(String.valueOf(this.myFormatter.format(invoice.getTtc())))).toString(), this.bfBold, Integer.valueOf(10), baseColor, 0);
	}
	
	private void generateInvoiceItems(InvoiceDef invoice, BaseColor baseColor, Float leftMargin, float firstColumn, float y) throws Exception {
		y -= 25.0F;
		Float oldFirstColumn = Float.valueOf(firstColumn);
		drawText(leftMargin.floatValue() + firstColumn, y, 0.0F, "Description", this.bfBold, Integer.valueOf(12), baseColor, 0);
		drawText(leftMargin.floatValue() + firstColumn + 230.0F, y, 0.0F, "Qty", this.bfBold, Integer.valueOf(12), baseColor, 0);
		drawText(leftMargin.floatValue() + firstColumn + 280.0F, y, 0.0F, "Unit Price", this.bfBold, Integer.valueOf(12), baseColor, 0);
		drawText(leftMargin.floatValue() + firstColumn + 350.0F, y, 0.0F, "Disc", this.bfBold, Integer.valueOf(12), baseColor, 0);
		drawText(leftMargin.floatValue() + firstColumn + 400.0F, y, 0.0F, "Total", this.bfBold, Integer.valueOf(12), baseColor, 0);
		firstColumn = oldFirstColumn.floatValue();
		y -= 20.0F;
		for (InvoiceItem invoiceItem : invoice) {
			String discount = (invoiceItem.getDiscount() != null) ? this.myFormatter.format(invoiceItem.getDiscount()) : "";
			Double total = invoiceItem.getTotal();
			if (invoiceItem.getUnitPrice() == null && (invoiceItem.getQty() == null || invoiceItem.getQty().equals(new Integer(0))) && (total == null || total.equals(new Double(0.0D)))) {
				continue;
			}
			drawText(leftMargin.floatValue() + firstColumn, y, 0.0F, invoiceItem.getDescription(), this.bf, Integer.valueOf(8), baseColor, 0);
			drawText(leftMargin.floatValue() + firstColumn + 230.0F, y, 0.0F, invoiceItem.getQty() + "", this.bf, Integer.valueOf(10), baseColor, 0);
			drawText(leftMargin.floatValue() + firstColumn + 330.0F, y, 0.0F, (new StringBuilder(String.valueOf(this.myFormatter.format(invoiceItem.getUnitPrice())))).toString(), this.bf, Integer.valueOf(10), baseColor, 2);
			drawText(leftMargin.floatValue() + firstColumn + 370.0F, y, 0.0F, discount, this.bf, Integer.valueOf(10), baseColor, 2);
			drawText(leftMargin.floatValue() + firstColumn + 430.0F, y, 0.0F, this.myFormatter.format(total), this.bf, Integer.valueOf(10), baseColor, 2);
			firstColumn = oldFirstColumn.floatValue();
			y -= 15.0F;
		}
	}
}
/*
 * Location:
 * C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server
 * \dao\invoice\export\InvoiceExport.class Java compiler version: 7 (51.0)
 * JD-Core Version: 1.1.3
 */