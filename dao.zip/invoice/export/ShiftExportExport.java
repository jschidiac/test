package me.iradius.server.dao.invoice.export;

import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import me.iradius.server.dao.invoice.InvoicePaymentDao;
import me.iradius.server.dao.invoice.ShiftTransactionManagement;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.invoice.PosInf;
import me.iradius.shared.invoice.curr.CurrenciesInf;
import me.iradius.shared.invoice.curr.CurrencyInf;
import me.iradius.shared.invoice.curr.CurrencyPart;
import me.iradius.shared.invoice.payment.CashPayment;
import me.iradius.shared.invoice.payment.CashPaymentCurrencyPart;
import me.iradius.shared.invoice.payment.CheckPayment;
import me.iradius.shared.invoice.payment.IPaymentType;
import me.iradius.shared.invoice.payment.InvoicePaymentType;
import me.iradius.shared.invoice.payment.PosOpenCloseShiftInf;
import me.iradius.shared.invoice.payment.VisaPayment;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.Session;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfWriter;

public class ShiftExportExport {
	
	//
	class Info {
		
		Integer						id;
		String						user;
		String						note;
		HashMap<Integer, Double>	amounts	= new HashMap<Integer, Double>();
	}
	
	//
	//
	protected static final String	PGET_NBR	= "Page No. ";
	protected static final String	footer1		= "© Copyright Improve Data. All Rights Reserved.";
	protected static final String	CREATOR		= "Joseph Chidiac";
	//
	protected Document				doc;
	protected PdfWriter				docWriter;
	protected PdfContentByte		cb;
	protected Rectangle				page;
	protected Integer				pageHeight;
	protected Integer				pageWidth;
	//
	protected BaseFont				bfBold;
	protected BaseFont				bf;
	protected int					pageNumber	= 0;
	protected int					leftmargin	= 20;
	protected int					rowHeight	= 20;
	//
	protected DateFormat			dateFormat;
	protected RecordSet				recordSet;
	protected String				fileName;
	protected String				pdfFileName;
	//
	//
	protected Session				session;
	protected DecimalFormat			myFormatter;
	protected Integer				pointOfSalesId;
	protected Integer				collectorId;
	protected Integer				toUserId;
	protected Date					shiftDate;
	protected String				posName		= "";
	protected String				toUserName	= "";
	protected String				notes		= "";
	protected String				posShifyTransType;
	//
	//
	//
	private CurrenciesInf			currenciesInf;
	//
	private PosOpenCloseShiftInf	posOpenCloseShiftInf;
	
	//
	//
	//
	//
	public ShiftExportExport(Session session, Integer collectorId, Integer pointOfSalesId, Integer toUserId, String posShifyTransType, Double Amount, Date shiftDate, String notes, PosOpenCloseShiftInf posOpenCloseShiftInf) {
		super();
		//
		//
		this.posOpenCloseShiftInf = posOpenCloseShiftInf;
		//
		this.session = session;
		this.pointOfSalesId = pointOfSalesId;
		this.collectorId = collectorId;
		this.toUserId = toUserId;
		this.shiftDate = shiftDate;
		this.notes = notes;
		this.posShifyTransType = posShifyTransType;
	}
	
	private void initialiseDrawingParameters() throws Exception {
		Integer id = (int) Math.random();
		fileName = "PDF" + id + ExportUtils.PDF;
		this.pdfFileName = ExportUtils.getPDFFileName(fileName);
		//
		this.bfBold = ExportUtils.getBoldBaseFont();
		this.bf = ExportUtils.getBaseFont();
		//
		dateFormat = new SimpleDateFormat("dd MMM yyyy HH:mm:ss");
		//
		DecimalFormatSymbols symbols = new DecimalFormatSymbols();
		symbols.setGroupingSeparator(' ');
		myFormatter = new DecimalFormat("#,###", symbols);
		//
		this.currenciesInf = new InvoicePaymentDao().getCurrenciesInf();
		//
		rowHeight = 17;
		//
	}
	
	private void initializeHeaderInfo() throws Exception {
		String sql = "SELECT UserName From User Where Id = " + toUserId;
		RecordSet recordSet = new QueryEngine().executeSql(sql);
		if (recordSet.size() > 0)
			toUserName = recordSet.get(0).getStringValue("UserName");
		//
		if (pointOfSalesId == null) {
			PosInf posInf = new ShiftTransactionManagement(this.session).ensureOpeningUserShift(collectorId);
			if (posInf != null)
				posName = posInf.getName();
		} else {
			//
			sql = "SELECT Name From PointOfSales Where Id = " + pointOfSalesId;
			recordSet = new QueryEngine().executeSql(sql);
			if (recordSet.size() > 0)
				posName = recordSet.get(0).getStringValue("Name");
		}
		//
		//
	}
	
	private IPaymentType getCashPaymentByCurencyId(ArrayList<IPaymentType> cashPayments, Integer currencyId) {
		for (IPaymentType cashPayment : cashPayments) {
			if (cashPayment.getCurrencyId().equals(currencyId))
				return cashPayment;
		}
		return null;
	}
	
	//
	//
	//
	protected void initializeDocument() throws Exception {
		this.doc = new Document();
		//
		this.docWriter = PdfWriter.getInstance(doc, new FileOutputStream(pdfFileName));
		this.doc.addAuthor(CREATOR);
		this.doc.addCreationDate();
		this.doc.addProducer();
		this.doc.addCreator(CREATOR);
		this.doc.addTitle("");
		this.doc.setPageSize(PageSize.A4);
		//
		this.doc.open();
		//
		//
		this.page = doc.getPageSize();
		this.pageHeight = (int) this.page.getHeight();
		this.pageWidth = (int) this.page.getWidth();
		//
		this.cb = docWriter.getDirectContent();
		//
	}
	
	private void closeDocument() {
		if (doc != null) {
			doc.close();
		}
		//
		if (docWriter != null) {
			docWriter.close();
		}
		//
	}
	
	private void drawLine(float x, float y, float x1, float y1) {
		//
		// cb.setColorStroke(BaseColor.GRAY);
		cb.setLineWidth((float) 0.2);
		//
		cb.moveTo(x, y);
		//
		cb.lineTo(x1, y1);
		//
		cb.stroke();
	}
	
	protected void generateLine(float y, Integer marginWidth) {
		cb.moveTo(marginWidth, y);
		//
		cb.lineTo(this.pageWidth - 20, y);
		//
		cb.stroke();
	}
	
	protected void drawText(float x, float y, float rotation, String text, BaseFont baseFont, Integer fontSize, BaseColor baseColor, int alignement) throws Exception {
		text = text != null ? text : "";
		cb.beginText();
		cb.setFontAndSize(baseFont, fontSize);
		cb.setColorFill(baseColor);
		cb.showTextAligned(alignement, text, x, y, rotation);
		cb.endText();
	}
	
	private int drawHeader() throws Exception {
		int y = this.pageHeight - 20;
		int x = this.leftmargin;
		int z = 80;
		//
		drawText(x, y, 0, "Date", bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawText(x + z, y, 0, dateFormat.format(this.shiftDate), bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		//
		drawText(this.pageWidth - leftmargin, y, 0, "Transaction From / To", bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_RIGHT);
		drawText(this.pageWidth - leftmargin, y - rowHeight, 0, toUserName, bfBold, 10, BaseColor.BLACK, PdfContentByte.ALIGN_RIGHT);
		//
		y -= rowHeight;
		drawText(x, y, 0, "Name", bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawText(x + z, y, 0, session.getFullName(), bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		//
		y -= rowHeight;
		drawText(x, y, 0, "Trans Type", bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawText(x + z, y, 0, posShifyTransType, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		//
		y -= rowHeight;
		drawText(x, y, 0, "Notes", bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawText(x + z, y, 0, notes, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		//
		y -= 2 * rowHeight;
		//
		drawText((this.pageWidth / 2), y, 0, posName, bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_CENTER);
		//
		y -= rowHeight / 2;
		//
		return y;
	}
	
	private int drawCurrency(CurrencyInf currencyInf, CashPayment cashPayment, int x, int y, int currencyWidth) throws Exception {
		//
		y -= rowHeight;
		//
		int cellWidth = currencyWidth / 3;
		//
		drawLine(x, y + (rowHeight - 5), x + 3 * cellWidth, y + (rowHeight - 5));
		//
		drawText(x + 20, y, 0, currencyInf.getSymbol(), bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawLine(x, y + (rowHeight - 5), x, y - 5);
		//
		drawText(x + 20 + cellWidth, y, 0, "Count", bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawLine(x + cellWidth, y + (rowHeight - 5), x + cellWidth, y - 5);
		//
		drawText(x + 20 + 2 * cellWidth, y, 0, "Amount", bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawLine(x + 2 * cellWidth, y + (rowHeight - 5), x + 2 * cellWidth, y - 5);
		//
		drawLine(x + 3 * cellWidth, y + (rowHeight - 5), x + 3 * cellWidth, y - 5);
		//
		drawLine(x, y - 5, x + 3 * cellWidth, y - 5);
		//
		y -= rowHeight;
		//
		//
		Double totalAmount = 0.0;
		for (CurrencyPart currencyPart : currencyInf) {
			//
			CashPaymentCurrencyPart cashPaymentCurrencyPart = cashPayment != null ? cashPayment.getCashPaymentCurrencyPart(currencyPart.getId()) : null;
			//
			int count = cashPaymentCurrencyPart != null ? cashPaymentCurrencyPart.getCount() : 0;
			Double amount = count * currencyPart.getValue();
			totalAmount += amount;
			//
			drawLine(x, y + (rowHeight - 5), x + 3 * cellWidth, y + (rowHeight - 5));
			drawText(x + 20, y, 0, currencyPart.getValue() + "", bf, 10, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			drawLine(x, y + (rowHeight - 5), x, y - 5);
			//
			drawText(x + 20 + cellWidth, y, 0, count + "", bf, 10, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			drawLine(x + cellWidth, y + (rowHeight - 5), x + cellWidth, y - 5);
			//
			drawText(x + 20 + 2 * cellWidth, y, 0, myFormatter.format(amount), bf, 10, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			drawLine(x + 2 * cellWidth, y + (rowHeight - 5), x + 2 * cellWidth, y - 5);
			drawLine(x + 3 * cellWidth, y + (rowHeight - 5), x + 3 * cellWidth, y - 5);
			//
			drawLine(x, y - 5, x + 3 * cellWidth, y - 5);
			//
			y -= rowHeight;
		}
		//
		drawText(x + 20, y, 0, "Total", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawText(x + 20 + 2 * cellWidth, y, 0, myFormatter.format(totalAmount), bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawLine(x + 2 * cellWidth, y + (rowHeight - 5), x + 2 * cellWidth, y - 5);
		drawLine(x + 3 * cellWidth, y + (rowHeight - 5), x + 3 * cellWidth, y - 5);
		drawLine(x + 2 * cellWidth, y - 5, x + 3 * cellWidth, y - 5);
		//
		y -= rowHeight;
		//
		// totalInPosAmount.put(currencyInf.getId(), totalAmount);
		//
		return y;
	}
	
	private int drawCurrencies(int y) throws Exception {
		int minY = 0;
		//
		//
		int x = leftmargin;
		//
		//
		int count = currenciesInf.size();
		int currencyWidth = (this.pageWidth - (4 * leftmargin)) / count;
		//
		ArrayList<IPaymentType> cashPayments = posOpenCloseShiftInf.get(InvoicePaymentType.CASH);
		//
		for (CurrencyInf currencyInf : currenciesInf) {
			//
			IPaymentType cashPayment = getCashPaymentByCurencyId(cashPayments, currencyInf.getId());
			if (cashPayment == null) {
				cashPayment = new CashPayment();
			}
			//
			int currY = drawCurrency(currencyInf, (CashPayment) cashPayment, x, y, currencyWidth);
			minY = minY == 0 ? currY : Math.min(minY, currY);
			//
			x += currencyWidth + 2 * leftmargin;
		}
		//
		return minY;
	}
	
	private int drawVisaAndCheck(int y) throws Exception {
		//
		y -= rowHeight / 2;
		//
		int cellWidth = (this.pageWidth - 2 * leftmargin) / (currenciesInf.size() + 1);
		int x = this.leftmargin + cellWidth;
		//
		for (CurrencyInf currencyInf : currenciesInf) {
			//
			drawLine(x, y + (rowHeight - 5), x + cellWidth, y + (rowHeight - 5));
			//
			drawText(x + 20, y, 0, currencyInf.getSymbol() + "", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			//
			drawLine(x, y + (rowHeight - 5), x, y - 5);
			//
			x += cellWidth;
			//
			drawLine(x, y + (rowHeight - 5), x, y - 5);
		}
		//
		int x1 = this.leftmargin;
		//
		drawLine(x1, y - 5, x, y - 5);
		y -= rowHeight;
		//
		drawText(x1 + 20, y, 0, "Visa", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		int index = 1;
		//
		ArrayList<IPaymentType> visaPayments = posOpenCloseShiftInf.get(InvoicePaymentType.VISA);
		//
		for (CurrencyInf currencyInf : currenciesInf) {
			//
			VisaPayment visaPayment = (VisaPayment) (visaPayments != null ? getCashPaymentByCurencyId(visaPayments, currencyInf.getId()) : null);
			if (visaPayment == null) {
				visaPayment = new VisaPayment();
				visaPayment.setAmount(0.0);
			}
			//
			Double value = visaPayment.getAmount();
			value = value != null ? value : 0.0;
			String strValue = myFormatter.format(value);
			drawText(x1 + index * cellWidth + 20, y, 0, strValue, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			index++;
		}
		//
		drawLine(x1, y - 5, x, y - 5);
		drawLine(x1, y + (rowHeight - 5), x1, y - 5);
		drawLine(x1 + cellWidth, y + (rowHeight - 5), x1 + cellWidth, y - 5);
		drawLine(x1 + 2 * cellWidth, y + (rowHeight - 5), x1 + 2 * cellWidth, y - 5);
		drawLine(x1 + 3 * cellWidth, y + (rowHeight - 5), x1 + 3 * cellWidth, y - 5);
		y -= rowHeight;
		//
		//
		//
		//
		drawLine(x1, y + (rowHeight - 5), x1, y - 5);
		drawText(x1 + 20, y, 0, "Check", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		index = 1;
		ArrayList<IPaymentType> checkPayments = posOpenCloseShiftInf.get(InvoicePaymentType.CHECK);
		//
		for (CurrencyInf currencyInf : currenciesInf) {
			//
			CheckPayment checkPayment = (CheckPayment) (checkPayments != null ? getCashPaymentByCurencyId(checkPayments, currencyInf.getId()) : null);
			if (checkPayment == null) {
				checkPayment = new CheckPayment();
				checkPayment.setAmount(0.0);
			}
			//
			Double value = checkPayment.getAmount();
			value = value != null ? value : 0.0;
			//
			String strValue = myFormatter.format(value);
			drawText(x1 + index * cellWidth + 20, y, 0, strValue, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			index++;
		}
		//
		drawLine(x1, y - 5, x, y - 5);
		drawLine(x1 + cellWidth, y + (rowHeight - 5), x1 + cellWidth, y - 5);
		drawLine(x1 + 2 * cellWidth, y + (rowHeight - 5), x1 + 2 * cellWidth, y - 5);
		drawLine(x1 + 3 * cellWidth, y + (rowHeight - 5), x1 + 3 * cellWidth, y - 5);
		//
		y -= 3 * rowHeight;
		drawText(this.pageWidth - leftmargin - 100, y, 0, "Signature", bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_RIGHT);
		//
		return y;
	}
	
	public String exportToPDF() throws Exception {
		//
		this.initialiseDrawingParameters();
		//
		this.initializeDocument();
		//
		this.initializeHeaderInfo();
		//
		//
		int y = drawHeader();
		//
		y -= 1 * rowHeight;
		//
		y = drawCurrencies(y);
		//
		y -= 2 * rowHeight;
		//
		y = drawVisaAndCheck(y);
		//
		//
		this.closeDocument();
		//
		return ExportUtils.EXPORT_DIR + "/" + fileName;
	}
}
