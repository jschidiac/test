package me.iradius.server.dao.invoice.export;

import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.BaseFont;
import java.io.File;
import me.iradius.server.divers.ServerUtils;



public class ExportUtils
{
  public static final String PDF = ".pdf";
  public static final String EXPORT_DIR = "export";
  public static final String IMG_DIR = "images";
  public static final String LOGO = "1_Primary_logo_on_transparent_256.png";
  
  public static String getPDFFileName(String fileName) {
    String exportFileDir = String.valueOf(ServerUtils.getWebRoot()) + "export" + File.separator;
    File dirfile = new File(exportFileDir);
    boolean direxists = dirfile.exists();
    if (!direxists) {
      direxists = (new File(exportFileDir)).mkdirs();
    }
    
    return String.valueOf(exportFileDir) + fileName;
  }
  
  public static Image getLogoImage() throws Exception {
    String fileName = "images" + File.separator + "1_Primary_logo_on_transparent_256.png";
    byte[] imageBytes = ServerUtils.getByteImageFromFile(fileName);
    Image image = Image.getInstance(imageBytes);
    
    image.setBorder(0);
    return image;
  }
  
  public static BaseFont getBaseFont() {
    try {
      return BaseFont.createFont("Helvetica", "Cp1252", false);
    } catch (Exception exception) {
      
      return null;
    } 
  }
  public static BaseFont getBoldBaseFont() {
    try {
      return BaseFont.createFont("Helvetica-Bold", "Cp1252", false);
    } catch (Exception exception) {
      
      return null;
    } 
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\invoice\export\ExportUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */