package me.iradius.server.dao.invoice.export;

import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import me.iradius.server.dao.invoice.InvoicePaymentDao;
import me.iradius.server.dao.invoice.ShiftTransactionManagement;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.SharedConst;
import me.iradius.shared.invoice.PosInf;
import me.iradius.shared.invoice.curr.CurrenciesInf;
import me.iradius.shared.invoice.curr.CurrencyInf;
import me.iradius.shared.invoice.curr.CurrencyPart;
import me.iradius.shared.invoice.payment.CashPayment;
import me.iradius.shared.invoice.payment.CashPaymentCurrencyPart;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.Session;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfWriter;

public class CloseShiftExportExport {
	
	//
	class Info {
		
		Integer						id;
		String						user;
		String						note;
		HashMap<Integer, Double>	amounts	= new HashMap<Integer, Double>();
	}
	
	//
	//
	protected static final String		PGET_NBR						= "Page No. ";
	protected static final String		footer1							= "© Copyright Improve Data. All Rights Reserved.";
	protected static final String		CREATOR							= "Joseph Chidiac";
	//
	protected Document					doc;
	protected PdfWriter					docWriter;
	protected PdfContentByte			cb;
	protected Rectangle					page;
	protected Integer					pageHeight;
	protected Integer					pageWidth;
	//
	protected BaseFont					bfBold;
	protected BaseFont					bf;
	protected int						pageNumber						= 0;
	protected int						leftmargin						= 20;
	protected int						rowHeight						= 20;
	//
	protected DateFormat				dateFormat;
	protected RecordSet					recordSet;
	protected String					fileName;
	protected String					pdfFileName;
	//
	//
	protected Session					session;
	protected DecimalFormat				myFormatter;
	protected Integer					pointOfSalesId;
	protected Integer					collectorId;
	protected Integer					toUserId;
	protected Date						shiftDate;
	protected String					posName							= "";
	protected String					toUserName						= "";
	//
	//
	private String						startFilterDate;
	private String						endFilterDate;
	//
	private PosInf						posInf;
	//
	private CurrenciesInf				currenciesInf;
	//
	private ArrayList<CashPayment>		analyzedValuesPosCashPayments	= new ArrayList<CashPayment>();
	private ArrayList<Info>				inInfos							= new ArrayList<CloseShiftExportExport.Info>();
	private ArrayList<Info>				outInfos						= new ArrayList<CloseShiftExportExport.Info>();
	//
	private ArrayList<CashPayment>		invoicesCashPayments			= new ArrayList<CashPayment>();
	private ArrayList<CashPayment>		invoicesRefundCashPayments		= new ArrayList<CashPayment>();
	private ArrayList<CashPayment>		openPosCashPayments				= new ArrayList<CashPayment>();
	private ArrayList<CashPayment>		InPosCashPayments				= new ArrayList<CashPayment>();
	private ArrayList<CashPayment>		OutPosCashPayments				= new ArrayList<CashPayment>();
	private ArrayList<CashPayment>		closePosCashPayments			= new ArrayList<CashPayment>();
	//
	private HashMap<Integer, Double>	totalInPosAmount				= new HashMap<Integer, Double>();
	//
	private HashMap<Integer, Double>	visaPayments					= new HashMap<Integer, Double>();
	private HashMap<Integer, Double>	checkPayments					= new HashMap<Integer, Double>();
	//
	private HashMap<Integer, Double>	totalInPos						= new HashMap<Integer, Double>();
	private HashMap<Integer, Double>	totalInvoices					= new HashMap<Integer, Double>();
	private HashMap<Integer, Double>	totalIN							= new HashMap<Integer, Double>();
	private HashMap<Integer, Double>	totalOUT						= new HashMap<Integer, Double>();
	private HashMap<Integer, Double>	totalCloseOUT					= new HashMap<Integer, Double>();
	private HashMap<Integer, Double>	verification					= new HashMap<Integer, Double>();
	
	//
	//
	//
	public CloseShiftExportExport(Session session, Integer pointOfSalesId, Integer collectorId, Integer toUserId, Date shiftDate) throws Exception {
		//
		this.session = session;
		this.pointOfSalesId = pointOfSalesId;
		this.collectorId = collectorId;
		this.toUserId = toUserId;
		this.shiftDate = shiftDate;
		//
		this.posInf = new ShiftTransactionManagement(session).getLastClosedUserShift(collectorId);
		//
		if (this.posInf == null)
			throw new Exception("An Open Shift Is Required For This Operation.");
		//
		//
		String format = "MM/dd/yyyy HH:mm:ss";
		String dbFormat = "%m/%d/%Y %H:%i:%s";
		DateFormat df = new SimpleDateFormat(format);
		String strStartFromDate = df.format(posInf.getStartShiftDate());
		String strEndFromDate = posInf.getEndShiftDate() != null ? df.format(posInf.getEndShiftDate()) : null;
		//
		this.startFilterDate = (" STR_TO_DATE('" + strStartFromDate + "', '" + dbFormat + "' )");
		if (strEndFromDate != null)
			this.endFilterDate = ("STR_TO_DATE('" + strEndFromDate + "',  '" + dbFormat + "' )");
		//
		Integer id = (int) Math.random();
		fileName = "PDF" + id + ExportUtils.PDF;
		this.pdfFileName = ExportUtils.getPDFFileName(fileName);
		//
		this.bfBold = ExportUtils.getBoldBaseFont();
		this.bf = ExportUtils.getBaseFont();
		//
		dateFormat = new SimpleDateFormat("dd MMM yyyy");
		//
		DecimalFormatSymbols symbols = new DecimalFormatSymbols();
		symbols.setGroupingSeparator(' ');
		myFormatter = new DecimalFormat("#,###", symbols);
		//
		this.currenciesInf = new InvoicePaymentDao().getCurrenciesInf();
		//
		rowHeight = 17;
		//
	}
	
	private void initializeValues() {
		for (CurrencyInf currencyInf : currenciesInf) {
			totalInPos.put(currencyInf.getId(), 0.0);
			totalInvoices.put(currencyInf.getId(), 0.0);
			totalIN.put(currencyInf.getId(), 0.0);
			totalOUT.put(currencyInf.getId(), 0.0);
			totalCloseOUT.put(currencyInf.getId(), 0.0);
			verification.put(currencyInf.getId(), 0.0);
			//
			visaPayments.put(currencyInf.getId(), 0.0);
			checkPayments.put(currencyInf.getId(), 0.0);
		}
	}
	
	private void calculateVisaCheck() throws Exception {
		String sql = "SELECT CurrencyId, SUM(IFNULL(CheckPayment.Amount, 0)) AS SUM " //
				+ " FROM CheckPayment " //
				+ " LEFT OUTER JOIN InvoicePayment " //
				+ " ON InvoicePayment.Id = CheckPayment.PaymentId " //
				+ " WHERE InvoicePayment.PointOfSaleId = " + posInf.getId() //
				+ " AND InvoicePayment.PaymentDate  >= " + this.startFilterDate //
				+ ( //
				posInf.getEndShiftDate() != null ? //
				" AND InvoicePayment.PaymentDate  <= " + this.endFilterDate //
						: //
						" AND InvoicePayment.PaymentDate  <= now() " //
				) //
					//
				+ " AND InvoicePayment.CollectorId = " + this.collectorId //
				+ " GROUP BY CurrencyId ";//
		//
		RecordSet recordSet = new QueryEngine().executeSql(sql);
		for (Record record : recordSet) {
			checkPayments.put(record.getIntegerValue("CurrencyId"), record.getDoubleValue("SUM"));
		}
		//
		sql = "SELECT CurrencyId, SUM(IFNULL(VisaPayment.Amount, 0)) AS SUM " //
				+ " FROM VisaPayment " //
				+ " LEFT OUTER JOIN InvoicePayment " //
				+ " ON InvoicePayment.Id = VisaPayment.PaymentId " //
				+ " WHERE InvoicePayment.PointOfSaleId = " + posInf.getId() //
				+ " AND InvoicePayment.PaymentDate  >= " + this.startFilterDate //
				+ ( //
				posInf.getEndShiftDate() != null ? //
				" AND InvoicePayment.PaymentDate  <= " + this.endFilterDate //
						: //
						" AND InvoicePayment.PaymentDate  <= now() " //
				) //
					//
				+ " AND InvoicePayment.CollectorId = " + this.collectorId //
				+ " GROUP BY CurrencyId ";// ;
		//
		//
		recordSet = new QueryEngine().executeSql(sql);
		for (Record record : recordSet) {
			visaPayments.put(record.getIntegerValue("CurrencyId"), record.getDoubleValue("SUM"));
		}
	}
	
	private CashPayment getCashPaymentByCurencyId(ArrayList<CashPayment> cashPayments, Integer currencyId) {
		for (CashPayment cashPayment : cashPayments) {
			if (cashPayment.getCurrencyId().equals(currencyId))
				return cashPayment;
		}
		return null;
	}
	
	//
	private void calculateInvoicePaymentCurrencyParts() throws Exception {
		//
		//
		String sql = "SELECT CashPayment.CurrencyId, CurrencyPartId, SUM(IFNULL(Count, 0)) AS CNT " //
				+ " FROM CashPaymentCurrencyPart " //
				+ " LEFT OUTER JOIN CashPayment " //
				+ " ON CashPayment.Id = CashPaymentCurrencyPart.CashPaymentId " //
				+ " LEFT OUTER JOIN InvoicePayment " //
				+ " ON InvoicePayment.Id = CashPayment.PaymentId " //
				+ " WHERE InvoicePayment.PointOfSaleId = " + posInf.getId() //
				+ " AND (CashPaymentCurrencyPart.IsRefund IS NULL OR CashPaymentCurrencyPart.IsRefund = 0) AND " //
				+ "  InvoicePayment.PaymentDate  >= " + this.startFilterDate //
				+ ( //
				posInf.getEndShiftDate() != null ? //
				" AND InvoicePayment.PaymentDate  <= " + this.endFilterDate //
						: //
						" AND InvoicePayment.PaymentDate  <= now() " //
				) //
					//
				+ " AND InvoicePayment.CollectorId = " + this.collectorId //
				+ " GROUP BY CashPayment.CurrencyId, CurrencyPartId ";
		//
		//
		RecordSet recordSet = new QueryEngine().executeSql(sql);
		for (Record record : recordSet) {
			Integer CurrencyId = record.getIntegerValue("CurrencyId");
			Integer CurrencyPartId = record.getIntegerValue("CurrencyPartId");
			Integer CNT = record.getIntegerValue("CNT");
			//
			CashPayment cashPayment = getCashPaymentByCurencyId(invoicesCashPayments, CurrencyId);
			if (cashPayment == null) {
				cashPayment = new CashPayment();
				cashPayment.setCurrencyId(CurrencyId);
				invoicesCashPayments.add(cashPayment);
			}
			//
			CashPaymentCurrencyPart currencyPart = cashPayment.getCashPaymentCurrencyPart(CurrencyPartId);
			if (currencyPart == null) {
				currencyPart = new CashPaymentCurrencyPart();
				currencyPart.setCurrencyPartId(CurrencyPartId);
				cashPayment.add(currencyPart);
			}
			currencyPart.setCount(CNT);
		}
		//
		//
		sql = "SELECT CashPayment.CurrencyId, CurrencyPartId, SUM(IFNULL(Count, 0)) AS CNT " //
				+ " FROM CashPaymentCurrencyPart " //
				+ " LEFT OUTER JOIN CashPayment " //
				+ " ON CashPayment.Id = CashPaymentCurrencyPart.CashPaymentId " //
				+ " LEFT OUTER JOIN InvoicePayment " //
				+ " ON InvoicePayment.Id = CashPayment.PaymentId " //
				+ " WHERE InvoicePayment.PointOfSaleId = " + posInf.getId() //
				+ " AND (  CashPaymentCurrencyPart.IsRefund = 1) AND " //
				+ "  InvoicePayment.PaymentDate  >= " + this.startFilterDate //
				+ ( //
				posInf.getEndShiftDate() != null ? //
				" AND InvoicePayment.PaymentDate  <= " + this.endFilterDate //
						: //
						" AND InvoicePayment.PaymentDate  <= now() " //
				) //
					//
				+ " AND InvoicePayment.CollectorId = " + this.collectorId //
				+ " GROUP BY CashPayment.CurrencyId, CurrencyPartId ";
		//
		//
		recordSet = new QueryEngine().executeSql(sql);
		for (Record record : recordSet) {
			Integer CurrencyId = record.getIntegerValue("CurrencyId");
			Integer CurrencyPartId = record.getIntegerValue("CurrencyPartId");
			Integer CNT = record.getIntegerValue("CNT");
			//
			CashPayment cashPayment = getCashPaymentByCurencyId(invoicesRefundCashPayments, CurrencyId);
			if (cashPayment == null) {
				cashPayment = new CashPayment();
				cashPayment.setCurrencyId(CurrencyId);
				invoicesRefundCashPayments.add(cashPayment);
			}
			//
			CashPaymentCurrencyPart currencyPart = cashPayment.getCashPaymentCurrencyPart(CurrencyPartId);
			if (currencyPart == null) {
				currencyPart = new CashPaymentCurrencyPart();
				currencyPart.setCurrencyPartId(CurrencyPartId);
				cashPayment.add(currencyPart);
			}
			currencyPart.setCount(CNT);
		}
	}
	
	private void calculateTransactionsPaymentCurrencyParts() throws Exception {
		String sql = "SELECT PosShifyTransType.Guid, CashOpenCloseShift.CurrencyId, CurrencyPartId ," //
				+ " PointOfSaleShiftTransaction.Id, PointOfSaleShiftTransaction.Notes, concat(User.firstName , \" \",  IFNULL( User.LastName,\"\" ) ) as Name , " + " SUM(IFNULL(Count, 0)) as CNT " //
				+ " FROM CashOpenCloseShiftCurrencyPart " //
				+ " LEFT OUTER JOIN CashOpenCloseShift  ON CashOpenCloseShift.Id =  CashOpenCloseShiftCurrencyPart.CashOpenCloseShiftId " //
				+ " LEFT OUTER JOIN PointOfSaleShiftTransaction  ON PointOfSaleShiftTransaction.Id = CashOpenCloseShift.PointOfSaleShiftTransactionId " //
				+ " LEFT OUTER JOIN User on User.Id = PointOfSaleShiftTransaction.TransUserId " //
				+ " LEFT OUTER JOIN PosShifyTransType on PosShifyTransType.Id = PointOfSaleShiftTransaction.PosShifyTransTypeId " //
				+ " LEFT OUTER JOIN PointOfSaleShift ON PointOfSaleShift.Id =  PointOfSaleShiftTransaction.PointOfSaleShiftId " //
				+ "WHERE PointOfSaleShift.UserId = " + this.collectorId //
				+ " AND PointOfSaleShift.Id = " + posInf.getPointOfSaleShiftId() //
				+ " GROUP BY PosShifyTransType.Id, CashOpenCloseShift.CurrencyId,  CurrencyPartId ";
		// /
		//
		//
		//
		RecordSet recordSet = new QueryEngine().executeSql(sql);
		for (Record record : recordSet) {
			Integer CurrencyId = record.getIntegerValue("CurrencyId");
			Integer CurrencyPartId = record.getIntegerValue("CurrencyPartId");
			Integer CNT = record.getIntegerValue("CNT");
			//
			Integer transId = record.getIntegerValue("Id");
			String user = record.getStringValue("Name");
			String note = record.getStringValue("Notes");
			//
			String guid = record.getStringValue("Guid");
			//
			ArrayList<CashPayment> cashPayments = null;
			if (SharedConst.OPEN_SHIFT_TRANSACTION_TYPE.equals(guid)) {
				cashPayments = openPosCashPayments;
			} else if (SharedConst.IN_SHIFT_TRANSACTION_TYPE.equals(guid)) {
				cashPayments = InPosCashPayments;
				//
				addTransactionInfo(inInfos, CurrencyId, CurrencyPartId, CNT, transId, user, note);
			} else if (SharedConst.OUT_SHIFT_TRANSACTION_TYPE.equals(guid)) {
				cashPayments = OutPosCashPayments;
				//
				addTransactionInfo(outInfos, CurrencyId, CurrencyPartId, CNT, transId, user, note);
			} else if (SharedConst.CLOSE_SHIFT_TRANSACTION_TYPE.equals(guid)) {
				cashPayments = closePosCashPayments;
			}
			if (cashPayments != null) {
				//
				//
				CashPayment cashPayment = getCashPaymentByCurencyId(cashPayments, CurrencyId);
				if (cashPayment == null) {
					cashPayment = new CashPayment();
					cashPayment.setCurrencyId(CurrencyId);
					cashPayments.add(cashPayment);
				}
				//
				CashPaymentCurrencyPart currencyPart = cashPayment.getCashPaymentCurrencyPart(CurrencyPartId);
				if (currencyPart == null) {
					currencyPart = new CashPaymentCurrencyPart();
					currencyPart.setCurrencyPartId(CurrencyPartId);
					cashPayment.add(currencyPart);
					currencyPart.setCount(CNT);
				} else {
					Integer cntValue = currencyPart.getCount();
					cntValue = cntValue != null ? cntValue : 0;
					cntValue += CNT;
					currencyPart.setCount(cntValue);
				}
			}
		}
	}
	
	private void addTransactionInfo(ArrayList<Info> infos, Integer currencyId, Integer currencyPartId, Integer cNT, Integer transId, String user, String note) {
		//
		cNT = cNT != null ? cNT : 0;
		//
		Info info = null;
		for (Info info2 : infos) {
			if (info2.id.equals(transId)) {
				info = info2;
				break;
			}
		}
		//
		if (info == null) {
			info = new Info();
			info.id = transId;
			infos.add(info);
		}
		//
		//
		CurrencyInf currencyInf = currenciesInf.getCurrencyById(currencyId);
		CurrencyPart currencyPart = currencyInf.getCurrencyPartById(currencyPartId);
		Double newAmount = cNT * currencyPart.getValue();
		//
		newAmount = newAmount != null ? newAmount : 0.0;
		info.note = note;
		info.user = user;
		//
		Double amount = info.amounts.get(currencyId);
		if (amount == null) {
			info.amounts.put(currencyId, newAmount);
		} else {
			amount += newAmount;
			info.amounts.put(currencyId, amount);
		}
	}
	
	private void analyzedValuesPosCashPayments() {
		//
		for (CashPayment cashPayment : invoicesCashPayments) {
			CashPayment newCashPayment = cashPayment.cloneCashPayment();
			analyzedValuesPosCashPayments.add(newCashPayment);
			//
			Double value = totalInvoices.get(cashPayment.getCurrencyId());
			value = value != null ? value : 0.0;
			value += cashPayment.calculateAmount(currenciesInf);
			totalInvoices.put(cashPayment.getCurrencyId(), value);
			//
			//
		}
		//
		//
		for (CashPayment cashPayment : invoicesRefundCashPayments) {
			//
			CashPayment existingCashPayment = getCashPaymentByCurencyId(analyzedValuesPosCashPayments, cashPayment.getCurrencyId());
			//
			if (existingCashPayment == null) {
				existingCashPayment = cashPayment.cloneCashPayment();
				existingCashPayment.minusAllCounter();
				analyzedValuesPosCashPayments.add(existingCashPayment);
			} else {
				existingCashPayment.decrementCurrencyPart(cashPayment);
			}
			//
			//
			Double value = totalInvoices.get(cashPayment.getCurrencyId());
			value = value != null ? value : 0.0;
			value -= cashPayment.calculateAmount(currenciesInf);
			totalInvoices.put(cashPayment.getCurrencyId(), value);
			//
		}
		//
		for (CashPayment cashPayment : openPosCashPayments) {
			//
			CashPayment existingCashPayment = getCashPaymentByCurencyId(analyzedValuesPosCashPayments, cashPayment.getCurrencyId());
			//
			if (existingCashPayment == null) {
				existingCashPayment = cashPayment.cloneCashPayment();
				analyzedValuesPosCashPayments.add(existingCashPayment);
			} else {
				existingCashPayment.incrementCurrencyPart(cashPayment);
			}
			//
			//
			//
			Double value = totalInPos.get(cashPayment.getCurrencyId());
			value = value != null ? value : 0.0;
			value += cashPayment.calculateAmount(currenciesInf);
			totalInPos.put(cashPayment.getCurrencyId(), value);
			//
		}
		//
		//
		for (CashPayment cashPayment : InPosCashPayments) {
			//
			CashPayment existingCashPayment = getCashPaymentByCurencyId(analyzedValuesPosCashPayments, cashPayment.getCurrencyId());
			//
			if (existingCashPayment == null) {
				existingCashPayment = cashPayment.cloneCashPayment();
				analyzedValuesPosCashPayments.add(existingCashPayment);
			} else {
				existingCashPayment.incrementCurrencyPart(cashPayment);
			}
			//
			//
			Double value = totalIN.get(cashPayment.getCurrencyId());
			value = value != null ? value : 0.0;
			value += cashPayment.calculateAmount(currenciesInf);
			totalIN.put(cashPayment.getCurrencyId(), value);
			//
		}
		//
		for (CashPayment cashPayment : OutPosCashPayments) {
			//
			CashPayment existingCashPayment = getCashPaymentByCurencyId(analyzedValuesPosCashPayments, cashPayment.getCurrencyId());
			//
			if (existingCashPayment == null) {
				existingCashPayment = cashPayment.cloneCashPayment();
				existingCashPayment.minusAllCounter();
				analyzedValuesPosCashPayments.add(existingCashPayment);
			} else {
				existingCashPayment.decrementCurrencyPart(cashPayment);
			}
			//
			//
			Double value = totalOUT.get(cashPayment.getCurrencyId());
			value = value != null ? value : 0.0;
			value += cashPayment.calculateAmount(currenciesInf);
			totalOUT.put(cashPayment.getCurrencyId(), value);
			//
		}
		//
		//
		for (CashPayment cashPayment : closePosCashPayments) {
			//
			//
			Double value = totalCloseOUT.get(cashPayment.getCurrencyId());
			value = value != null ? value : 0.0;
			value += cashPayment.calculateAmount(currenciesInf);
			totalCloseOUT.put(cashPayment.getCurrencyId(), value);
			//
		}
		//
		//
		//
		//
		for (CurrencyInf currencyInf : currenciesInf) {
			Double remainingValue = 0.0;
			Integer id = currencyInf.getId();
			//
			remainingValue = totalInPos.get(id);
			remainingValue += totalInvoices.get(id);
			remainingValue += totalIN.get(id);
			remainingValue -= totalOUT.get(id);
			//
			//
			verification.put(id, remainingValue);
			//
		}
	}
	
	//
	//
	protected void initializeDocument() throws Exception {
		this.doc = new Document();
		//
		this.docWriter = PdfWriter.getInstance(doc, new FileOutputStream(pdfFileName));
		this.doc.addAuthor(CREATOR);
		this.doc.addCreationDate();
		this.doc.addProducer();
		this.doc.addCreator(CREATOR);
		this.doc.addTitle("");
		this.doc.setPageSize(PageSize.A4);
		//
		this.doc.open();
		//
		//
		this.page = doc.getPageSize();
		this.pageHeight = (int) this.page.getHeight();
		this.pageWidth = (int) this.page.getWidth();
		//
		this.cb = docWriter.getDirectContent();
		//
	}
	
	private void closeDocument() {
		if (doc != null) {
			doc.close();
		}
		//
		if (docWriter != null) {
			docWriter.close();
		}
		//
	}
	
	private void drawLine(float x, float y, float x1, float y1) {
		//
		//
		cb.setLineWidth((float) 0.2);
		//
		cb.moveTo(x, y);
		//
		cb.lineTo(x1, y1);
		//
		cb.stroke();
	}
	
	protected void generateLine(float y, Integer marginWidth) {
		cb.moveTo(marginWidth, y);
		//
		cb.lineTo(this.pageWidth - 20, y);
		//
		cb.stroke();
	}
	
	protected void drawText(float x, float y, float rotation, String text, BaseFont baseFont, Integer fontSize, BaseColor baseColor, int alignement) throws Exception {
		text = text != null ? text : "";
		cb.beginText();
		cb.setFontAndSize(baseFont, fontSize);
		cb.setColorFill(baseColor);
		cb.showTextAligned(alignement, text, x, y, rotation);
		cb.endText();
	}
	
	private int drawHeader() throws Exception {
		int y = this.pageHeight - 20;
		int x = this.leftmargin;
		int z = 75;
		//
		drawText(x, y, 0, "Date", bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawText(x + z, y, 0, dateFormat.format(this.shiftDate), bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		//
		drawText(this.pageWidth - leftmargin, y, 0, "Validate By", bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_RIGHT);
		drawText(this.pageWidth - leftmargin, y - rowHeight, 0, toUserName, bfBold, 10, BaseColor.BLACK, PdfContentByte.ALIGN_RIGHT);
		//
		y -= rowHeight;
		drawText(x, y, 0, "Name", bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawText(x + z, y, 0, session.getFullName(), bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		//
		y -= rowHeight;
		drawText(x, y, 0, "Signature", bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		//
		drawText((this.pageWidth / 2), y, 0, posName, bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_CENTER);
		//
		y -= rowHeight / 2;
		//
		return y;
	}
	
	private int drawCurrency(CurrencyInf currencyInf, CashPayment cashPayment, int x, int y, int currencyWidth) throws Exception {
		//
		y -= rowHeight;
		//
		int cellWidth = currencyWidth / 3;
		//
		drawLine(x, y + (rowHeight - 5), x + 3 * cellWidth, y + (rowHeight - 5));
		//
		drawText(x + 20, y, 0, currencyInf.getSymbol(), bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawLine(x, y + (rowHeight - 5), x, y - 5);
		//
		drawText(x + 20 + cellWidth, y, 0, "Count", bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawLine(x + cellWidth, y + (rowHeight - 5), x + cellWidth, y - 5);
		//
		drawText(x + 20 + 2 * cellWidth, y, 0, "Amount", bfBold, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawLine(x + 2 * cellWidth, y + (rowHeight - 5), x + 2 * cellWidth, y - 5);
		//
		drawLine(x + 3 * cellWidth, y + (rowHeight - 5), x + 3 * cellWidth, y - 5);
		//
		drawLine(x, y - 5, x + 3 * cellWidth, y - 5);
		//
		y -= rowHeight;
		//
		//
		Double totalAmount = 0.0;
		for (CurrencyPart currencyPart : currencyInf) {
			//
			CashPaymentCurrencyPart cashPaymentCurrencyPart = cashPayment != null ? cashPayment.getCashPaymentCurrencyPart(currencyPart.getId()) : null;
			//
			int count = cashPaymentCurrencyPart != null ? cashPaymentCurrencyPart.getCount() : 0;
			Double amount = count * currencyPart.getValue();
			totalAmount += amount;
			//
			drawLine(x, y + (rowHeight - 5), x + 3 * cellWidth, y + (rowHeight - 5));
			drawText(x + 20, y, 0, currencyPart.getValue() + "", bf, 10, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			drawLine(x, y + (rowHeight - 5), x, y - 5);
			//
			drawText(x + 20 + cellWidth, y, 0, count + "", bf, 10, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			drawLine(x + cellWidth, y + (rowHeight - 5), x + cellWidth, y - 5);
			//
			drawText(x + 20 + 2 * cellWidth, y, 0, myFormatter.format(amount), bf, 10, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			drawLine(x + 2 * cellWidth, y + (rowHeight - 5), x + 2 * cellWidth, y - 5);
			drawLine(x + 3 * cellWidth, y + (rowHeight - 5), x + 3 * cellWidth, y - 5);
			//
			drawLine(x, y - 5, x + 3 * cellWidth, y - 5);
			//
			y -= rowHeight;
		}
		//
		drawText(x + 20, y, 0, "Total", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawText(x + 20 + 2 * cellWidth, y, 0, myFormatter.format(totalAmount), bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawLine(x + 2 * cellWidth, y + (rowHeight - 5), x + 2 * cellWidth, y - 5);
		drawLine(x + 3 * cellWidth, y + (rowHeight - 5), x + 3 * cellWidth, y - 5);
		drawLine(x + 2 * cellWidth, y - 5, x + 3 * cellWidth, y - 5);
		//
		y -= rowHeight;
		//
		totalInPosAmount.put(currencyInf.getId(), totalAmount);
		//
		return y;
	}
	
	private int drawCurrencies(int y) throws Exception {
		int minY = 0;
		//
		//
		int x = leftmargin;
		//
		//
		int count = currenciesInf.size();
		int currencyWidth = (this.pageWidth - (4 * leftmargin)) / count;
		//
		//
		for (CurrencyInf currencyInf : currenciesInf) {
			//
			CashPayment cashPayment = getCashPaymentByCurencyId(analyzedValuesPosCashPayments, currencyInf.getId());
			//
			int currY = drawCurrency(currencyInf, cashPayment, x, y, currencyWidth);
			minY = minY == 0 ? currY : Math.min(minY, currY);
			//
			x += currencyWidth + 2 * leftmargin;
		}
		//
		return minY;
	}
	
	private int drawVisaAndCheck(int y) throws Exception {
		//
		y -= rowHeight / 2;
		//
		int cellWidth = (this.pageWidth - 2 * leftmargin) / (currenciesInf.size() + 1);
		int x = this.leftmargin + cellWidth;
		//
		for (CurrencyInf currencyInf : currenciesInf) {
			//
			drawLine(x, y + (rowHeight - 5), x + cellWidth, y + (rowHeight - 5));
			//
			drawText(x + 20, y, 0, currencyInf.getSymbol() + "", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			//
			drawLine(x, y + (rowHeight - 5), x, y - 5);
			//
			x += cellWidth;
			//
			drawLine(x, y + (rowHeight - 5), x, y - 5);
		}
		//
		int x1 = this.leftmargin;
		//
		drawLine(x1, y - 5, x, y - 5);
		y -= rowHeight;
		//
		drawText(x1 + 20, y, 0, "Visa", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		int index = 1;
		for (CurrencyInf currencyInf : currenciesInf) {
			Double value = visaPayments.get(currencyInf.getId());
			String strValue = myFormatter.format(value);
			drawText(x1 + index * cellWidth + 20, y, 0, strValue, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			index++;
		}
		//
		drawLine(x1, y - 5, x, y - 5);
		drawLine(x1, y + (rowHeight - 5), x1, y - 5);
		drawLine(x1 + cellWidth, y + (rowHeight - 5), x1 + cellWidth, y - 5);
		drawLine(x1 + 2 * cellWidth, y + (rowHeight - 5), x1 + 2 * cellWidth, y - 5);
		drawLine(x1 + 3 * cellWidth, y + (rowHeight - 5), x1 + 3 * cellWidth, y - 5);
		y -= rowHeight;
		//
		//
		//
		//
		drawLine(x1, y + (rowHeight - 5), x1, y - 5);
		drawText(x1 + 20, y, 0, "Check", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		index = 1;
		for (CurrencyInf currencyInf : currenciesInf) {
			Double value = checkPayments.get(currencyInf.getId());
			String strValue = myFormatter.format(value);
			drawText(x1 + index * cellWidth + 20, y, 0, strValue, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			index++;
		}
		//
		drawLine(x1, y - 5, x, y - 5);
		drawLine(x1 + cellWidth, y + (rowHeight - 5), x1 + cellWidth, y - 5);
		drawLine(x1 + 2 * cellWidth, y + (rowHeight - 5), x1 + 2 * cellWidth, y - 5);
		drawLine(x1 + 3 * cellWidth, y + (rowHeight - 5), x1 + 3 * cellWidth, y - 5);
		y -= rowHeight / 2;
		//
		//
		return y;
	}
	
	private int drawIn(int y) throws Exception {
		y -= rowHeight;
		//
		int currencyWidth = 70;
		int firstWidth = 120;
		int notesWidth = (this.pageWidth - 2 * leftmargin) - currenciesInf.size() * currencyWidth - firstWidth;
		int x = this.leftmargin;
		//
		drawText(x + 20, y, 0, "IN", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawLine(x, y + (rowHeight - 5), x, y - 5);
		drawLine(x, y + (rowHeight - 5), x + firstWidth, y + (rowHeight - 5));
		x += firstWidth;
		//
		drawText(x + 20, y, 0, "Notes", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawLine(x, y + (rowHeight - 5), x, y - 5);
		drawLine(x, y + (rowHeight - 5), x + notesWidth, y + (rowHeight - 5));
		x += notesWidth;
		//
		//
		for (CurrencyInf currencyInf : currenciesInf) {
			drawText(x + 20, y, 0, currencyInf.getSymbol() + "", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			drawLine(x, y + (rowHeight - 5), x + currencyWidth, y + (rowHeight - 5));
			drawLine(x, y + (rowHeight - 5), x, y - 5);
			//
			x += currencyWidth;
		}
		drawLine(x, y + (rowHeight - 5), x, y - 5);
		//
		int x1 = this.leftmargin;
		//
		drawLine(x1, y - 5, x, y - 5);
		//
		y -= rowHeight;
		//
		//
		//
		HashMap<Integer, Double> amounts = new HashMap<Integer, Double>();
		//
		//
		for (Info info : inInfos) {
			//
			x = x1;
			drawText(x + 20, y, 0, info.user, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			drawLine(x, y + (rowHeight - 5), x, y - 5);
			drawLine(x, y + (rowHeight - 5), x + firstWidth, y + (rowHeight - 5));
			x += firstWidth;
			//
			drawText(x + 20, y, 0, info.note, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			drawLine(x, y + (rowHeight - 5), x, y - 5);
			drawLine(x, y + (rowHeight - 5), x + notesWidth, y + (rowHeight - 5));
			x += notesWidth;
			//
			for (CurrencyInf currencyInf : currenciesInf) {
				//
				Double value = info.amounts.get(currencyInf.getId());
				value = value != null ? value : 0.0;
				//
				//
				if (amounts.containsKey(currencyInf.getId())) {
					amounts.put(currencyInf.getId(), amounts.get(currencyInf.getId()) + value);
				} else {
					amounts.put(currencyInf.getId(), value);
				}
				//
				drawText(x + currencyWidth / 2, y, 0, myFormatter.format(value), bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_CENTER);
				drawLine(x, y + (rowHeight - 5), x + currencyWidth, y + (rowHeight - 5));
				drawLine(x, y + (rowHeight - 5), x, y - 5);
				//
				x += currencyWidth;
			}
			drawLine(x, y + (rowHeight - 5), x, y - 5);
			//
			x1 = this.leftmargin;
			drawLine(x1, y - 5, x, y - 5);
			y -= rowHeight;
			//
		}
		//
		//
		x = x1;
		drawText(x + 20, y, 0, "", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawLine(x, y + (rowHeight - 5), x, y - 5);
		drawLine(x, y + (rowHeight - 5), x + firstWidth, y + (rowHeight - 5));
		x += firstWidth;
		//
		drawText(x + notesWidth - 50, y, 0, "Total", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		// drawLine(x, y + ( rowHeight - 5), x, y - 5);
		drawLine(x, y + (rowHeight - 5), x + notesWidth, y + (rowHeight - 5));
		x += notesWidth;
		//
		for (CurrencyInf currencyInf : currenciesInf) {
			Double value = amounts.get(currencyInf.getId());
			value = value != null ? value : 0.0;
			drawText(x + currencyWidth / 2, y, 0, myFormatter.format(value), bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_CENTER);
			drawLine(x, y + (rowHeight - 5), x + currencyWidth, y + (rowHeight - 5));
			drawLine(x, y + (rowHeight - 5), x, y - 5);
			//
			x += currencyWidth;
		}
		drawLine(x, y + (rowHeight - 5), x, y - 5);
		//
		x1 = this.leftmargin;
		drawLine(x1, y - 5, x, y - 5);
		y -= rowHeight / 2;
		//
		//
		//
		return y;
	}
	
	private int drawOut(int y) throws Exception {
		y -= rowHeight;
		//
		int currencyWidth = 70;
		int firstWidth = 120;
		int notesWidth = (this.pageWidth - 2 * leftmargin) - currenciesInf.size() * currencyWidth - firstWidth;
		int x = this.leftmargin;
		//
		drawText(x + 20, y, 0, "OUT", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawLine(x, y + (rowHeight - 5), x, y - 5);
		drawLine(x, y + (rowHeight - 5), x + firstWidth, y + (rowHeight - 5));
		x += firstWidth;
		//
		drawText(x + 20, y, 0, "Notes", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawLine(x, y + (rowHeight - 5), x, y - 5);
		drawLine(x, y + (rowHeight - 5), x + notesWidth, y + (rowHeight - 5));
		x += notesWidth;
		//
		//
		for (CurrencyInf currencyInf : currenciesInf) {
			drawText(x + currencyWidth / 2, y, 0, currencyInf.getSymbol() + "", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_CENTER);
			drawLine(x, y + (rowHeight - 5), x + currencyWidth, y + (rowHeight - 5));
			drawLine(x, y + (rowHeight - 5), x, y - 5);
			//
			x += currencyWidth;
		}
		drawLine(x, y + (rowHeight - 5), x, y - 5);
		//
		int x1 = this.leftmargin;
		drawLine(x1, y - 5, x, y - 5);
		//
		y -= rowHeight;
		//
		//
		//
		HashMap<Integer, Double> amounts = new HashMap<Integer, Double>();
		//
		for (Info info : outInfos) {
			//
			x = x1;
			drawText(x + 20, y, 0, info.user, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			drawLine(x, y + (rowHeight - 5), x, y - 5);
			drawLine(x, y + (rowHeight - 5), x + firstWidth, y + (rowHeight - 5));
			x += firstWidth;
			//
			drawText(x + 20, y, 0, info.note, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			drawLine(x, y + (rowHeight - 5), x, y - 5);
			drawLine(x, y + (rowHeight - 5), x + notesWidth, y + (rowHeight - 5));
			x += notesWidth;
			//
			for (CurrencyInf currencyInf : currenciesInf) {
				//
				Double value = info.amounts.get(currencyInf.getId());
				value = value != null ? value : 0.0;
				//
				if (amounts.containsKey(currencyInf.getId())) {
					amounts.put(currencyInf.getId(), amounts.get(currencyInf.getId()) + value);
				} else {
					amounts.put(currencyInf.getId(), value);
				}
				//
				drawText(x + currencyWidth / 2, y, 0, myFormatter.format(value), bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_CENTER);
				drawLine(x, y + (rowHeight - 5), x + currencyWidth, y + (rowHeight - 5));
				drawLine(x, y + (rowHeight - 5), x, y - 5);
				//
				x += currencyWidth;
			}
			drawLine(x, y + (rowHeight - 5), x, y - 5);
			//
			x1 = this.leftmargin;
			drawLine(x1, y - 5, x, y - 5);
			y -= rowHeight;
			//
			//
			//
		}
		//
		//
		x = x1;
		drawText(x + 20, y, 0, "", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		drawLine(x, y + (rowHeight - 5), x, y - 5);
		drawLine(x, y + (rowHeight - 5), x + firstWidth, y + (rowHeight - 5));
		x += firstWidth;
		//
		drawText(x + notesWidth - 50, y, 0, "Total", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		// drawLine(x, y + ( rowHeight - 5), x, y - 5);
		drawLine(x, y + (rowHeight - 5), x + notesWidth, y + (rowHeight - 5));
		x += notesWidth;
		//
		for (CurrencyInf currencyInf : currenciesInf) {
			Double value = amounts.get(currencyInf.getId());
			value = value != null ? value : 0.0;
			drawText(x + 20, y, 0, myFormatter.format(value), bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			drawLine(x, y + (rowHeight - 5), x + currencyWidth, y + (rowHeight - 5));
			drawLine(x, y + (rowHeight - 5), x, y - 5);
			//
			x += currencyWidth;
		}
		drawLine(x, y + (rowHeight - 5), x, y - 5);
		//
		x1 = this.leftmargin;
		drawLine(x1, y - 5, x, y - 5);
		y -= rowHeight / 2;
		//
		//
		//
		return y;
	}
	
	private int drawResume(int y) throws Exception {
		//
		y -= rowHeight;
		//
		int cellWidth = (this.pageWidth - 2 * leftmargin) / (currenciesInf.size() + 1);
		int x = this.leftmargin + cellWidth;
		//
		for (CurrencyInf currencyInf : currenciesInf) {
			//
			drawLine(x, y + (rowHeight - 5), x + cellWidth, y + (rowHeight - 5));
			//
			drawText(x + 20, y, 0, currencyInf.getSymbol() + "", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			//
			drawLine(x, y + (rowHeight - 5), x, y - 5);
			//
			x += cellWidth;
			//
			drawLine(x, y + (rowHeight - 5), x, y - 5);
		}
		//
		int x1 = this.leftmargin;
		//
		drawLine(x1, y - 5, x, y - 5);
		y -= rowHeight;
		//
		//
		//
		drawText(x1 + 20, y, 0, "In POS", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		int index = 1;
		for (CurrencyInf currencyInf : currenciesInf) {
			Double value = totalInPos.get(currencyInf.getId());
			String strValue = myFormatter.format(value);
			drawText(x1 + index * cellWidth + 20, y, 0, strValue, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			index++;
		}
		//
		drawLine(x1, y - 5, x, y - 5);
		drawLine(x1, y + (rowHeight - 5), x1, y - 5);
		drawLine(x1 + cellWidth, y + (rowHeight - 5), x1 + cellWidth, y - 5);
		drawLine(x1 + 2 * cellWidth, y + (rowHeight - 5), x1 + 2 * cellWidth, y - 5);
		drawLine(x1 + 3 * cellWidth, y + (rowHeight - 5), x1 + 3 * cellWidth, y - 5);
		y -= rowHeight;
		//
		//
		//
		//
		//
		//
		drawLine(x1, y + (rowHeight - 5), x1, y - 5);
		drawText(x1 + 20, y, 0, "Invoices", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		index = 1;
		for (CurrencyInf currencyInf : currenciesInf) {
			Double value = totalInvoices.get(currencyInf.getId());
			String strValue = myFormatter.format(value);
			drawText(x1 + index * cellWidth + 20, y, 0, strValue, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			index++;
		}
		//
		drawLine(x1, y - 5, x, y - 5);
		drawLine(x1 + cellWidth, y + (rowHeight - 5), x1 + cellWidth, y - 5);
		drawLine(x1 + 2 * cellWidth, y + (rowHeight - 5), x1 + 2 * cellWidth, y - 5);
		drawLine(x1 + 3 * cellWidth, y + (rowHeight - 5), x1 + 3 * cellWidth, y - 5);
		y -= rowHeight;
		//
		//
		drawLine(x1, y + (rowHeight - 5), x1, y - 5);
		drawText(x1 + 20, y, 0, "IN", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		index = 1;
		for (CurrencyInf currencyInf : currenciesInf) {
			Double value = totalIN.get(currencyInf.getId());
			String strValue = myFormatter.format(value);
			drawText(x1 + index * cellWidth + 20, y, 0, strValue, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			index++;
		}
		drawLine(x1, y - 5, x, y - 5);
		drawLine(x1 + cellWidth, y + (rowHeight - 5), x1 + cellWidth, y - 5);
		drawLine(x1 + 2 * cellWidth, y + (rowHeight - 5), x1 + 2 * cellWidth, y - 5);
		drawLine(x1 + 3 * cellWidth, y + (rowHeight - 5), x1 + 3 * cellWidth, y - 5);
		y -= rowHeight;
		//
		drawLine(x1, y + (rowHeight - 5), x1, y - 5);
		drawText(x1 + 20, y, 0, "Out", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		index = 1;
		for (CurrencyInf currencyInf : currenciesInf) {
			Double value = totalOUT.get(currencyInf.getId());
			String strValue = myFormatter.format(value);
			drawText(x1 + index * cellWidth + 20, y, 0, strValue, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			index++;
		}
		drawLine(x1, y - 5, x, y - 5);
		drawLine(x1 + cellWidth, y + (rowHeight - 5), x1 + cellWidth, y - 5);
		drawLine(x1 + 2 * cellWidth, y + (rowHeight - 5), x1 + 2 * cellWidth, y - 5);
		drawLine(x1 + 3 * cellWidth, y + (rowHeight - 5), x1 + 3 * cellWidth, y - 5);
		y -= rowHeight;
		//
		//
		//
		//
		drawLine(x1, y + (rowHeight - 5), x1, y - 5);
		drawText(x1 + 20, y, 0, "", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		index = 1;
		for (int i = 0; i < currenciesInf.size(); i++) {
			String strValue = "";
			drawText(x1 + index * cellWidth + 20, y, 0, strValue, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			index++;
		}
		drawLine(x1, y - 5, x, y - 5);
		drawLine(x1 + 3 * cellWidth, y + (rowHeight - 5), x1 + 3 * cellWidth, y - 5);
		y -= rowHeight;
		//
		//
		//
		//
		drawLine(x1, y + (rowHeight - 5), x1, y - 5);
		drawText(x1 + 20, y, 0, "Close POS", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		index = 1;
		for (CurrencyInf currencyInf : currenciesInf) {
			Double value = totalCloseOUT.get(currencyInf.getId());
			String strValue = myFormatter.format(value);
			drawText(x1 + index * cellWidth + 20, y, 0, strValue, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			index++;
		}
		drawLine(x1, y - 5, x, y - 5);
		drawLine(x1 + cellWidth, y + (rowHeight - 5), x1 + cellWidth, y - 5);
		drawLine(x1 + 2 * cellWidth, y + (rowHeight - 5), x1 + 2 * cellWidth, y - 5);
		drawLine(x1 + 3 * cellWidth, y + (rowHeight - 5), x1 + 3 * cellWidth, y - 5);
		y -= rowHeight;
		//
		drawLine(x1, y + (rowHeight - 5), x1, y - 5);
		drawText(x1 + 20, y, 0, "Verification", bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
		index = 1;
		for (CurrencyInf currencyInf : currenciesInf) {
			Double value = verification.get(currencyInf.getId());
			String strValue = myFormatter.format(value);
			drawText(x1 + index * cellWidth + 20, y, 0, strValue, bf, 12, BaseColor.BLACK, PdfContentByte.ALIGN_LEFT);
			index++;
		}
		drawLine(x1, y - 5, x, y - 5);
		drawLine(x1 + cellWidth, y + (rowHeight - 5), x1 + cellWidth, y - 5);
		drawLine(x1 + 2 * cellWidth, y + (rowHeight - 5), x1 + 2 * cellWidth, y - 5);
		drawLine(x1 + 3 * cellWidth, y + (rowHeight - 5), x1 + 3 * cellWidth, y - 5);
		y -= rowHeight;
		return y;
	}
	
	public String exportToPDF() throws Exception {
		//
		this.initializeDocument();
		//
		this.initializeValues();
		//
		this.calculateInvoicePaymentCurrencyParts();
		//
		this.calculateTransactionsPaymentCurrencyParts();
		//
		this.calculateVisaCheck();
		//
		//
		this.analyzedValuesPosCashPayments();
		//
		int y = drawHeader();
		//
		y = drawCurrencies(y);
		//
		y = drawVisaAndCheck(y);
		//
		y = drawIn(y);
		//
		y = drawOut(y);
		//
		drawResume(y);
		//
		this.closeDocument();
		//
		return ExportUtils.EXPORT_DIR + "/" + fileName;
	}
}
