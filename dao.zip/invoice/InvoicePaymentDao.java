package me.iradius.server.dao.invoice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.db.Table;
import me.iradius.shared.invoice.curr.CurrenciesInf;
import me.iradius.shared.invoice.curr.CurrencyInf;
import me.iradius.shared.invoice.curr.CurrencyPart;
import me.iradius.shared.invoice.payment.CashPayment;
import me.iradius.shared.invoice.payment.CashPaymentCurrencyPart;
import me.iradius.shared.invoice.payment.CheckPayment;
import me.iradius.shared.invoice.payment.IPaymentType;
import me.iradius.shared.invoice.payment.InvoicePayment;
import me.iradius.shared.invoice.payment.InvoicePaymentType;
import me.iradius.shared.invoice.payment.RefundCashPayment;
import me.iradius.shared.invoice.payment.VisaPayment;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;

public class InvoicePaymentDao {
	
	private void assignCurrencypart(CurrencyInf currencyInf) throws Exception {
		String sql = "SELECT Id, Value, IsCoins  FROM CurrencyPart  WHERE CurrencyId = " + currencyInf.getId() + " ORDER BY Value DESC ";
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		for (Record record : recordSet) {
			CurrencyPart currencyPart = new CurrencyPart();
			currencyInf.add(currencyPart);
			currencyPart.setId(record.getIntegerValue("Id"));
			currencyPart.setIsCoins(record.getBooleanValue("IsCoins"));
			currencyPart.setValue(record.getDoubleValue("Value"));
		}
	}
	
	public CurrencyInf getBaseCurrencuInf() throws Exception {
		String sql = "SELECT Id, Name, Symbol, RateByBaseCurrency, BaseCurrency  FROM Currency  ORDER BY BaseCurrency DESC ";
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		Iterator<Record> iterator = recordSet.iterator();
		if (iterator.hasNext()) {
			Record record = iterator.next();
			CurrencyInf currencyInf = new CurrencyInf();
			currencyInf.setId(record.getIntegerValue("Id"));
			currencyInf.setName(record.getStringValue("Name"));
			currencyInf.setSymbol(record.getStringValue("Symbol"));
			currencyInf.setBaseCurrency(record.getBooleanValue("BaseCurrency"));
			currencyInf.setRateByBaseCurrency(record.getDoubleValue("RateByBaseCurrency"));
			return currencyInf;
		}
		return null;
	}
	
	public CurrenciesInf getCurrenciesInf() throws Exception {
		CurrenciesInf currenciesInf = new CurrenciesInf();
		String sql = "SELECT Id, Name, Symbol, RateByBaseCurrency, BaseCurrency  FROM Currency  ORDER BY BaseCurrency DESC ";
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		for (Record record : recordSet) {
			CurrencyInf currencyInf = new CurrencyInf();
			currenciesInf.add(currencyInf);
			currencyInf.setId(record.getIntegerValue("Id"));
			currencyInf.setName(record.getStringValue("Name"));
			currencyInf.setSymbol(record.getStringValue("Symbol"));
			currencyInf.setBaseCurrency(record.getBooleanValue("BaseCurrency"));
			currencyInf.setRateByBaseCurrency(record.getDoubleValue("RateByBaseCurrency"));
			assignCurrencypart(currencyInf);
		}
		return currenciesInf;
	}
	
	private void paidTotalInvoice(Integer invoiceId) throws Exception {
		Table table = new Table("Invoice", "Id", Boolean.valueOf(false));
		table.setPkFieldValue(invoiceId);
		table.addFieldValue("Paid", Boolean.valueOf(true));
		(new QueryEngine()).updateData(table);
	}
	
	private void addUserPayment(Integer invoicePaymentId, InvoicePayment invoicePayment) throws Exception {
		Integer invocieId = null;
		if (invoicePayment.getInvoicesId() != null && invoicePayment.getInvoicesId().size() > 0) {
			invocieId = invoicePayment.getInvoicesId().get(0);
		}
		Double receivedMoney = invoicePayment.getReceviedAmount();
		if (invoicePayment.getRefundAmount() != null)
			receivedMoney = Double.valueOf(receivedMoney.doubleValue() - invoicePayment.getRefundAmount().doubleValue());
		String sql = "Insert Into UserBalance (CollectorId, UserId, InvoiceId, InvoicePaymentId, Credit, OperationDate)  VALUES (" + invoicePayment.getCollectorId() + "," + invoicePayment.getUserId() + "," + invocieId + "," + invoicePaymentId + ","
				+ receivedMoney + ", now() )";
		(new QueryEngine()).executeUpdateDelete(sql);
	}
	
	private Integer traceInvoicePayment(Integer pointOfSaleId, InvoicePayment invoicePayment) throws Exception {
		invoicePayment.assignInvoicePaymentValues();
		Table table = new Table("InvoicePayment", "Id", Boolean.valueOf(true));
		table.addFieldValue("CollectorId", invoicePayment.getCollectorId());
		if (invoicePayment.getInvoicesId() != null && invoicePayment.getInvoicesId().size() == 1) {
			table.addFieldValue("InvoiceId", invoicePayment.getInvoicesId().get(0));
		}
		table.addFieldValue("PointOfSaleId", pointOfSaleId);
		table.addFieldValue("UserId", invoicePayment.getUserId());
		table.addFieldValue("PaymentDate", invoicePayment.getPaymentDate());
		table.addFieldValue("Amount", invoicePayment.getAmount());
		table.addFieldValue("ReceivedAmount", invoicePayment.getReceviedAmount());
		table.addFieldValue("RemainingAmount", invoicePayment.getRemainingAmount());
		table.addFieldValue("RefundAmount", invoicePayment.getRefundAmount());
		table.addFieldValue("BalanceBeforePayment", invoicePayment.getBalanceBeforePayment());
		table.addFieldValue("BalanceAfterPayment", invoicePayment.getBalanceAfterPayment());
		return (new QueryEngine()).updateData(table);
	}
	
	private void traceInvoicePaymentType(Integer collectorId, Integer pointOfSaleId, Integer invoicePaymentId, InvoicePaymentType invoicePaymentType, ArrayList<IPaymentType> paymentTypes) throws Exception {
		switch (invoicePaymentType) {
			case VISA:
				traceVisaInvoicePaymentType(invoicePaymentId, paymentTypes);
				break;
			case CHECK:
				traceCheckInvoicePaymentType(invoicePaymentId, paymentTypes);
				break;
			case CASH:
				traceCashInvoicePaymentType(collectorId, pointOfSaleId, invoicePaymentId, paymentTypes);
				break;
			case REFUND:
				traceRefundInvoicePaymentType(collectorId, pointOfSaleId, invoicePaymentId, paymentTypes);
				break;
		}
	}
	
	private void traceRefundInvoicePaymentType(Integer collectorId, Integer pointOfSaleId, Integer invoicePaymentId, ArrayList<IPaymentType> paymentTypes) throws Exception {
		traceCashPaymentType(collectorId, pointOfSaleId, invoicePaymentId, paymentTypes, Boolean.valueOf(true));
	}
	
	private void traceCashInvoicePaymentType(Integer collectorId, Integer pointOfSaleId, Integer invoicePaymentId, ArrayList<IPaymentType> paymentTypes) throws Exception {
		traceCashPaymentType(collectorId, pointOfSaleId, invoicePaymentId, paymentTypes, Boolean.valueOf(false));
	}
	
	private void traceCashPaymentType(Integer collectorId, Integer pointOfSaleId, Integer invoicePaymentId, ArrayList<IPaymentType> paymentTypes, Boolean IsRefund) throws Exception {
		for (IPaymentType paymentType : paymentTypes) {
			CashPayment cashPayment = (CashPayment) paymentType;
			Table table = new Table("CashPayment", "Id", Boolean.valueOf(true));
			table.addFieldValue("PaymentId", invoicePaymentId);
			table.addFieldValue("CurrencyId", cashPayment.getCurrencyId());
			table.addFieldValue("IsRefund", IsRefund);
			table.addFieldValue("Amount", cashPayment.getAmount());
			table.addFieldValue("AmountByBaseCurrency", cashPayment.getAmountByBaseCurrency());
			Integer CashPaymentId = (new QueryEngine()).updateData(table);
			traceCashPaymentCurrencyPart(CashPaymentId, cashPayment, collectorId, pointOfSaleId, IsRefund);
		}
	}
	
	private void traceCashPaymentCurrencyPart(Integer cashPaymentId, CashPayment cashPayment, Integer collectorId, Integer pointOfSaleId, Boolean IsRefund) throws Exception {
		for (CashPaymentCurrencyPart part : cashPayment) {
			Table table = new Table("CashPaymentCurrencyPart", "Id", Boolean.valueOf(true));
			table.addFieldValue("CashPaymentId", cashPaymentId);
			table.addFieldValue("CurrencyPartId", part.getCurrencyPartId());
			table.addFieldValue("Count", part.getCount());
			table.addFieldValue("CollectorId", collectorId);
			table.addFieldValue("PointOfSaleId", pointOfSaleId);
			table.addFieldValue("IsRefund", IsRefund);
			(new QueryEngine()).updateData(table);
		}
	}
	
	private void traceCheckInvoicePaymentType(Integer invoicePaymentId, ArrayList<IPaymentType> paymentTypes) throws Exception {
		for (IPaymentType paymentType : paymentTypes) {
			CheckPayment checkPayment = (CheckPayment) paymentType;
			Table table = new Table("CheckPayment", "Id", Boolean.valueOf(true));
			table.addFieldValue("PaymentId", invoicePaymentId);
			table.addFieldValue("BankName", checkPayment.getBankName());
			table.addFieldValue("CheckNumber", checkPayment.getCheckNumber());
			table.addFieldValue("DueDate", checkPayment.getDueDate());
			table.addFieldValue("CurrencyId", checkPayment.getCurrencyId());
			table.addFieldValue("Amount", checkPayment.getAmount());
			table.addFieldValue("AmountByBaseCurrency", checkPayment.getAmountByBaseCurrency());
			(new QueryEngine()).updateData(table);
		}
	}
	
	private void traceVisaInvoicePaymentType(Integer invoicePaymentId, ArrayList<IPaymentType> paymentTypes) throws Exception {
		for (IPaymentType paymentType : paymentTypes) {
			VisaPayment visaPayment = (VisaPayment) paymentType;
			Table table = new Table("VisaPayment", "Id", Boolean.valueOf(true));
			table.addFieldValue("PaymentId", invoicePaymentId);
			table.addFieldValue("VisaNumber", visaPayment.getVisaNumber());
			table.addFieldValue("ReferenceNumber", visaPayment.getReferenceNumber());
			table.addFieldValue("CurrencyId", visaPayment.getCurrencyId());
			table.addFieldValue("Amount", visaPayment.getAmount());
			table.addFieldValue("AmountByBaseCurrency", visaPayment.getAmountByBaseCurrency());
			(new QueryEngine()).updateData(table);
		}
	}
	
	public void savePayment(InvoicePayment invoicePayment) throws Exception {
		Integer pointOfSaleId = invoicePayment.getPointOfSaleId();
		if (invoicePayment.getPaidInvoiced().booleanValue()) {
			for (Integer invoiceId : invoicePayment.getInvoicesId()) {
				paidTotalInvoice(invoiceId);
			}
		}
		resetOverrideExpiryAccount(invoicePayment);
		Integer invoicePaymentId = traceInvoicePayment(pointOfSaleId, invoicePayment);
		addUserPayment(invoicePaymentId, invoicePayment);
		for (Map.Entry<InvoicePaymentType, ArrayList<IPaymentType>> entry : (Iterable<Map.Entry<InvoicePaymentType, ArrayList<IPaymentType>>>) invoicePayment.entrySet()) {
			traceInvoicePaymentType(invoicePayment.getCollectorId(), pointOfSaleId, invoicePaymentId, entry.getKey(), entry.getValue());
		}
	}
	
	private void resetOverrideExpiryAccount(InvoicePayment invoicePayment) throws Exception {
		String sqlUpdate = "Update UserNas  SET OverrideExpiryAccount = null,  ForceExpiryAfterDays = null  where  UserId = " + invoicePayment.getUserId();
		(new QueryEngine()).delete(sqlUpdate);
	}
	
	public InvoicePayment getInvoicePayment(Integer invoicePaymentId) throws Exception {
		String sql = "SELECT CollectorId,InvoiceId, UserId , PaymentDate, Amount , ReceivedAmount, RemainingAmount, RefundAmount  FROM InvoicePayment  Where Id = " + invoicePaymentId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		Iterator<Record> iterator = recordSet.iterator();
		if (iterator.hasNext()) {
			Record record = iterator.next();
			InvoicePayment invoicePayment = new InvoicePayment();
			invoicePayment.setCollectorId(record.getIntegerValue("CollectorId"));
			Integer invoiceId = record.getIntegerValue("InvoiceId");
			if (invoiceId != null) {
				ArrayList<Integer> invoicesId = new ArrayList<>();
				invoicesId.add(invoiceId);
				invoicePayment.setInvoicesId(invoicesId);
			}
			invoicePayment.setUserId(record.getIntegerValue("UserId"));
			invoicePayment.setPaymentDate(record.getDateValue("PaymentDate"));
			invoicePayment.setAmount(record.getDoubleValue("Amount"));
			invoicePayment.setReceviedAmount(record.getDoubleValue("ReceivedAmount"));
			invoicePayment.setRemainingAmount(record.getDoubleValue("RemainingAmount"));
			invoicePayment.setRefundAmount(record.getDoubleValue("RefundAmount"));
			ArrayList<IPaymentType> visaPayments = new ArrayList<>();
			sql = "SELECT VisaNumber, ReferenceNumber, CurrencyId, Amount, AmountByBaseCurrency  FROM VisaPayment Where PaymentId = " + invoicePaymentId;
			RecordSet visaRecordSet = (new QueryEngine()).executeSql(sql);
			for (Record visaRecord : visaRecordSet) {
				VisaPayment visaPayment = new VisaPayment();
				visaPayment.setVisaNumber(visaRecord.getStringValue("VisaNumber"));
				visaPayment.setReferenceNumber(visaRecord.getStringValue("ReferenceNumber"));
				visaPayment.setCurrencyId(visaRecord.getIntegerValue("CurrencyId"));
				visaPayment.setAmount(visaRecord.getDoubleValue("Amount"));
				visaPayment.setAmountByBaseCurrency(visaRecord.getDoubleValue("AmountByBaseCurrency"));
				visaPayments.add(visaPayment);
			}
			if (visaPayments.size() > 0) {
				invoicePayment.put(InvoicePaymentType.VISA, visaPayments);
			}
			ArrayList<IPaymentType> checkPayments = new ArrayList<>();
			sql = "SELECT BankName, CheckNumber, CurrencyId, DueDate, Amount, AmountByBaseCurrency  FROM CheckPayment Where PaymentId = " + invoicePaymentId;
			RecordSet checkRecordSet = (new QueryEngine()).executeSql(sql);
			for (Record checkRecord : checkRecordSet) {
				CheckPayment checkPayment = new CheckPayment();
				checkPayment.setBankName(checkRecord.getStringValue("BankName"));
				checkPayment.setCheckNumber(checkRecord.getStringValue("CheckNumber"));
				checkPayment.setDueDate(checkRecord.getDateValue("DueDate"));
				checkPayment.setCurrencyId(checkRecord.getIntegerValue("CurrencyId"));
				checkPayment.setAmount(checkRecord.getDoubleValue("Amount"));
				checkPayment.setAmountByBaseCurrency(checkRecord.getDoubleValue("AmountByBaseCurrency"));
				checkPayments.add(checkPayment);
			}
			if (checkPayments.size() > 0) {
				invoicePayment.put(InvoicePaymentType.CHECK, checkPayments);
			}
			ArrayList<IPaymentType> cashPayments = new ArrayList<>();
			ArrayList<IPaymentType> refundPayments = new ArrayList<>();
			sql = "SELECT  Id, CurrencyId, IsRefund, Amount, AmountByBaseCurrency  FROM CashPayment Where PaymentId = " + invoicePaymentId;
			RecordSet cashrecordSet = (new QueryEngine()).executeSql(sql);
			for (Record cashRecord : cashrecordSet) {
				CashPayment cashPayment;
				Boolean IsRefund = cashRecord.getBooleanValue("IsRefund");
				if (IsRefund.booleanValue()) {
					cashPayment = new RefundCashPayment();
					refundPayments.add(cashPayment);
				} else {
					cashPayment = new CashPayment();
					cashPayments.add(cashPayment);
				}
				cashPayment.setCurrencyId(cashRecord.getIntegerValue("CurrencyId"));
				cashPayment.setAmount(cashRecord.getDoubleValue("Amount"));
				cashPayment.setAmountByBaseCurrency(cashRecord.getDoubleValue("AmountByBaseCurrency"));
				Integer cashPaymentid = cashRecord.getIntegerValue("Id");
				sql = "SELECT CurrencyPartId, Count  FROM  CashPaymentCurrencyPart Where CashPaymentId = " + cashPaymentid;
				RecordSet partRecordSet = (new QueryEngine()).executeSql(sql);
				for (Record partRecord : partRecordSet) {
					CashPaymentCurrencyPart cashPaymentCurrencyPart = new CashPaymentCurrencyPart();
					cashPayment.add(cashPaymentCurrencyPart);
					cashPaymentCurrencyPart.setCount(partRecord.getIntegerValue("Count"));
					cashPaymentCurrencyPart.setCurrencyPartId(partRecord.getIntegerValue("CurrencyPartId"));
				}
			}
			if (cashPayments.size() > 0) {
				invoicePayment.put(InvoicePaymentType.CASH, cashPayments);
			}
			if (refundPayments.size() > 0) {
				invoicePayment.put(InvoicePaymentType.REFUND, refundPayments);
			}
			return invoicePayment;
		}
		return null;
	}
}
/*
 * Location:
 * C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server
 * \dao\invoice\InvoicePaymentDao.class Java compiler version: 7 (51.0) JD-Core
 * Version: 1.1.3
 */