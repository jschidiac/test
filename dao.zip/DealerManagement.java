package me.iradius.server.dao;

import java.util.Date;
import me.iradius.server.ctxt.AppContext;
import me.iradius.server.dealer.DealerConfiguration;
import me.iradius.server.divers.ServerUtils;
import me.iradius.server.engine.QueryEngine;
import me.iradius.server.socket.RadiusSocketCLient;
import me.iradius.server.system.IRadiusSecurity;
import me.iradius.shared.db.Table;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.DealerInf;




public class DealerManagement
  extends AbstractDaoMgmt
{
  public DealerManagement(Table updateTableDef) {
    super(updateTableDef);
  }


  
  public void executeBeforeUpdate() throws Exception {
    String logoFieldName = "Logo";
    
    String logo = (String)this.updateTableDef.getFieldValues().get(logoFieldName);
    if (logo != null) {
      if (!logo.isEmpty()) {
        Object blobImageFromFile = ServerUtils.getBlobImageFromFile(logo);
        this.updateTableDef.getFieldValues().put(logoFieldName, blobImageFromFile);
      } else {
        this.updateTableDef.getFieldValues().put(logoFieldName, null);
      } 
    }

    
    String password = (String)this.updateTableDef.getFieldValues().get("Password");
    if (password != null && !password.isEmpty()) {
      
      password = IRadiusSecurity.encode(password);
      
      this.updateTableDef.addFieldValue("Password", password);
    } 
  }

  
  public void executeAfterUpdate(Integer modifiedUserId, Table updateTableDef, Integer pkFieldValue) throws Exception {
    DealerConfiguration dealerConfiguration = (DealerConfiguration)AppContext.getBean("dealerConfiguration");
    dealerConfiguration.refresh();

    
    if (updateTableDef.getInsertMode().booleanValue() && "Dealer".equals(updateTableDef.getTableName())) {
      (new RadiusSocketCLient(getSocketDef())).refreshDictionnary(RadiusSocketCLient.RefreshType.REFRESH_DEALERS);
    }
  }

  
  public void traceDealerBillingLog(Integer modifiedUserId, Integer dealerId, Integer UserId, Date newExpiryDate, String type, Double addedCredit, Double addedCommision, Integer commissionDealerId, String description) throws Exception {
    if (dealerId == null) {
      return;
    }
    Double addedDebit = null;
    if (addedCredit != null && addedCredit.doubleValue() < 0.0D) {
      addedDebit = Double.valueOf(-addedCredit.doubleValue());
      addedCredit = null;
    } 
    
    if (addedCredit != null) {
      addedCredit = ServerUtils.formatDouble(addedCredit);
    }
    if (addedCommision != null) {
      addedCommision = ServerUtils.formatDouble(addedCommision);
    }
    if (addedDebit != null) {
      addedDebit = ServerUtils.formatDouble(addedDebit);
    }
    Table tableDef = new Table("DealerBillingLog", "Id", Boolean.valueOf(true));
    tableDef.addFieldValue("DealerId", dealerId);
    tableDef.addFieldValue("UserId", UserId);
    tableDef.addFieldValue("NewExpiryDate", newExpiryDate);
    tableDef.addFieldValue("Type", type);
    tableDef.addFieldValue("Credit", addedCredit);
    tableDef.addFieldValue("Commission", addedCommision);
    tableDef.addFieldValue("Debit", addedDebit);
    tableDef.addFieldValue("CommissionDealerId", commissionDealerId);
    tableDef.addFieldValue("OperationDate", new Date((new Date()).getTime()));
    tableDef.addFieldValue("Description", description);
    tableDef.addFieldValue("ModifiedUserId", modifiedUserId);

    
    (new QueryEngine(getDataSource())).updateData(tableDef);
  }














  
  public void interfaceUpdateDealerCredit(Integer modifiedUserId, Integer dealerId, Double newCredit, String type, String description) throws Exception {
    DealerConfiguration dealerConfiguration = (DealerConfiguration)AppContext.getBean("dealerConfiguration");
    dealerConfiguration.UpdateDealerCredit(modifiedUserId, dealerId, newCredit, type, description, Boolean.valueOf(false));
  }
  
  public void transferDealerCommisionToCredit(Integer modifiedUserId, Integer dealerId, Double baseCredit, Double newCommission) throws Exception {
    DealerInf dealerInf = getDealerInf(dealerId);
    if (dealerInf != null) {
      if (dealerInf.getDealerCredit() != null && dealerInf.getDealerCredit().equals(baseCredit)) {
        DealerConfiguration dealerConfiguration = (DealerConfiguration)AppContext.getBean("dealerConfiguration");
        
        dealerConfiguration.checkCommission(dealerId, newCommission);
        
        dealerConfiguration.UpdateDealerCredit(modifiedUserId, dealerId, newCommission, "TRANSFER COMMISSION", "Transfer From Commission To Credit", Boolean.valueOf(true));
      } else {
        throw new Exception("Something wrong, Please contact support");
      } 
    } else {
      throw new Exception("Something wrong, Please contact support");
    } 
  }

  
  public void removeCreditBasedOnrechargeAccount(Integer modifiedUserId, Integer dealerId, Integer userId, Float accountRate, Date newExpiryDate, String type, String description) throws Exception {
    accountRate = Float.valueOf((accountRate != null) ? accountRate.floatValue() : 0.0F);
    DealerConfiguration dealerConfiguration = (DealerConfiguration)AppContext.getBean("dealerConfiguration");
    dealerConfiguration.updateDealerCredit(modifiedUserId, dealerId, userId, Double.valueOf(-accountRate.doubleValue()), newExpiryDate, type, description);
  }




  
  public void updateDealerCommission(Integer modifiedUserId, Integer userId, Integer accountTypeId, Date newExpiryDate, String type, String description, Boolean canTracebiiling) throws Exception {
    DealerConfiguration dealerConfiguration = (DealerConfiguration)AppContext.getBean("dealerConfiguration");
    dealerConfiguration.updateDealerCommision(modifiedUserId, userId, accountTypeId, newExpiryDate, type, description, canTracebiiling);
  }































  
  public Double checkDealerCredit(Integer dealerId, Float accountRate) throws Exception {
    String sqlCode = "SELECT Credit, NoCharge from Dealer WHERE UserId = " + dealerId;
    RecordSet recordSet = (new QueryEngine()).executeSql(sqlCode);
    if (recordSet.size() > 0) {
      Record record = (Record)recordSet.get(0);
      Boolean noCharge = record.getBooleanValue("NoCharge");
      if (!noCharge.booleanValue()) {
        Double credit = record.getDoubleValue("Credit");
        credit = Double.valueOf((credit != null) ? credit.doubleValue() : 0.0D);
        if (accountRate.floatValue() > credit.doubleValue()) {
          throw new Exception("Not Ennough Credit To Renew This User.");
        }
        return credit;
      } 
      
      return null;
    } 
    throw new Exception("Dealer Not Found.");
  }
  
  public void removeDealerCredit(Integer modifiedUserId, Integer dealerId, Integer userId, Float accountRate, Date newExpiryDate, String type, String description) throws Exception {
    Double credit = checkDealerCredit(dealerId, accountRate);
    if (credit != null)
      removeCreditBasedOnrechargeAccount(modifiedUserId, dealerId, userId, accountRate, newExpiryDate, type, description); 
  }
  
  public void checkIfExistLinkedAccounts(String dealerId) throws Exception {
    String sql = " SELECT count(DealerId) count from AccountType where DealerId = " + dealerId;
    RecordSet recordSet = (new QueryEngine()).executeSql(sql);
    if (recordSet != null && recordSet.size() > 0) {
      Integer count = ((Record)recordSet.get(0)).getIntegerValue("count");
      if (count.intValue() > 0) {
        throw new Exception("Dealer is linked to Account, Please delete linked Accounts before.");
      }
    } 
  }
















  
  public DealerInf getDealerInf(Integer userId) throws Exception {
    String sqlCode = " SELECT  Credit, Commision FROM Dealer Where UserId = " + userId;
    
    RecordSet recordSet = (new QueryEngine()).executeSql(sqlCode);
    if (recordSet.size() > 0) {
      Record record = (Record)recordSet.get(0);
      DealerInf dealerInf = new DealerInf();
      dealerInf.setDealerCredit(record.getDoubleValue("Credit"));
      dealerInf.setDealerCommission(record.getDoubleValue("Commision"));
      return dealerInf;
    } 
    return null;
  }
  
  public boolean canDeleteDealer(Integer dealerId) throws Exception {
    String sqlCode = " SELECT count(Id) as ct from User WHERE ParentId =  " + dealerId + " AND ProfileId = " + "2";
    
    RecordSet recordSet = (new QueryEngine()).executeSql(sqlCode);
    if (recordSet.size() > 0) {
      Record record = (Record)recordSet.get(0);
      Integer count = record.getIntegerValue("ct");
      return (count.intValue() == 0);
    } 
    return true;
  }

























  
  public void updateDealerExtraGBCommission(Integer modifiedUserId, Integer baseUserId, Integer dealerId, Integer totalGB) throws Exception {}
























  
  public void onUpdateDealerCommission(Integer modifiedUserId, Integer userId, Integer accountTypeId, Date newExpiryDate, String type, String description, Boolean canTracebiiling) throws Exception {
    Date sqlnewExpiryDate = (newExpiryDate != null) ? new Date(newExpiryDate.getTime()) : null;
    (new DealerManagement(null)).updateDealerCommission(modifiedUserId, userId, accountTypeId, sqlnewExpiryDate, type, description, canTracebiiling);
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\DealerManagement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */