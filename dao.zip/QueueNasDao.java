package me.iradius.server.dao;

import java.util.HashMap;
import java.util.LinkedList;
import me.iradius.mikrotik.api.MikrotikApi;
import me.iradius.mikrotik.api.legrange.mikrotik.impl.Result;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;



public class QueueNasDao
{
  public void applyQueueConfiguration(Integer nasId) throws Exception {
    try {
      String sql = " SELECT Host, ApiPort, ApiUserName, ApiPassword   FROM Nas ";

      
      if (nasId != null) {
        sql = String.valueOf(sql) + " Where Id = " + nasId;
      }
      RecordSet recordSet = (new QueryEngine()).executeSql(sql);
      for (Record record : recordSet) {
        
        String host = record.getStringValue("Host");
        Integer ApiPort = record.getIntegerValue("ApiPort");
        String ApiUserName = record.getStringValue("ApiUserName");
        String ApiPassword = record.getStringValue("ApiPassword");
        
        MikrotikApi mikrotikApi = new MikrotikApi(host, ApiPort, ApiUserName, ApiPassword);
        
        try {
          applyNasAddressListConfiguration(mikrotikApi);
          
          applyNasQueueTypeConfiguration(mikrotikApi);
          
          applyNasMangleConfiguration(mikrotikApi);
          
          applyQueueTreeConfiguration(mikrotikApi);
        } finally {
          
          if (mikrotikApi != null) {
            mikrotikApi.disconnect();
          }
        } 
      } 
    } catch (Exception e) {
      throw new Exception(e.getMessage());
    } 
  }



  
  private void applyNasAddressListConfiguration(MikrotikApi mikrotikApi) throws Exception {
    String printAddressList = "/ip/firewall/address-list/print detail without-paging ";
    LinkedList<Result> linkedList = (LinkedList<Result>)mikrotikApi.executeCommand(printAddressList);
    for (Result result : linkedList) {
      String comment = result.get("comment");
      if (comment != null && comment.equalsIgnoreCase("IRADIUS")) {
        
        String id = result.get(".id");
        String removeipAddressList = "/ip/firewall/address-list/remove .id=" + id;
        mikrotikApi.executeCommand(removeipAddressList);
      } 
    } 


    
    String sql = "select Name, Address from AddressList ";
    RecordSet recordSet = (new QueryEngine()).executeSql(sql);
    for (Record record : recordSet) {
      String Name = record.getStringValue("Name");
      String Address = record.getStringValue("Address");
      String ipAddressList = "/ip/firewall/address-list/add list=" + Name + "  address=" + Address + " comment=IRADIUS ";
      mikrotikApi.executeCommand(ipAddressList);
    } 
  }



  
  private void applyNasQueueTypeConfiguration(MikrotikApi mikrotikApi) throws Exception {
    String printAddressList = "/queue/type/print detail without-paging ";
    LinkedList<Result> linkedList = (LinkedList<Result>)mikrotikApi.executeCommand(printAddressList);
    HashMap<String, String> existList = new HashMap<>();
    for (Result result : linkedList) {
      String name = result.get("name");
      String id = result.get(".id");
      existList.put(name, id);
    } 
    
    String sql = "select Kind, Name , PcqClassifier, PcqDstAddress6Mask,  PcqRate, PcqSrcAddress6Mask,  PcqTotalLimit   from Queue ";



    
    RecordSet recordSet = (new QueryEngine()).executeSql(sql);
    for (Record record : recordSet) {
      String Kind = record.getStringValue("Kind");
      String Name = record.getStringValue("Name");
      String PcqClassifier = record.getStringValue("PcqClassifier");
      String PcqDstAddress6Mask = record.getStringValue("PcqDstAddress6Mask");
      String PcqRate = record.getStringValue("PcqRate");
      String PcqSrcAddress6Mask = record.getStringValue("PcqSrcAddress6Mask");
      String PcqTotalLimit = record.getStringValue("PcqTotalLimit");
      
      String id = existList.get(Name);
      if (id != null) {
        String removeQueuetypeList = "/queue/type/remove .id=" + id;
        mikrotikApi.executeCommand(removeQueuetypeList);
      } 
      
      String queueTypeCommand = "/queue/type/add kind=" + 
        Kind + 
        " name=" + Name + 
        " pcq-classifier=" + PcqClassifier + 
        " pcq-dst-address6-mask=" + PcqDstAddress6Mask + 
        " pcq-rate=" + PcqRate + 
        " pcq-src-address6-mask=" + PcqSrcAddress6Mask + 
        " pcq-total-limit=" + PcqTotalLimit;
      
      try {
        mikrotikApi.executeCommand(queueTypeCommand);
      } catch (Exception e) {
        System.err.println(e);
      } 
    } 
  }




  
  private void applyNasMangleConfiguration(MikrotikApi mikrotikApi) throws Exception {
    String printAddressList = "/ip/firewall/mangle/print detail without-paging ";
    LinkedList<Result> linkedList = (LinkedList<Result>)mikrotikApi.executeCommand(printAddressList);
    for (Result result : linkedList) {
      String comment = result.get("comment");
      if (comment != null && comment.equalsIgnoreCase("IRADIUS")) {
        
        String id = result.get(".id");
        String removeipAddressList = "/ip/firewall/mangle/remove .id=" + id;
        mikrotikApi.executeCommand(removeipAddressList);
      } 
    } 


    
    String sql = "SELECT  Action, Chain,  AddressList.Name, InInterface,  NewPacketMark, PassThrough,  SrcAddress  FROM Mangle  LEFT OUTER JOIN AddressList ON AddressList.Id = Mangle.DstAddressListId ";





    
    RecordSet recordSet = (new QueryEngine()).executeSql(sql);
    for (Record record : recordSet) {
      String Action = record.getStringValue("Action");
      String Chain = record.getStringValue("Chain");
      String AddressListName = record.getStringValue("Name");
      String InInterface = record.getStringValue("InInterface");
      String NewPacketMark = record.getStringValue("NewPacketMark");
      String PassThrough = record.getStringValue("PassThrough");
      String SrcAddress = record.getStringValue("SrcAddress");
      
      String mangleCommane = "/ip/firewall/mangle/add action=" + 
        Action + 
        " chain=" + Chain + 
        " dst-address-list=" + AddressListName + 
        " in-interface=" + InInterface + 
        " new-packet-mark=" + NewPacketMark + 
        " passthrough=" + PassThrough + 
        " src-address=" + SrcAddress + 
        " comment=IRADIUS";
      
      mikrotikApi.executeCommand(mangleCommane);
    } 
  }


  
  private void applyQueueTreeConfiguration(MikrotikApi mikrotikApi) throws Exception {
    String printAddressList = "/queue/tree/print detail without-paging ";
    LinkedList<Result> linkedList = (LinkedList<Result>)mikrotikApi.executeCommand(printAddressList);
    for (Result result : linkedList) {
      String comment = result.get("comment");
      if (comment != null && comment.equalsIgnoreCase("IRADIUS")) {
        
        String id = result.get(".id");
        String removeipAddressList = "/queue/tree/remove .id=" + id;
        mikrotikApi.executeCommand(removeipAddressList);
      } 
    } 
    
    String sql = "SELECT  QueueTree.Name, QueueTree.PacketMark,  ParentQueueTree.Name as ParentQueueTreeName, QueueTree.Priority,  Queue.Name as QueueName, QueueTree.MaxLimit  FROM QueueTree  LEFT OUTER JOIN QueueTree ParentQueueTree on QueueTree.ParentId = ParentQueueTree.Id  LEFT OUTER JOIN Queue   on Queue.Id = QueueTree.QueueId ";






    
    RecordSet recordSet = (new QueryEngine()).executeSql(sql);
    for (Record record : recordSet) {
      String Name = record.getStringValue("Name");
      String PacketMark = record.getStringValue("PacketMark");
      String ParentQueueTreeName = record.getStringValue("ParentQueueTreeName");
      Integer Priority = record.getIntegerValue("Priority");
      String QueueName = record.getStringValue("QueueName");
      String MaxLimit = record.getStringValue("MaxLimit");
      
      ParentQueueTreeName = (ParentQueueTreeName != null && !ParentQueueTreeName.isEmpty()) ? ParentQueueTreeName : "global";
      
      String queueTree = "/queue/tree/add  name=" + 
        Name + 
        " parent=" + ParentQueueTreeName + 
        " queue=" + QueueName + 
        " priority=" + Priority + ((
        MaxLimit != null && !MaxLimit.trim().isEmpty()) ? (" max-limit=" + MaxLimit) : "") + 
        " packet-mark=" + PacketMark + 
        " comment=IRADIUS";
      
      mikrotikApi.executeCommand(queueTree);
    } 
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\QueueNasDao.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */