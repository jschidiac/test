package me.iradius.server.dao.account;

import java.util.Calendar;
import java.util.Date;
import me.iradius.server.dao.user.UserInf;
import me.iradius.server.divers.ServerUtils;
import me.iradius.shared.SharedConst;
import me.iradius.shared.session.Session;


public class AccountTypeUtils
{
  public static Double getAccountPricePerDay(Double oldRate, Integer oldValidityPeriod, Integer oldValidityPeriodTypeId) {
    Date oldNowDate = new Date((new Date()).getTime());
    Date oldDate = getExpiryAccount(oldNowDate, oldValidityPeriod, oldValidityPeriodTypeId);
    int oldAccountaDays = ServerUtils.daysBetween(oldNowDate.getTime(), oldDate.getTime());
    Double oldAccountDayPrice = new Double(oldRate.doubleValue() / oldAccountaDays);
    
    oldAccountDayPrice = Double.valueOf((oldAccountDayPrice != null) ? oldAccountDayPrice.doubleValue() : 0.0D);
    
    return oldAccountDayPrice;
  }
  
  public static void checkIfAccountIsExpired(Session ispSession, Boolean preventBeforeRecharge, Date expiryAccount) throws Exception {
    Date now = new Date((new Date()).getTime());
    if ((ispSession == null || !ispSession.isAdmin()) && preventBeforeRecharge.booleanValue() && now.before(expiryAccount)) {
      throw new Exception("User Account is not Expired, Operation Failed");
    }
  }
  
  public static Integer getAccountInDays(Integer validityPeriod, Integer validityPeriodTypeId) {
    Date now = new Date();
    Date newDate = getExpiryAccount(now, validityPeriod, validityPeriodTypeId);
    return Integer.valueOf(ServerUtils.getDiffDays(newDate.getTime(), now.getTime()));
  }

  
  public static Date getExpiryAccount(Date refillRenewDate, Integer validityPeriod, Integer validityPeriodTypeId) {
    if (validityPeriod != null && validityPeriod.intValue() > 0) {
      if (SharedConst.CALENDAR_MONTH_PERIOD_ID.equals(validityPeriodTypeId)) {
        
        Calendar cal = Calendar.getInstance();
        cal.setTime(refillRenewDate);
        cal.add(2, validityPeriod.intValue());
        return cal.getTime();
      }  if (SharedConst.DAYS_PERIOD_ID.equals(validityPeriodTypeId)) {
        
        Calendar cal = Calendar.getInstance();
        cal.setTime(refillRenewDate);
        cal.add(5, validityPeriod.intValue());
        return cal.getTime();
      }  if (SharedConst.HOURS_PERIOD_ID.equals(validityPeriodTypeId)) {
        
        Calendar cal = Calendar.getInstance();
        cal.setTime(refillRenewDate);
        cal.add(10, validityPeriod.intValue());
        return cal.getTime();
      }  if (SharedConst.MINUTSE_PERIOD_ID.equals(validityPeriodTypeId)) {
        
        Calendar cal = Calendar.getInstance();
        cal.setTime(refillRenewDate);
        cal.add(12, validityPeriod.intValue());
        return cal.getTime();
      } 
    } 
    return null;
  }

  
  public static Double getRefundableCreditByTime(UserInf userInf, Double accountRate) {
    accountRate = Double.valueOf((accountRate == null) ? 0.0D : accountRate.doubleValue());
    
    int accountDays = getAccountInDays(userInf.validityPeriod, userInf.validityPeriodTypeId).intValue();
    
    int refundDays = ServerUtils.getDiffDays(userInf.expiryAccount.getTime(), (new Date()).getTime());
    
    if (refundDays == accountDays) {
      refundDays--;
    }
    
    Double refundCredit = new Double(refundDays * accountRate.doubleValue() / accountDays);
    
    return refundCredit;
  }

  
  public static Double getRefundableCreditByGB(UserInf userInf, Double accountRate) {
    accountRate = Double.valueOf((accountRate == null) ? 0.0D : accountRate.doubleValue());
    
    Integer accountData = Integer.valueOf(0);
    Float usedData = new Float(0.0F);
    if (userInf.CombinedMaxMonthlyUpAndDown != null && userInf.CombinedMaxMonthlyUpAndDown.intValue() > 0) {
      
      accountData = userInf.CombinedMaxMonthlyUpAndDown;
      usedData = Float.valueOf(userInf.currentUserMonthUp.floatValue() + userInf.currentUserMonthDown.floatValue());
    }
    else if (userInf.SeperateMaxMonthlyDown != null || userInf.SeperateMaxMonthlyUp != null) {
      
      if (userInf.SeperateMaxMonthlyDown == null) {
        userInf.SeperateMaxMonthlyDown = Integer.valueOf(0);
      }
      if (userInf.SeperateMaxMonthlyUp == null) {
        userInf.SeperateMaxMonthlyUp = Integer.valueOf(0);
      }
      accountData = Integer.valueOf(userInf.SeperateMaxMonthlyDown.intValue() + userInf.SeperateMaxMonthlyUp.intValue());
      usedData = Float.valueOf(userInf.currentUserMonthUp.floatValue() + userInf.currentUserMonthDown.floatValue());
    } 
    
    float refundMB = accountData.intValue() - usedData.floatValue();
    
    Double refundCredit = new Double(refundMB * accountRate.doubleValue() / accountData.intValue());
    return refundCredit;
  }

  
  private static Double getRefundableCreditByTimeeAndGB(UserInf userInf, Double accountRate) {
    accountRate = Double.valueOf((accountRate == null) ? 0.0D : accountRate.doubleValue());
    
    accountRate = Double.valueOf(accountRate.doubleValue() / 2.0D);
    
    Double refundByTime = getRefundableCreditByTime(userInf, accountRate);
    refundByTime = Double.valueOf((refundByTime == null) ? 0.0D : refundByTime.doubleValue());
    
    Double refundByGB = getRefundableCreditByGB(userInf, accountRate);
    refundByGB = Double.valueOf((refundByGB == null) ? 0.0D : refundByGB.doubleValue());
    
    return Double.valueOf(refundByTime.doubleValue() + refundByGB.doubleValue());
  }

  
  public static Double getRefundableCredit(UserInf userInf) {
    Integer accountTypeCategory = userInf.accountTypeCategory;
    
    if (SharedConst.ACCOUNTCATEGORY_DAILY.equals(accountTypeCategory))
    {
      return getRefundableCreditByTime(userInf, userInf.accountRate);
    }
    if (SharedConst.ACCOUNTCATEGORY_MONTHLY.equals(accountTypeCategory))
    {
      return getRefundableCreditByGB(userInf, userInf.accountRate);
    }

    
    return getRefundableCreditByTimeeAndGB(userInf, userInf.accountRate);
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\account\AccountTypeUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */