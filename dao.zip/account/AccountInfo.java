package me.iradius.server.dao.account;

import java.util.Date;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.SharedConst;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.Session;

public class AccountInfo {
	
	private Integer	id;
	private String	name;
	private Boolean	preventBeforeRecharge;
	private Integer	AccountTypeCategory;
	private Double	rate;
	private Double	commision;
	private Double	sellingPrice;
	private Integer	validityPeriod;
	private Integer	validityPeriodTypeId;
	private Integer	combinedMaxMonthlyUpAndDown;
	private Integer	seperateMaxMonthlyUp;
	private Integer	seperateMaxMonthlyDown;
	private Integer	monthlyFallBack;
	
	public static AccountInfo getAccountInfo(Integer accountTypeId) throws Exception {
		String sql = "SELECT Id, Commision, PreventBeforeRecharge, AccountTypeName, AccountTypeCategory, Rate, " //
				+ " ValidityPeriod, ValidityPeriodTypeId   , CombinedMaxMonthlyUpAndDown, SeperateMaxMonthlyUp, " //
				+ "SeperateMaxMonthlyDown , SellingPrice, " //
				+ "(SELECT AboveMB FROM AccountTypeMonthlyAutoFallBack " //
				+ " WHERE AccountTypeMonthlyAutoFallBack.AccountTypeId = AccountType.Id ORDER BY AboveMB DESC LIMIT 0, 1) " //
				+ "as MonthlyFallBack  " //
				+ "FROM  AccountType  WHERE AccountType.Id = " + accountTypeId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			AccountInfo accountInfo = new AccountInfo();
			accountInfo.setId(record.getIntegerValue("Id"));
			accountInfo.setName(record.getStringValue("AccountTypeName"));
			accountInfo.setAccountTypeCategory(record.getIntegerValue("AccountTypeCategory"));
			accountInfo.setPreventBeforeRecharge(record.getBooleanValue("PreventBeforeRecharge"));
			accountInfo.setRate(record.getDoubleValue("Rate"));
			accountInfo.setCommision(record.getDoubleValue("Commision"));
			accountInfo.setSellingPrice(record.getDoubleValue("SellingPrice"));
			accountInfo.setValidityPeriod(record.getIntegerValue("ValidityPeriod"));
			accountInfo.setValidityPeriodTypeId(record.getIntegerValue("ValidityPeriodTypeId"));
			accountInfo.setCombinedMaxMonthlyUpAndDown(record.getIntegerValue("CombinedMaxMonthlyUpAndDown"));
			accountInfo.setSeperateMaxMonthlyDown(record.getIntegerValue("SeperateMaxMonthlyDown"));
			accountInfo.setSeperateMaxMonthlyUp(record.getIntegerValue("SeperateMaxMonthlyUp"));
			accountInfo.setMonthlyFallBack(record.getIntegerValue("MonthlyFallBack"));
			return accountInfo;
		}
		return null;
	}
	
	public void checkIfAccountIsExpired(Session ispSession, Date expiryDate) throws Exception {
		Date now = new Date((new Date()).getTime());
		if ((ispSession == null || !ispSession.isAdmin()) && this.preventBeforeRecharge.booleanValue() && now.before(expiryDate)) {
			throw new Exception("User Account is not Expired, Operation Failed");
		}
	}
	
	private Boolean isMonthly() {
		return ((this.combinedMaxMonthlyUpAndDown == null || this.combinedMaxMonthlyUpAndDown.intValue() <= 0) && (this.seperateMaxMonthlyUp == null || this.seperateMaxMonthlyUp.intValue() <= 0)
				&& (this.seperateMaxMonthlyDown == null || this.seperateMaxMonthlyDown.intValue() <= 0) && (this.monthlyFallBack == null || this.monthlyFallBack.intValue() <= 0)) ? Boolean.valueOf(false) : Boolean.valueOf(true);
	}
	
	public Boolean isMonthlyAccount() {
		if (this.AccountTypeCategory != null) {
			return Boolean.valueOf(SharedConst.ACCOUNTCATEGORY_MONTHLY.equals(this.AccountTypeCategory));
		}
		return isMonthly();
	}
	
	public Boolean isDailyAccount() {
		if (this.AccountTypeCategory != null) {
			return Boolean.valueOf(SharedConst.ACCOUNTCATEGORY_DAILY.equals(this.AccountTypeCategory));
		}
		return Boolean.valueOf(!isMonthly().booleanValue());
	}
	
	public Boolean isDailyMonthlyAccount() {
		if (this.AccountTypeCategory != null) {
			return Boolean.valueOf(SharedConst.ACCOUNTCATEGORY_DAILYANDMONTHLY.equals(this.AccountTypeCategory));
		}
		return Boolean.valueOf(false);
	}
	
	public Integer getId() {
		return this.id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public Boolean getPreventBeforeRecharge() {
		return this.preventBeforeRecharge;
	}
	
	public void setPreventBeforeRecharge(Boolean preventBeforeRecharge) {
		this.preventBeforeRecharge = preventBeforeRecharge;
	}
	
	public Double getRate() {
		return Double.valueOf((this.rate != null) ? this.rate.doubleValue() : 0.0D);
	}
	
	public void setRate(Double rate) {
		this.rate = rate;
	}
	
	public Integer getValidityPeriod() {
		return this.validityPeriod;
	}
	
	public void setValidityPeriod(Integer validityPeriod) {
		this.validityPeriod = validityPeriod;
	}
	
	public Integer getValidityPeriodTypeId() {
		return this.validityPeriodTypeId;
	}
	
	public void setValidityPeriodTypeId(Integer validityPeriodTypeId) {
		this.validityPeriodTypeId = validityPeriodTypeId;
	}
	
	public Integer getCombinedMaxMonthlyUpAndDown() {
		return this.combinedMaxMonthlyUpAndDown;
	}
	
	public void setCombinedMaxMonthlyUpAndDown(Integer combinedMaxMonthlyUpAndDown) {
		this.combinedMaxMonthlyUpAndDown = combinedMaxMonthlyUpAndDown;
	}
	
	public Integer getSeperateMaxMonthlyUp() {
		return this.seperateMaxMonthlyUp;
	}
	
	public void setSeperateMaxMonthlyUp(Integer seperateMaxMonthlyUp) {
		this.seperateMaxMonthlyUp = seperateMaxMonthlyUp;
	}
	
	public Integer getSeperateMaxMonthlyDown() {
		return this.seperateMaxMonthlyDown;
	}
	
	public void setSeperateMaxMonthlyDown(Integer seperateMaxMonthlyDown) {
		this.seperateMaxMonthlyDown = seperateMaxMonthlyDown;
	}
	
	public Integer getMonthlyFallBack() {
		return this.monthlyFallBack;
	}
	
	public void setMonthlyFallBack(Integer monthlyFallBack) {
		this.monthlyFallBack = monthlyFallBack;
	}
	
	public Double getCommision() {
		return this.commision;
	}
	
	public void setCommision(Double commision) {
		this.commision = commision;
	}
	
	public Double getSellingPrice() {
		return sellingPrice;
	}
	
	public void setSellingPrice(Double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}
	
	public Integer getAccountTypeCategory() {
		return this.AccountTypeCategory;
	}
	
	public void setAccountTypeCategory(Integer accountTypeCategory) {
		this.AccountTypeCategory = accountTypeCategory;
	}
	
	public Float getMonthlyAccountMaxQuota() {
		Float oldccountMax = (getCombinedMaxMonthlyUpAndDown() != null) ? Float.valueOf(getCombinedMaxMonthlyUpAndDown().floatValue()) : null;
		if (oldccountMax == null) {
			oldccountMax = Float.valueOf(((getSeperateMaxMonthlyDown() != null) ? getSeperateMaxMonthlyDown().floatValue() : 0.0F) + ((getSeperateMaxMonthlyUp() != null) ? getSeperateMaxMonthlyUp().floatValue() : 0.0F));
		}
		if (oldccountMax == null || oldccountMax.equals(new Float(0.0F))) {
			oldccountMax = Float.valueOf((getMonthlyFallBack() != null) ? getMonthlyFallBack().floatValue() : 0.0F);
		}
		return Float.valueOf((oldccountMax != null) ? oldccountMax.floatValue() : 0.0F);
	}
}
/*
 * Location:
 * C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server
 * \dao\account\AccountInfo.class Java compiler version: 7 (51.0) JD-Core
 * Version: 1.1.3
 */