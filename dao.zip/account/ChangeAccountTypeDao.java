package me.iradius.server.dao.account;

import java.util.Calendar;
import java.util.Date;
import me.iradius.server.ctxt.AppContext;
import me.iradius.server.dao.DealerManagement;
import me.iradius.server.dao.UserManagement;
import me.iradius.server.dao.dealer.DealerCommistionMgmt;
import me.iradius.server.dao.invoice.InvoiceDao;
import me.iradius.server.dao.user.TraceUserLog;
import me.iradius.server.divers.ServerUtils;
import me.iradius.server.engine.QueryEngine;
import me.iradius.server.socket.RadiusSocketCLient;
import me.iradius.server.socket.SocketDef;
import me.iradius.shared.acctype.ChangeAccTypeInfo;
import me.iradius.shared.db.Table;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.Session;

public class ChangeAccountTypeDao {
	
	public static final Integer	BYTE		= Integer.valueOf(1);
	public static final Integer	KILO_BYTE	= Integer.valueOf(1024 * BYTE.intValue());
	public static final Integer	MEGA_BYTE	= Integer.valueOf(1024 * KILO_BYTE.intValue());
	public static final Integer	GEGA_BYTE	= Integer.valueOf(1024 * MEGA_BYTE.intValue());
	
	protected SocketDef getSocketDef() {
		return (SocketDef) AppContext.getBean("socket");
	}
	
	private Double getDebitBasedOnTime(UserNasInfo userNasInfo, AccountInfo oldAccountInfo, AccountInfo newAccountInfo, Boolean remainingDaysPrice) {
		Date now = new Date();
		Integer remainAccountMinutes = Integer.valueOf(ServerUtils.minutesBetween(now.getTime(), userNasInfo.getExpiryDate().getTime()));
		Double newAccountDayPrice = AccountTypeUtils.getAccountPricePerDay(newAccountInfo.getRate(), newAccountInfo.getValidityPeriod(), newAccountInfo.getValidityPeriodTypeId());
		Double newDebitToRemove = Double.valueOf((remainAccountMinutes.intValue() / 1440) * newAccountDayPrice.doubleValue());
		return newDebitToRemove;
	}
	
	private Double getCreditMoneyBasedOnMonthly(UserNasInfo userNasInfo, AccountInfo oldAccountInfo, AccountInfo newAccountInfo, boolean b) {
		Double oldRate = oldAccountInfo.getRate();
		Float consumed = userNasInfo.getuserConsumedMB();
		Float oldccountMax = oldAccountInfo.getMonthlyAccountMaxQuota();
		Float remainingQuota = Float.valueOf(oldccountMax.floatValue() - consumed.floatValue());
		Double oldMBRate = new Double(oldRate.doubleValue() / oldccountMax.floatValue());
		Double oldCredit = Double.valueOf(remainingQuota.floatValue() * oldMBRate.doubleValue());
		return oldCredit;
	}
	
	private Double assignChangeAccTypeInfoBasedOnMonthlyToDaily(ChangeAccTypeInfo changeAccTypeInfo, UserNasInfo userNasInfo, AccountInfo oldAccountInfo, AccountInfo newAccountInfo) {
		Double refeundBasedOnQuota = getCreditMoneyBasedOnMonthly(userNasInfo, oldAccountInfo, newAccountInfo, false);
		Double debitbasedOnTime = getDebitBasedOnTime(userNasInfo, oldAccountInfo, newAccountInfo, Boolean.valueOf(false));
		Double refeundMoney = Double.valueOf(refeundBasedOnQuota.doubleValue() - debitbasedOnTime.doubleValue());
		if (changeAccTypeInfo != null) {
			changeAccTypeInfo.setRefund(ServerUtils.formatDouble(refeundMoney));
		}
		return refeundMoney;
	}
	
	private Double assignChangeAccTypeInfoBasedOnDailyToMonthly(ChangeAccTypeInfo changeAccTypeInfo, UserNasInfo userNasInfo, AccountInfo oldAccountInfo, AccountInfo newAccountInfo) {
		Float newAccountMax = newAccountInfo.getMonthlyAccountMaxQuota();
		Float consumed = userNasInfo.getuserConsumedMB();
		if (consumed.floatValue() >= newAccountMax.floatValue()) {
			Double double_ = Double.valueOf((newAccountInfo.getRate() != null) ? newAccountInfo.getRate().doubleValue() : 0.0D);
			if (changeAccTypeInfo != null) {
				changeAccTypeInfo.setPayNewAccountQuota(true);
				changeAccTypeInfo.setRefund(ServerUtils.formatDouble(Double.valueOf(-double_.doubleValue())));
			}
			return Double.valueOf(-double_.doubleValue());
		}
		Float remainingQuota = Float.valueOf(newAccountMax.floatValue() - consumed.floatValue());
		Double oldRate = oldAccountInfo.getRate();
		Double newRate = newAccountInfo.getRate();
		Float newccountMax = newAccountInfo.getMonthlyAccountMaxQuota();
		Double oldMBRate = new Double(oldRate.doubleValue() / newccountMax.floatValue());
		Double newMBRate = new Double(newRate.doubleValue() / newccountMax.floatValue());
		Double oldCredit = Double.valueOf(remainingQuota.floatValue() * oldMBRate.doubleValue());
		Double newCredit = Double.valueOf(remainingQuota.floatValue() * newMBRate.doubleValue());
		Double finalCredit = Double.valueOf(oldCredit.doubleValue() - newCredit.doubleValue());
		if (changeAccTypeInfo != null)
			changeAccTypeInfo.setRefund(ServerUtils.formatDouble(finalCredit));
		return finalCredit;
	}
	
	private Double assignChangeAccTypeInfoBasedOnDailyToDaily(ChangeAccTypeInfo changeAccTypeInfo, UserNasInfo userNasInfo, AccountInfo oldAccountInfo, AccountInfo newAccountInfo, Boolean splitAcccount) {
		Date now = new Date();
		Integer remainAccountMinutes = Integer.valueOf(ServerUtils.minutesBetween(now.getTime(), userNasInfo.getExpiryDate().getTime()));
		Double oldAccountDayPrice = AccountTypeUtils.getAccountPricePerDay(oldAccountInfo.getRate(), oldAccountInfo.getValidityPeriod(), oldAccountInfo.getValidityPeriodTypeId());
		Double newAccountDayPrice = AccountTypeUtils.getAccountPricePerDay(newAccountInfo.getRate(), newAccountInfo.getValidityPeriod(), newAccountInfo.getValidityPeriodTypeId());
		if (splitAcccount.booleanValue()) {
			oldAccountDayPrice = Double.valueOf(oldAccountDayPrice.doubleValue() / 2.0D);
			newAccountDayPrice = Double.valueOf(newAccountDayPrice.doubleValue() / 2.0D);
		}
		Double credit = Double.valueOf(0.0D);
		Double oldCredit = Double.valueOf((remainAccountMinutes.intValue() / 1440) * oldAccountDayPrice.doubleValue());
		Double newCreditToAdd = Double.valueOf((remainAccountMinutes.intValue() / 1440) * newAccountDayPrice.doubleValue());
		Double finalCredit = Double.valueOf(oldCredit.doubleValue() - newCreditToAdd.doubleValue());
		credit = finalCredit;
		if (changeAccTypeInfo != null) {
			changeAccTypeInfo.setRefund(ServerUtils.formatDouble(credit));
		}
		return credit;
	}
	
	private Double assignChangeAccTypeInfoBasedOnMonthlyToMontly(ChangeAccTypeInfo changeAccTypeInfo, UserNasInfo userNasInfo, AccountInfo oldAccountInfo, AccountInfo newAccountInfo, Boolean splitAccount) {
		Double oldRate = oldAccountInfo.getRate();
		Double newRate = newAccountInfo.getRate();
		if (splitAccount.booleanValue()) {
			oldRate = Double.valueOf(oldRate.doubleValue() / 2.0D);
			newRate = Double.valueOf(newRate.doubleValue() / 2.0D);
		}
		Float consumed = userNasInfo.getuserConsumedMB();
		Float oldccountMax = oldAccountInfo.getMonthlyAccountMaxQuota();
		Float remainingOldQuota = Float.valueOf(oldccountMax.floatValue() - consumed.floatValue());
		Double oldMBRate = new Double(oldRate.doubleValue() / oldccountMax.floatValue());
		Float newccountMax = newAccountInfo.getMonthlyAccountMaxQuota();
		Float remainingNewQuota = Float.valueOf(newccountMax.floatValue() - consumed.floatValue());
		Double newMBRate = new Double(newRate.doubleValue() / newccountMax.floatValue());
		Double oldCredit = Double.valueOf(remainingOldQuota.floatValue() * oldMBRate.doubleValue());
		Double newCredit = Double.valueOf(remainingNewQuota.floatValue() * newMBRate.doubleValue());
		Double finalCredit = Double.valueOf(oldCredit.doubleValue() - newCredit.doubleValue());
		if (changeAccTypeInfo != null) {
			changeAccTypeInfo.setRefund(ServerUtils.formatDouble(finalCredit));
		}
		return finalCredit;
	}
	
	private void assignChangeAccTypeInfoBasedOnDailyMontlyToDailyMonthly(ChangeAccTypeInfo changeAccTypeInfo, UserNasInfo userNasInfo, AccountInfo oldAccountInfo, AccountInfo newAccountInfo) {
		Double refunBasedOnDays = assignChangeAccTypeInfoBasedOnDailyToDaily(null, userNasInfo, oldAccountInfo, newAccountInfo, Boolean.valueOf(true));
		Double refunBasedOnQuota = assignChangeAccTypeInfoBasedOnMonthlyToMontly(null, userNasInfo, oldAccountInfo, newAccountInfo, Boolean.valueOf(true));
		Double finalCredit = Double.valueOf(refunBasedOnDays.doubleValue() + refunBasedOnQuota.doubleValue());
		changeAccTypeInfo.setRefund(ServerUtils.formatDouble(finalCredit));
	}
	
	private void getRefundByChangeAccount(ChangeAccTypeInfo changeAccTypeInfo, UserNasInfo userNasInfo, AccountInfo oldAccountInfo, AccountInfo newAccountInfo) throws Exception {
		if (oldAccountInfo.isDailyAccount().booleanValue() && newAccountInfo.isDailyAccount().booleanValue()) {
			assignChangeAccTypeInfoBasedOnDailyToDaily(changeAccTypeInfo, userNasInfo, oldAccountInfo, newAccountInfo, Boolean.valueOf(false));
		} else if (oldAccountInfo.isMonthlyAccount().booleanValue() && newAccountInfo.isMonthlyAccount().booleanValue()) {
			if (newAccountInfo.getMonthlyAccountMaxQuota().floatValue() > 0.0F && oldAccountInfo.getMonthlyAccountMaxQuota().floatValue() > 0.0F) {
				assignChangeAccTypeInfoBasedOnMonthlyToMontly(changeAccTypeInfo, userNasInfo, oldAccountInfo, newAccountInfo, Boolean.valueOf(false));
			}
		} else if (oldAccountInfo.isMonthlyAccount().booleanValue() && newAccountInfo.isDailyAccount().booleanValue()) {
			if (oldAccountInfo.getMonthlyAccountMaxQuota().floatValue() > 0.0F) {
				assignChangeAccTypeInfoBasedOnMonthlyToDaily(changeAccTypeInfo, userNasInfo, oldAccountInfo, newAccountInfo);
			}
		} else if (oldAccountInfo.isDailyAccount().booleanValue() && newAccountInfo.isMonthlyAccount().booleanValue()) {
			if (newAccountInfo.getMonthlyAccountMaxQuota().floatValue() > 0.0F) {
				assignChangeAccTypeInfoBasedOnDailyToMonthly(changeAccTypeInfo, userNasInfo, oldAccountInfo, newAccountInfo);
			}
		} else if (oldAccountInfo.isDailyMonthlyAccount().booleanValue() && newAccountInfo.isDailyMonthlyAccount().booleanValue()) {
			if (newAccountInfo.getMonthlyAccountMaxQuota().floatValue() > 0.0F && oldAccountInfo.getMonthlyAccountMaxQuota().floatValue() > 0.0F) {
				assignChangeAccTypeInfoBasedOnDailyMontlyToDailyMonthly(changeAccTypeInfo, userNasInfo, oldAccountInfo, newAccountInfo);
			}
		} else if (oldAccountInfo.isMonthlyAccount().booleanValue() && newAccountInfo.isDailyMonthlyAccount().booleanValue()) {
			if (newAccountInfo.getMonthlyAccountMaxQuota().floatValue() > 0.0F && oldAccountInfo.getMonthlyAccountMaxQuota().floatValue() > 0.0F) {
				assignChangeAccTypeInfoBasedOnMonthlyToMontly(changeAccTypeInfo, userNasInfo, oldAccountInfo, newAccountInfo, Boolean.valueOf(false));
			}
		} else if (oldAccountInfo.isDailyAccount().booleanValue() && newAccountInfo.isDailyMonthlyAccount().booleanValue()) {
			assignChangeAccTypeInfoBasedOnDailyToDaily(changeAccTypeInfo, userNasInfo, oldAccountInfo, newAccountInfo, Boolean.valueOf(false));
		} else if (oldAccountInfo.isDailyMonthlyAccount().booleanValue() && newAccountInfo.isDailyAccount().booleanValue()) {
			assignChangeAccTypeInfoBasedOnDailyToDaily(changeAccTypeInfo, userNasInfo, oldAccountInfo, newAccountInfo, Boolean.valueOf(false));
		} else if (oldAccountInfo.isDailyMonthlyAccount().booleanValue() && newAccountInfo.isMonthlyAccount().booleanValue()) {
			if (newAccountInfo.getMonthlyAccountMaxQuota().floatValue() > 0.0F && oldAccountInfo.getMonthlyAccountMaxQuota().floatValue() > 0.0F) {
				assignChangeAccTypeInfoBasedOnMonthlyToMontly(changeAccTypeInfo, userNasInfo, oldAccountInfo, newAccountInfo, Boolean.valueOf(false));
			}
		} else {
			throw new Exception("The Sysytem cannot make this change, Please contact your administrator.");
		}
	}
	
	public ChangeAccTypeInfo getRemaingCreditForchangeUserAccountType(Session ispSession, Integer modifiedUserId, Integer userId, String userName, Integer oldAccountTypeId, Integer newAccountTypeId, Integer daysToApply) throws Exception {
		ChangeAccTypeInfo changeAccTypeInfo = new ChangeAccTypeInfo();
		Boolean canManageDealerCredit = Boolean.valueOf(!(daysToApply != null && !daysToApply.equals(Integer.valueOf(0))));
		UserNasInfo userNasInfo = UserNasInfo.getUserNasInfo(userId);
		if (userNasInfo != null && !userNasInfo.getNoCharge().booleanValue()) {
			if (userNasInfo.getTempExpiryAccount() != null && userNasInfo.getOldAccountTypeId() != null && userNasInfo.getOldAccountTypeId().equals(newAccountTypeId)) {
				canManageDealerCredit = Boolean.valueOf(false);
			}
			if (canManageDealerCredit.booleanValue() && userNasInfo.getExpiryDate().after(new Date())) {
				AccountInfo oldAccountInfo = AccountInfo.getAccountInfo(oldAccountTypeId);
				AccountInfo newAccountInfo = AccountInfo.getAccountInfo(newAccountTypeId);
				if (oldAccountInfo != null && newAccountInfo != null) {
					oldAccountInfo.checkIfAccountIsExpired(ispSession, userNasInfo.getExpiryDate());
					getRefundByChangeAccount(changeAccTypeInfo, userNasInfo, oldAccountInfo, newAccountInfo);
				}
			}
		}
		return changeAccTypeInfo;
	}
	
	public void changeUserAccountType(Integer modifiedUserId, Integer userId, String userName, Integer oldAccountTypeId, Integer newAccountTypeId, Integer daysToApply) throws Exception {
		ChangeAccTypeInfo changeAccTypeInfo = new ChangeAccTypeInfo();
		Boolean canManageDealerCredit = Boolean.valueOf(!(daysToApply != null && !daysToApply.equals(Integer.valueOf(0))));
		UserNasInfo userNasInfo = UserNasInfo.getUserNasInfo(userId);
		if (userNasInfo != null) {
			if (userNasInfo.getTempExpiryAccount() != null && userNasInfo.getOldAccountTypeId() != null && userNasInfo.getOldAccountTypeId().equals(newAccountTypeId)) {
				canManageDealerCredit = Boolean.valueOf(false);
			}
			AccountInfo oldAccountInfo = AccountInfo.getAccountInfo(oldAccountTypeId);
			AccountInfo newAccountInfo = AccountInfo.getAccountInfo(newAccountTypeId);
			if (oldAccountInfo != null && newAccountInfo != null) {
				getRefundByChangeAccount(changeAccTypeInfo, userNasInfo, oldAccountInfo, newAccountInfo);
				if (!userNasInfo.getNoCharge().booleanValue() && canManageDealerCredit.booleanValue() && userNasInfo.getExpiryDate().after(new Date())) {
					updateBilliingInfoBasedOnChangeAccount(modifiedUserId, userId, userName, oldAccountTypeId, changeAccTypeInfo, userNasInfo, oldAccountInfo, newAccountInfo);
					(new InvoiceDao()).generateInvoiceBasedOnChangeAccountType(modifiedUserId, userNasInfo.getDealerId(), userId, changeAccTypeInfo, newAccountInfo);
				}
				canManageDealerCredit = Boolean.valueOf(!(daysToApply != null && !daysToApply.equals(Integer.valueOf(0))));
				Table tableDef = new Table("UserNas", "UserId", Boolean.valueOf(false));
				tableDef.setPkFieldValue(userId);
				tableDef.addFieldValue("AccountTypeId", newAccountTypeId);
				if (!canManageDealerCredit.booleanValue()) {
					Date now = new Date((new Date()).getTime());
					Calendar cal = Calendar.getInstance();
					cal.setTime(now);
					cal.add(5, daysToApply.intValue());
					Date newExpiryDate = new Date(cal.getTime().getTime());
					tableDef.addFieldValue("TempExpiryAccount", newExpiryDate);
					tableDef.addFieldValue("OldAccountTypeId", oldAccountTypeId);
				} else {
					tableDef.addFieldValue("TempExpiryAccount", null);
					tableDef.addFieldValue("OldAccountTypeId", null);
				}
				Boolean newAccount = Boolean.valueOf(false);
				if (changeAccTypeInfo.isPayNewAccountQuota()) {
					addFieldToResetUserQuota(tableDef);
					updateUserNasSessionBasedOnNewAccount(userId);
					newAccount = Boolean.valueOf(true);
				}
				(new QueryEngine()).updateData(tableDef);
				//
				Table userTableDef = new Table("User", "Id", false);
				userTableDef.setPkFieldValue(userId);
				userTableDef.addFieldValue("AccountPrice", newAccountInfo.getSellingPrice());
				new QueryEngine().updateData(userTableDef);
				//
				if (newAccount.booleanValue()) {
					(new RadiusSocketCLient(getSocketDef())).notifyRadiusByResetQuota(userId, userName);
				}
				Date accountExpiryDate = userNasInfo.getExpiryDate();
				(new TraceUserLog()).traceUserLog(userId, userNasInfo.getDealerId(), userName, "6", "Change User Account Type By " + UserManagement.getModifiedUserName(modifiedUserId) + " [Old Acccount = " + oldAccountInfo.getName()
						+ "]  [New Account = " + newAccountInfo.getName() + "] [Expiry Date = " + accountExpiryDate.toLocaleString() + "] ");
			}
		}
	}
	
	private void updateBilliingInfoBasedOnChangeAccount(Integer modifiedUserId, Integer userId, String userName, Integer oldAccountTypeId, ChangeAccTypeInfo changeAccTypeInfo, UserNasInfo userNasInfo, AccountInfo oldAccountInfo,
			AccountInfo newAccountInfo) throws Exception {
		Double refundCredit = Double.valueOf((changeAccTypeInfo.getRefund() != null) ? changeAccTypeInfo.getRefund().doubleValue() : 0.0D);
		Double newCredit = Double.valueOf(userNasInfo.getCredit().doubleValue() + refundCredit.doubleValue());
		String description = "Change Account Type For User : " + userName + "[Old Account = " + oldAccountInfo.getName() + "]  [New Account = " + newAccountInfo.getName() + "] ";
		if (newCredit.doubleValue() < 0.0D) {
			throw new Exception("Not ennough credit for this operation.");
		}
		(new DealerManagement(null)).removeCreditBasedOnrechargeAccount(modifiedUserId, userNasInfo.getDealerId(), userId, Float.valueOf(-refundCredit.floatValue()), null, "CHANGE ACCOUNT", description);
		(new DealerCommistionMgmt()).commissionMgmt(modifiedUserId, oldAccountTypeId, oldAccountInfo.getRate(), oldAccountInfo.getCommision(), refundCredit, "REFUND", description);
	}
	
	public RenewUserDate updateUserExpiryAccountDate(Integer userId, Integer accountTypeId, Integer days, Boolean forceOverrideImmediatlyRecharge, Boolean overrideImmediatlyRecharge) throws Exception {
		Date refillRenewDate = null;
		String sql = "SELECT ImmediateRecharge, PreventBeforeRecharge, AddedHours,   ExtraDaysToAddWhenRefill, ExtraDaysToDeductWhenRefill, ValidityPeriod, ValidityPeriodTypeId,  ExpiryAccount , OverrideExpiryAccount, ForceExpiryAfterDays, AccountTypeCategory  FROM  UserNas  LEFT OUTER JOIN AccountType ON AccountType.Id = UserNas.AccountTypeId  WHERE AccountType.Id = "
				+ accountTypeId + " AND UserNas.UserId = " + userId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet != null && recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			Date activatedAccount = null;
			Date expiryAccount = record.getDateValue("ExpiryAccount");
			if (expiryAccount != null && expiryAccount.before(new Date())) {
				expiryAccount = new Date();
				activatedAccount = expiryAccount;
			}
			Integer validityPeriod = record.getIntegerValue("ValidityPeriod");
			Integer validityPeriodTypeId = record.getIntegerValue("ValidityPeriodTypeId");
			Boolean immediateRecharge = record.getBooleanValue("ImmediateRecharge");
			if (forceOverrideImmediatlyRecharge != null && forceOverrideImmediatlyRecharge.booleanValue()) {
				immediateRecharge = overrideImmediatlyRecharge;
			}
			refillRenewDate = new Date();
			if (!immediateRecharge.booleanValue() && expiryAccount != null) {
				refillRenewDate = expiryAccount;
			}
			Date expiryDate = AccountTypeUtils.getExpiryAccount(refillRenewDate, validityPeriod, validityPeriodTypeId);
			if (expiryDate != null) {
				RenewUserDate renewUserDate = new RenewUserDate();
				Integer addedHours = record.getIntegerValue("AddedHours");
				if (addedHours != null && addedHours.intValue() > 0) {
					Calendar cal = Calendar.getInstance();
					cal.setTime(expiryDate);
					cal.add(10, -addedHours.intValue());
					expiryDate = cal.getTime();
				}
				Integer extraDaysToAddWhenRefill = record.getIntegerValue("ExtraDaysToAddWhenRefill");
				if (extraDaysToAddWhenRefill != null && extraDaysToAddWhenRefill.intValue() > 0) {
					Calendar cal = Calendar.getInstance();
					cal.setTime(expiryDate);
					cal.add(5, extraDaysToAddWhenRefill.intValue());
					expiryDate = cal.getTime();
				}
				Integer extraDaysToDeductWhenRefill = record.getIntegerValue("ExtraDaysToDeductWhenRefill");
				if (extraDaysToDeductWhenRefill != null && extraDaysToDeductWhenRefill.intValue() > 0) {
					Calendar cal = Calendar.getInstance();
					cal.setTime(expiryDate);
					cal.add(5, -extraDaysToDeductWhenRefill.intValue());
					expiryDate = cal.getTime();
				}
				if (expiryDate != null) {
					expiryDate.setHours(23);
					expiryDate.setMinutes(59);
				}
				Table tableDef = new Table("UserNas", "UserId", Boolean.valueOf(false));
				tableDef.setPkFieldValue(userId);
				if (immediateRecharge.booleanValue() || activatedAccount != null)
					tableDef.addFieldValue("ActivatedAccount", refillRenewDate);
				tableDef.addFieldValue("ExpiryAccount", expiryDate);
				if (days != null && days.intValue() > 0) {
					Date overrideExpiryAccount = new Date();
					Calendar cal = Calendar.getInstance();
					cal.setTime(overrideExpiryAccount);
					cal.add(5, days.intValue());
					overrideExpiryAccount = cal.getTime();
					tableDef.addFieldValue("OverrideExpiryAccount", overrideExpiryAccount);
					tableDef.addFieldValue("ForceExpiryAfterDays", days);
					renewUserDate.setOverrideExpiryAccount(overrideExpiryAccount);
					renewUserDate.setForceExpiryAfterDays(days);
				} else {
					tableDef.addFieldValue("OverrideExpiryAccount", null);
					tableDef.addFieldValue("ForceExpiryAfterDays", null);
				}
				addFieldToResetUserQuota(tableDef);
				(new QueryEngine()).updateData(tableDef);
				updateUserNasSessionBasedOnNewAccount(userId);
				renewUserDate.setExpiryDate(expiryDate);
				return renewUserDate;
			}
		}
		return null;
	}
	
	protected QuotaInfo getQuotaInfo(Integer userId) throws Exception {
		QuotaInfo quotaInfo = new QuotaInfo();
		String sql = "SELECT DownloadBytes , UploadBytes From UserNas where UserId = " + userId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet != null && recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			Double DownloadBytes = record.getDoubleValue("DownloadBytes");
			Double UploadBytes = record.getDoubleValue("UploadBytes");
			DownloadBytes = Double.valueOf((DownloadBytes != null) ? DownloadBytes.doubleValue() : 0.0D);
			UploadBytes = Double.valueOf((UploadBytes != null) ? UploadBytes.doubleValue() : 0.0D);
			quotaInfo.setExtraGbDownload(Double.valueOf(DownloadBytes.doubleValue() / GEGA_BYTE.intValue()));
			quotaInfo.setExtraGbUpload(Double.valueOf(UploadBytes.doubleValue() / GEGA_BYTE.intValue()));
		}
		return quotaInfo;
	}
	
	private void updateUserNasSessionBasedOnNewAccount(Integer userId) {
		try {
			String sql = "SELECT UserNasSession.Id FROM UserNasSession WHERE   UserNasSession.UserId = " + userId + " ORDER BY UserNasSession.Id DESC LIMIT 0, 1";
			RecordSet recordSet = (new QueryEngine()).executeSql(sql);
			if (recordSet != null && recordSet.size() > 0) {
				Record record = (Record) recordSet.get(0);
				Integer id = record.getIntegerValue("Id");
				if (id != null && id.intValue() > 0) {
					Table tableDef = new Table("UserNasSession", "Id", Boolean.valueOf(false));
					tableDef.setPkFieldValue(id);
					tableDef.addFieldValue("DownloadBytes", Integer.valueOf(0));
					tableDef.addFieldValue("UploadBytes", Integer.valueOf(0));
					tableDef.addFieldValue("FreeDownloadBytes", Integer.valueOf(0));
					tableDef.addFieldValue("FreeUploadBytes", Integer.valueOf(0));
					(new QueryEngine()).updateData(tableDef);
				}
			}
		} catch (Exception e) {
			System.err.println(e);
		}
	}
	
	private void addFieldToResetUserQuota(Table tableDef) {
		tableDef.addFieldValue("DownloadBytes", Integer.valueOf(0));
		tableDef.addFieldValue("UploadBytes", Integer.valueOf(0));
		tableDef.addFieldValue("FreeDownloadBytes", Integer.valueOf(0));
		tableDef.addFieldValue("FreeUploadBytes", Integer.valueOf(0));
		tableDef.addFieldValue("ExtraUploadGB", Integer.valueOf(0));
		tableDef.addFieldValue("ExtraDownloadGB", Integer.valueOf(0));
		tableDef.addFieldValue("AddedHours", Integer.valueOf(0));
	}
}
/*
 * Location:
 * C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server
 * \dao\account\ChangeAccountTypeDao.class Java compiler version: 7 (51.0)
 * JD-Core Version: 1.1.3
 */