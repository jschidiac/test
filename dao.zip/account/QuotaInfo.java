package me.iradius.server.dao.account;

public class QuotaInfo
{
  private Double extraGbDownload = Double.valueOf(0.0D);
  private Double extraGbUpload = Double.valueOf(0.0D);
  
  public Double getExtraGbDownload() {
    return this.extraGbDownload;
  }
  
  public void setExtraGbDownload(Double extraGbDownload) {
    this.extraGbDownload = extraGbDownload;
  }
  
  public Double getExtraGbUpload() {
    return this.extraGbUpload;
  }
  
  public void setExtraGbUpload(Double extraGbUpload) {
    this.extraGbUpload = extraGbUpload;
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\account\QuotaInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */