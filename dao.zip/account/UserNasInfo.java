package me.iradius.server.dao.account;

import java.util.Date;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;


public class UserNasInfo
{
  private Integer dealerId;
  private Date expiryDate;
  private Double credit;
  private Double downloadBytes;
  private Double uploadBytes;
  private Integer oldAccountTypeId;
  private Integer tempExpiryAccount;
  private Boolean noCharge;
  
  public static UserNasInfo getUserNasInfo(Integer userId) throws Exception {
    String sql = "SELECT User.ParentId,   ExpiryAccount , Dealer.Credit , DownloadBytes , UploadBytes, OldAccountTypeId, TempExpiryAccount, Dealer.NoCharge   from UserNas  LEFT OUTER JOIN AccountType  on AccountType.Id = UserNas.AccountTypeId  LEFT OUTER JOIN User User on User.Id = UserNas.UserId  LEFT OUTER JOIN Dealer Dealer on Dealer.UserId = User.ParentId  WHERE UserNas.UserId = " + 



      
      userId;
    RecordSet recordSet = (new QueryEngine()).executeSql(sql);
    if (recordSet.size() > 0) {
      Record record = (Record)recordSet.get(0);
      
      UserNasInfo userNasInfo = new UserNasInfo();
      userNasInfo.setDealerId(record.getIntegerValue("ParentId"));
      userNasInfo.setExpiryDate(record.getDateValue("ExpiryAccount"));
      userNasInfo.setCredit(record.getDoubleValue("Credit"));
      userNasInfo.setDownloadBytes(record.getDoubleValue("DownloadBytes"));
      userNasInfo.setUploadBytes(record.getDoubleValue("UploadBytes"));
      userNasInfo.setTempExpiryAccount(record.getIntegerValue("TempExpiryAccount"));
      userNasInfo.setOldAccountTypeId(record.getIntegerValue("OldAccountTypeId"));
      userNasInfo.setNoCharge(record.getBooleanValue("NoCharge"));
      
      return userNasInfo;
    } 
    return null;
  }
  
  public Integer getDealerId() {
    return this.dealerId;
  }
  
  public void setDealerId(Integer dealerId) {
    this.dealerId = dealerId;
  }
  
  public Date getExpiryDate() {
    return this.expiryDate;
  }
  
  public void setExpiryDate(Date expiryDate) {
    this.expiryDate = expiryDate;
  }
  
  public Double getCredit() {
    return this.credit;
  }
  
  public void setCredit(Double credit) {
    credit = Double.valueOf((credit == null) ? 0.0D : credit.doubleValue());
    this.credit = credit;
  }
  
  public Double getDownloadBytes() {
    return this.downloadBytes;
  }
  
  public void setDownloadBytes(Double downloadBytes) {
    this.downloadBytes = downloadBytes;
  }
  
  public Double getUploadBytes() {
    return this.uploadBytes;
  }
  
  public void setUploadBytes(Double uploadBytes) {
    this.uploadBytes = uploadBytes;
  }
  
  public Integer getOldAccountTypeId() {
    return this.oldAccountTypeId;
  }
  
  public void setOldAccountTypeId(Integer oldAccountTypeId) {
    this.oldAccountTypeId = oldAccountTypeId;
  }
  
  public Integer getTempExpiryAccount() {
    return this.tempExpiryAccount;
  }
  
  public void setTempExpiryAccount(Integer tempExpiryAccount) {
    this.tempExpiryAccount = tempExpiryAccount;
  }
  
  public void setNoCharge(Boolean noCharge) {
    this.noCharge = noCharge;
  }
  
  public Boolean getNoCharge() {
    return this.noCharge;
  }
  
  public Float getuserConsumedMB() {
    Float consumed = Float.valueOf(((getDownloadBytes() != null) ? 
        getDownloadBytes().floatValue() : (
        new Float(0.0F)).floatValue()) + (
        (getUploadBytes() != null) ? getUploadBytes().floatValue() : (new Float(0.0F)).floatValue()));
    
    consumed = Float.valueOf((consumed != null) ? consumed.floatValue() : 0.0F);
    consumed = Float.valueOf(consumed.floatValue() / 1048576.0F);
    return consumed;
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\account\UserNasInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */