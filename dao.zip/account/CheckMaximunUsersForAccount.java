package me.iradius.server.dao.account;

import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;

public class CheckMaximunUsersForAccount
{
  public boolean checkMaxUsersForRelatedAccount(Integer accountTypeId) throws Exception {
    String sql = "Select MaxUsers , (Select count(UserId) From UserNas Where AccountTypeId = AccountType.Id ) as UserCount  From AccountType  Where Id = " + 
      
      accountTypeId;
    RecordSet recordSet = (new QueryEngine()).executeSql(sql);
    if (recordSet.size() > 0) {
      Record record = (Record)recordSet.get(0);
      Integer acctMaxUsers = record.getIntegerValue("MaxUsers");
      if (acctMaxUsers != null && acctMaxUsers.intValue() > 0) {
        Integer cuurentAccUsers = record.getIntegerValue("UserCount");
        if (cuurentAccUsers.intValue() >= acctMaxUsers.intValue())
          return false; 
      } 
    } 
    return true;
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\account\CheckMaximunUsersForAccount.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */