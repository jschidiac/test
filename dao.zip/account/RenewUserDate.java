package me.iradius.server.dao.account;

import java.util.Date;

public class RenewUserDate
{
  private Date expiryDate;
  private Date OverrideExpiryAccount;
  private Integer forceExpiryAfterDays;
  
  public Date getExpiryDate() {
    return this.expiryDate;
  }
  
  public void setExpiryDate(Date expiryDate) {
    this.expiryDate = expiryDate;
  }
  
  public Date getOverrideExpiryAccount() {
    return this.OverrideExpiryAccount;
  }
  
  public void setOverrideExpiryAccount(Date overrideExpiryAccount) {
    this.OverrideExpiryAccount = overrideExpiryAccount;
  }
  
  public Integer getForceExpiryAfterDays() {
    return this.forceExpiryAfterDays;
  }
  
  public void setForceExpiryAfterDays(Integer forceExpiryAfterDays) {
    this.forceExpiryAfterDays = forceExpiryAfterDays;
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\account\RenewUserDate.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */