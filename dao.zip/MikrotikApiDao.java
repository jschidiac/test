package me.iradius.server.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;

import me.iradius.mikrotik.api.MikrotikApi;
import me.iradius.mikrotik.api.ServerInfo;
import me.iradius.mikrotik.api.legrange.mikrotik.impl.Result;
import me.iradius.server.ctxt.AppContext;
import me.iradius.server.engine.QueryEngine;
import me.iradius.server.socket.RadiusSocketCLient;
import me.iradius.server.socket.SocketDef;
import me.iradius.shared.db.DbUtils;
import me.iradius.shared.divers.NasDef;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.MonitorNas;

public class MikrotikApiDao {
	
	private SocketDef getSocketDef() {
		return (SocketDef) AppContext.getBean("socket");
	}
	
	private void disconnectLogTrace(String message) {
	}
	
	private MikrotikApi getMikrotikApiByRecordSet(RecordSet recordSet) throws Exception {
		MikrotikApi mikrotikApi = null;
		if (recordSet != null && recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			String hostName = record.getStringValue("Host");
			Integer port = record.getIntegerValue("ApiPort");
			String user = record.getStringValue("ApiUserName");
			String password = record.getStringValue("ApiPassword");
			mikrotikApi = new MikrotikApi(hostName, port, user, password);
		}
		return mikrotikApi;
	}
	
	public ArrayList<String> getServers(String nasHost) throws Exception {
		String sql = "SELECT  Host,  ApiPort, ApiUserName, ApiPassword FROM  Nas WHERE Host = " + DbUtils.dblQuotedField(nasHost);
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		MikrotikApi mikrotikApi = getMikrotikApiByRecordSet(recordSet);
		if (mikrotikApi != null && mikrotikApi.getConnection() != null) {
			(new QueryEngine()).deleteRecord("NasServers", "NasHost", DbUtils.dblQuotedField(nasHost));
			try {
				ArrayList<ServerInfo> services = mikrotikApi.getServices();
				ArrayList<String> arrayList = new ArrayList<>();
				for (ServerInfo serverInfo : services) {
					arrayList.add(serverInfo.getServiceName());
					String insertSql = "INSERT INTO NasServers (NasHost,Server) VALUES(" + DbUtils.dblQuotedField(nasHost) + "," + DbUtils.dblQuotedField(serverInfo.getServiceName()) + ")";
					(new QueryEngine()).updateData(insertSql);
				}
				return arrayList;
			} catch (Exception e) {
				if (mikrotikApi.getConnection() == null) {
					throw new Exception("Mikrotik Connection problem.");
				}
				throw new Exception("Missing Nas Configuration.");
			}
		}
		ArrayList<String> list = new ArrayList<>();
		sql = "SELECT  Server FROM  NasServers  WHERE NasHost = " + DbUtils.dblQuotedField(nasHost);
		recordSet = (new QueryEngine()).executeSql(sql);
		for (Record record : recordSet)
			list.add(record.getStringValue("Server"));
		return list;
	}
	
	public void disconnectUser(Integer userId) throws Exception {
		try {
			String sql = "SELECT  Host,  ApiPort, ApiUserName, ApiPassword , SharedSecret, UserNas.MikrotikUser, User.UserName  FROM UserNas \tLEFT OUTER JOIN User on User.Id = UserNas.UserId \tLEFT OUTER JOIN Nas on Nas.Host = UserNas.NasHost   WHERE UserId = "
					+ userId;
			RecordSet recordSet = (new QueryEngine()).executeSql(sql);
			if (recordSet != null && recordSet.size() > 0) {
				Record record = (Record) recordSet.get(0);
				String nasHost = record.getStringValue("Host");
				String sharedSecret = record.getStringValue("SharedSecret");
				String userName = ((Record) recordSet.get(0)).getStringValue("UserName");
				String nasUser = ((Record) recordSet.get(0)).getStringValue("MikrotikUser");
				if (nasUser == null || nasUser.isEmpty()) {
					nasUser = userName;
				}
				Boolean isuSerDisconneted = Boolean.valueOf(false);
				if (nasHost != null && !nasHost.isEmpty()) {
					disconnectLogTrace(String.valueOf(userName) + " Disconnect Without API ");
					try {
						(new MikrotikDisconnectUtils()).disconnectMikrotikByRadiusClient(nasHost, sharedSecret, nasUser);
						disconnectLogTrace(String.valueOf(nasHost) + " Disconnected user  [" + userName + "]    Without API ");
						isuSerDisconneted = Boolean.valueOf(true);
					} catch (Exception e) {
						isuSerDisconneted = Boolean.valueOf(false);
						disconnectLogTrace(String.valueOf(nasHost) + " --- Disconnect User :: [" + userName + "]  By RadiusClient Error :: " + e.getMessage());
					}
				}
				if (!isuSerDisconneted.booleanValue()) {
					disconnectLogTrace(String.valueOf(userName) + " Disconnect By API ");
					MikrotikApi mikrotikApi = getMikrotikApiByRecordSet(recordSet);
					try {
						if (mikrotikApi != null) {
							Boolean hotspot = Boolean.valueOf(true);
							Object object = mikrotikApi.executeCommand("/ip/hotspot/active/print where user=" + nasUser);
							LinkedList<Result> linkedList = (LinkedList<Result>) object;
							if (linkedList.size() == 0) {
								object = mikrotikApi.executeCommand("/ppp/active/print where name=" + userName);
								linkedList = (LinkedList<Result>) object;
								hotspot = Boolean.valueOf(false);
							}
							Iterator<Result> iterator = linkedList.iterator();
							if (iterator.hasNext()) {
								Result result = iterator.next();
								String id = result.get(".id");
								String deleteCommand = null;
								if (hotspot.booleanValue()) {
									deleteCommand = "/ip/hotspot/active/remove .id=" + id;
								} else {
									deleteCommand = "/ppp/active/remove .id=" + id;
								}
								mikrotikApi.executeCommand(deleteCommand);
								disconnectLogTrace(String.valueOf(nasHost) + " --- Disconnected User :: [" + userName + "]  By API ");
							}
						}
					} finally {
						if (mikrotikApi != null) {
							mikrotikApi.disconnect();
						}
					}
				}
			}
		} catch (Exception exception) {
		}
	}
	
	public ArrayList<NasDef> getNasServers() throws Exception {
		String sql = "SELECT  Nas.Host, ShortName, Server    FROM Nas \tLEFT OUTER JOIN NasServers  on Nas.Host = NasServers.NasHost  order by ShortName, Server ";
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		ArrayList<NasDef> nasDefs = new ArrayList<>();
		if (recordSet != null) {
			String nasName = "";
			NasDef nasDef = null;
			for (Record record : recordSet) {
				String recordNasName = record.getStringValue("ShortName");
				if (recordNasName == null || recordNasName.isEmpty())
					continue;
				if (!nasName.equals(recordNasName)) {
					nasDef = new NasDef();
					nasDefs.add(nasDef);
					nasDef.setName(recordNasName);
					nasDef.setHost(record.getStringValue("Host"));
					nasName = recordNasName;
				}
				String serverName = record.getStringValue("Server");
				if (nasDef != null && serverName != null && !serverName.isEmpty()) {
					nasDef.getServers().add(serverName);
				}
			}
		}
		return nasDefs;
	}
	
	public void disconnectNasUsers(String nasHost) throws Exception {
		String sql = "UPDATE UserNas set Online = 0 , IpAddress = null where NasHost = " + DbUtils.dblQuotedField(nasHost);
		(new QueryEngine()).updateData(sql);
		(new RadiusSocketCLient(getSocketDef())).refreshDictionnary("8:" + nasHost);
	}
	
	public void transferUsersToNas(Integer accountTypeId, String accountName, Integer nasId) throws Exception {
		try {
			String sql = "SELECT Host, ApiPort, ApiUserName, ApiPassword FROM Nas WHERE Id = " + nasId;
			RecordSet recordSet = (new QueryEngine()).executeSql(sql);
			if (recordSet.size() > 0) {
				Record record = (Record) recordSet.get(0);
				String Host = record.getStringValue("Host");
				Integer ApiPort = record.getIntegerValue("ApiPort");
				String ApiUserName = record.getStringValue("ApiUserName");
				String ApiPassword = record.getStringValue("ApiPassword");
				MikrotikApi mikrotikApi = new MikrotikApi(Host, ApiPort, ApiUserName, ApiPassword);
				try {
					Object object = mikrotikApi.executeCommand("/ppp/secret/print where disabled=yes");
					LinkedList<Result> linkedList = (LinkedList<Result>) object;
					for (Result result : linkedList) {
						String profile = result.get("profile");
						if (accountName.equals(profile)) {
							String id = result.get(".id");
							String removeCommand = "/ppp/secret/remove .id=" + id;
							mikrotikApi.executeCommand(removeCommand);
						}
					}
					sql = "SELECT AccountTypeName , UserName , Password From UserNas left outer join User  on User.Id = UserNas.UserId left outer join AccountType  on AccountType.Id = UserNas.AccountTypeId  WHERE AccountType.Id = " + accountTypeId;
					recordSet = (new QueryEngine()).executeSql(sql);
					if (recordSet != null) {
						for (Record userRec : recordSet) {
							String userName = userRec.getStringValue("UserName");
							String password = userRec.getStringValue("Password");
							String profile = userRec.getStringValue("AccountTypeName");
							String apiCommand = "/ppp/secret/add ";
							apiCommand = String.valueOf(apiCommand) + "name=" + userName + " password=" + password + " service=pppoe profile=" + profile + " disabled=yes ";
							try {
								mikrotikApi.executeCommand(apiCommand);
							} catch (Exception exception) {
							}
						}
					}
				} finally {
					if (mikrotikApi != null)
						mikrotikApi.disconnect();
				}
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public void transferUsersToNasByDealer(Integer dealerId, String dealerUserName, Integer nasId) throws Exception {
		try {
			String sql = "SELECT Host, ApiPort, ApiUserName, ApiPassword FROM Nas WHERE Id = " + nasId;
			RecordSet recordSet = (new QueryEngine()).executeSql(sql);
			if (recordSet.size() > 0) {
				Record record = (Record) recordSet.get(0);
				String Host = record.getStringValue("Host");
				Integer ApiPort = record.getIntegerValue("ApiPort");
				String ApiUserName = record.getStringValue("ApiUserName");
				String ApiPassword = record.getStringValue("ApiPassword");
				MikrotikApi mikrotikApi = new MikrotikApi(Host, ApiPort, ApiUserName, ApiPassword);
				try {
					Object object = mikrotikApi.executeCommand("/ppp/secret/print where disabled=yes");
					LinkedList<Result> linkedList = (LinkedList<Result>) object;
					for (Result result : linkedList) {
						String profile = result.get("profile");
						if (dealerUserName.equals(profile)) {
							String id = result.get(".id");
							String removeCommand = "/ppp/secret/remove .id=" + id;
							mikrotikApi.executeCommand(removeCommand);
						}
					}
					sql = "SELECT  UserName , Password From UserNas left outer join User  on User.Id = UserNas.UserId  WHERE User.ParentId = " + dealerId;
					recordSet = (new QueryEngine()).executeSql(sql);
					if (recordSet != null) {
						for (Record userRec : recordSet) {
							String userName = userRec.getStringValue("UserName");
							String password = userRec.getStringValue("Password");
							String apiCommand = "/ppp/secret/add ";
							apiCommand = String.valueOf(apiCommand) + "name=" + userName + " password=" + password + " service=pppoe profile=" + dealerUserName + " disabled=yes ";
							try {
								mikrotikApi.executeCommand(apiCommand);
							} catch (Exception exception) {
							}
						}
					}
				} finally {
					if (mikrotikApi != null)
						mikrotikApi.disconnect();
				}
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	@SuppressWarnings("unchecked")
	public String getMikrotikUpTimeForUser(Integer userId, String userName) throws Exception {
		String sql = "SELECT Host, ApiPort, ApiUserName, ApiPassword  FROM Nas   Left Outer join UserNas ON UserNas.NasHost = Nas.Host   Where UserNas.UserId =  " + userId;
		RecordSet recordSet = new QueryEngine().executeSql(sql);
		if (recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			String Host = record.getStringValue("Host");
			Integer ApiPort = record.getIntegerValue("ApiPort");
			String ApiUserName = record.getStringValue("ApiUserName");
			String ApiPassword = record.getStringValue("ApiPassword");
			MikrotikApi mikrotikApi = new MikrotikApi(Host, ApiPort, ApiUserName, ApiPassword);
			try {
				String IP_SESSIONS_COMMAND = "/ppp/active/print without-paging";
				Object executeCommand = mikrotikApi.executeCommand(IP_SESSIONS_COMMAND);
				LinkedList<Result> linkedList = (LinkedList<Result>) executeCommand;
				for (Result result : linkedList) {
					String upTime;
					String mikUserName = result.get("name");
					if (!userName.equalsIgnoreCase(mikUserName))
						continue;
					upTime = result.get("uptime");
					return upTime;
				}
			} finally {
				try {
					mikrotikApi.disconnect();
				} catch (Exception exception) {
				}
			}
		}
		return null;
	}
	
	public boolean apiTest(String host, Integer port, String userName, String password) throws Exception {
		return true;
	}
	
	public MonitorNas userNasInofrmation(Integer userId) throws Exception {
		MonitorNas monitorNas = new MonitorNas();
		monitorNas.setDate(new Date());
		String sql = "SELECT MikrotikQueue, MikrotikUser, Host, ApiPort, ApiUserName, ApiPassword  FROM Nas   Left Outer join UserNas ON UserNas.NasHost = Nas.Host   Where UserNas.UserId =  " + userId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			String MikrotikUser = record.getStringValue("MikrotikUser");
			String Host = record.getStringValue("Host");
			Integer ApiPort = record.getIntegerValue("ApiPort");
			String ApiUserName = record.getStringValue("ApiUserName");
			String ApiPassword = record.getStringValue("ApiPassword");
			MikrotikApi mikrotikApi = new MikrotikApi(Host, ApiPort, ApiUserName, ApiPassword);
			try {
				String command = "/queue/simple/print detail where name=\"<pppoe-" + MikrotikUser + ">\"";
				Object executeCommand = mikrotikApi.executeCommand(command);
				LinkedList<Result> linkedList = (LinkedList<Result>) executeCommand;
				for (Result result : linkedList) {
					String rate = result.get("rate");
					String limitAt = result.get("limit-at");
					Integer pos = Integer.valueOf(limitAt.indexOf("/"));
					Integer limitUpload = Integer.valueOf(Integer.parseInt(limitAt.substring(0, pos.intValue())));
					Integer limitDownload = Integer.valueOf(Integer.parseInt(limitAt.substring(pos.intValue() + 1, limitAt.length())));
					Integer divideByKB = Integer.valueOf(1024);
					monitorNas.setLimitUp(new Float((limitUpload.intValue() / divideByKB.intValue())));
					monitorNas.setLimitDown(new Float((limitDownload.intValue() / divideByKB.intValue())));
					pos = Integer.valueOf(rate.indexOf("/"));
					Integer rateUpload = Integer.valueOf(Integer.parseInt(rate.substring(0, pos.intValue())));
					Integer rateDownload = Integer.valueOf(Integer.parseInt(rate.substring(pos.intValue() + 1, rate.length())));
					monitorNas.setCurrentUp(new Float((rateUpload.intValue() / divideByKB.intValue())));
					monitorNas.setCurrentDown(new Float((rateDownload.intValue() / divideByKB.intValue())));
				}
			} catch (Exception exception) {
				try {
					mikrotikApi.disconnect();
				} catch (Exception exception1) {
				}
			} finally {
				try {
					mikrotikApi.disconnect();
				} catch (Exception exception) {
				}
			}
		}
		return monitorNas;
	}
}
/*
 * Location:
 * C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server
 * \dao\MikrotikApiDao.class Java compiler version: 7 (51.0) JD-Core Version:
 * 1.1.3
 */