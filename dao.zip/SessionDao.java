package me.iradius.server.dao;

import java.util.Date;
import me.iradius.server.cfg.InvoiceNbrGenerated;
import me.iradius.server.ctxt.AppContext;
import me.iradius.server.ctxt.SessionUtil;
import me.iradius.server.dealer.DealerConfiguration;
import me.iradius.server.engine.QueryEngine;
import me.iradius.server.license.IRadiusLicenseManager;
import me.iradius.server.netflow.ExcludeIpAddressConf;
import me.iradius.server.system.IRadiusSecurity;
import me.iradius.shared.SharedConst;
import me.iradius.shared.db.DbUtils;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.Session;
import me.iradius.shared.session.SessionType;

public class SessionDao {
	
	private void checkInjecttion(String value) throws Exception {
		if (value != null) {
			String newPaw = value.toUpperCase();
			if (newPaw.contains("SELECT ") || newPaw.contains("COUNT(*)") || newPaw.contains(" OR ") || newPaw.contains(" FROM ") || newPaw.contains("INSERT ") || newPaw.contains("UPDATE ") || newPaw.contains("DROP ") || newPaw.contains("CREATE ")
					|| newPaw.contains("INFORMATION_SCHEMA") || newPaw.contains("COLLATIONS")) {
				throw new Exception("Injection Failed");
			}
		}
	}
	
	public Session login(Integer userId, String userName, String password) throws Exception {
		checkInjecttion(userName);
		checkInjecttion(password);
		String sql = "SELECT  User.Id,User.Password, User.FirstName, User.LastName, User.Mobile, User.Phone, User.LastLogin," //
				+ " User.CollectorResetMacAddress, User.CollectorCanShowLinks, User.MailAddress, User.Address, " //
				+ " User.Comment, Profile.Guid as ProfileGuid,   " //
				+ "Dealer.Id as DealerId, Dealer.FirstName as DealerFirstName, Dealer.LastName as DealerLastName, " //
				+ "Dealer.Comment as DealerNotification,          Viewer.CanChangePhone, Viewer.CanResetMacAddress," //
				+ " Viewer.CanRenewUser, Viewer.CanChangeFirstName,Viewer.CanChangeMobile,  Viewer.CanRefillCode," //
				+ " Viewer.CanChangeUserName, Viewer.CanChangeLastName, Viewer.CanChangeAddress, Viewer.CanChangeMail, " //
				+ "Viewer.CanChangePassword, Viewer.CanDisconnectUser, Viewer.CanAddUserBytes , Viewer.CanChangeUserAccount," //
				+ " Viewer.CanChangeActive, Viewer.CanChangeAutoRenew, Viewer.CanShowUserLog,  Viewer.CanDeleteUser, " //
				+ "Viewer.CanShowSpeed as viewerCanShowSpeed ,  DealerTbl.Logo,  DealerTbl.CanShowOnlineUsersSpeed as DealerCanShowOnlineUsersSpeed ,"//
				+ "DealerTbl.UserNotification, DealerTbl.CanShowSpeed as ViewerCanShowSpeed,   " //
				+ "UserNas.CanShowTraficDetails, UserNas.ExpiryAccount, AccountType.CanShowOnUserInterface,   " //
				+ " UserAsDealerTbl.NoCharge, UserAsDealerTbl.Credit, UserAsDealerTbl.Commision , " //
				+ "UserAsDealerTbl.CompanyVatNumber ,UserAsDealerTbl.CanShowRate , " //
				+ "UserAsDealerTbl.CanShowSpeed, UserAsDealerTbl.CanShowOnlineUsersSpeed, UserAsDealerTbl.CanChangeAccountType, " //
				+ "UserAsDealerTbl.CanDeleteUser as DealerCanDeleteUser,  UserAsDealerTbl.ExtraGB, " //
				+ "  UserAsDealerTbl.NotificationAmount,  UserAsDealerTbl.SmsSenderId, UserAsDealerTbl.FupResetPrice, " //
				+ "UserAsDealerTbl.ExtraOneGPPrice, UserAsDealerTbl.CanExportToExcel, UserAsDealerTbl.CanAddDealer,       " //
				+ "   UserAsDealerTbl.CanMonitorLog as UserAsDealerTblCanMonitorLog, DealerTbl.CanMonitorLog as DealerTblCanMonitorLog " //
				+ " FROM User User  LEFT OUTER JOIN Profile on Profile.Id = User.ProfileId " //
				+ " LEFT OUTER JOIN UserNas UserNas on UserNas.UserId = User.Id  " //
				+ "LEFT OUTER JOIN User Dealer on User.ParentId = Dealer.Id      " //
				+ "LEFT OUTER JOIN Viewer Viewer on Viewer.UserId = User.Id      " //
				+ "LEFT OUTER JOIN Dealer DealerTbl on DealerTbl.UserId = Dealer.Id      " //
				+ "LEFT OUTER JOIN Dealer UserAsDealerTbl on UserAsDealerTbl.UserId = User.Id      " //
				+ "LEFT OUTER JOIN AccountType AccountType on AccountType.Id = UserNas.AccountTypeId  WHERE ";
		if (userId != null) {
			sql = String.valueOf(sql) + "User.Id = " + userId;
		} else {
			sql = String.valueOf(sql) + "User.UserName = " + DbUtils.dblQuotedField(userName);
		}
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet != null && recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			SessionType sessionType = SharedConst.getSessionType(record.getStringValue("ProfileGuid"));
			if (userId == null) {
				try {
					String dbPassword = record.getStringValue("Password");
					Boolean matches = Boolean.valueOf(false);
					if (SessionType.USER.equals(sessionType)) {
						matches = Boolean.valueOf((dbPassword != null && dbPassword.equalsIgnoreCase(password)));
					} else {
						matches = Boolean.valueOf(IRadiusSecurity.matches(password, dbPassword));
					}
					if (!matches.booleanValue()) {
						throw new Exception("Invalid User Name/ Password !");
					}
				} catch (Exception e) {
					throw new Exception("Invalid User Name/ Password !");
				}
			}
			Session ispSession = new Session();
			ispSession.setUserName(userName);
			ispSession.setPassword(password);
			ispSession.setId((Integer) record.getValue("Id"));
			ispSession.setLastLogin(record.getDateValue("LastLogin"));
			ispSession.setFirstName(record.getStringValue("FirstName"));
			ispSession.setLastName(record.getStringValue("LastName"));
			ispSession.setMobile(record.getStringValue("Mobile"));
			ispSession.setPhone(record.getStringValue("Phone"));
			ispSession.setMailAddress(record.getStringValue("MailAddress"));
			ispSession.setAddress(record.getStringValue("Address"));
			ispSession.setComment(record.getStringValue("Comment"));
			ispSession.setSessionType(sessionType);
			ispSession.setDealerId((Integer) record.getValue("DealerId"));
			if (sessionType.equals(SessionType.VIEWER)) {
				ispSession.setCanChangePhone(record.getBooleanValue("CanChangePhone"));
				ispSession.setCanResetMacAddress(record.getBooleanValue("CanResetMacAddress"));
				ispSession.setCanRenewUser(record.getBooleanValue("CanRenewUser"));
				ispSession.setCanChangeFirstName(record.getBooleanValue("CanChangeFirstName"));
				ispSession.setCanChangeUserName(record.getBooleanValue("CanChangeUserName"));
				ispSession.setCanChangeLastName(record.getBooleanValue("CanChangeLastName"));
				ispSession.setCanChangeAddress(record.getBooleanValue("CanChangeAddress"));
				ispSession.setCanChangeMail(record.getBooleanValue("CanChangeMail"));
				ispSession.setCanChangePassword(record.getBooleanValue("CanChangePassword"));
				ispSession.setCanDisconnectUser(record.getBooleanValue("CanDisconnectUser"));
				ispSession.setCanChangeMobile(record.getBooleanValue("CanChangeMobile"));
				ispSession.setCanAddUserBytes(record.getBooleanValue("CanAddUserBytes"));
				ispSession.setCanChangeUserAccount(record.getBooleanValue("CanChangeUserAccount"));
				ispSession.setCanRefillCode(record.getBooleanValue("CanRefillCode"));
				ispSession.setCanShowOnlineUsersSpeed(record.getBooleanValue("DealerCanShowOnlineUsersSpeed"));
				ispSession.setCanChangeAutoRenew(record.getBooleanValue("CanChangeAutoRenew"));
				ispSession.setCanChangeActive(record.getBooleanValue("CanChangeActive"));
				ispSession.setCanShowUserLog(record.getBooleanValue("CanShowUserLog"));
				ispSession.setCanShowSpeedField(record.getBooleanValue("viewerCanShowSpeed"));
				ispSession.setCanDeleteUser(record.getBooleanValue("CanDeleteUser"));
				ispSession.setCanShowSpeed(record.getBooleanValue("ViewerCanShowSpeed"));
				ispSession.setCanMonitorLog(record.getBooleanValue("DealerTblCanMonitorLog"));
				InvoiceNbrGenerated invoiceNbrGenerated = (InvoiceNbrGenerated) AppContext.getBean("invoiceNbrGenerated");
				ispSession.setTva(invoiceNbrGenerated.getTva(ispSession.getDealerId()));
			} else if (sessionType.equals(SessionType.COLLECTOR)) {
				ispSession.setCanMonitorLog(record.getBooleanValue("DealerTblCanMonitorLog"));
				ispSession.setCollectorResetMacAddress(record.getBooleanValue("CollectorResetMacAddress"));
				ispSession.setCollectorCanShowMonitor(record.getBooleanValue("CollectorCanShowLinks"));
			} else if (sessionType.equals(SessionType.USER)) {
				ispSession.setCanShowOnlineUsersSpeed(Boolean.valueOf(false));
				ispSession.setCanShowTrafficDetails(record.getBooleanValue("CanShowTraficDetails"));
				ispSession.setDealerLogo(record.getStringValue("Logo"));
				ispSession.setCanDisplayAccOnUserInt(record.getBooleanValue("CanShowOnUserInterface"));
				ispSession.setNotification(record.getStringValue("UserNotification"));
				Date date = record.getDateValue("ExpiryAccount");
				ispSession.setSessionExpired(Boolean.valueOf(date.before(new Date())));
			} else if (sessionType.equals(SessionType.DEALER)) {
				ispSession.setDealerCredit(record.getDoubleValue("Credit"));
				ispSession.setDealerCommission(record.getDoubleValue("Commision"));
				ispSession.setCanShowRate(record.getBooleanValue("CanShowRate"));
				ispSession.setCanShowSpeed(record.getBooleanValue("CanShowSpeed"));
				ispSession.setCanShowOnlineUsersSpeed(record.getBooleanValue("CanShowOnlineUsersSpeed"));
				ispSession.setCanExportToExcel(record.getBooleanValue("CanExportToExcel"));
				ispSession.setCanAddDealer(record.getBooleanValue("CanAddDealer"));
				ispSession.setFupResetPrice(record.getFloatValue("FupResetPrice"));
				ispSession.setCanAddUserBytes(record.getBooleanValue("ExtraGB"));
				ispSession.setNotificationAmount(record.getFloatValue("NotificationAmount"));
				ispSession.setSmsSenderId(record.getStringValue("SmsSenderId"));
				ispSession.setExtraOneGPPrice(record.getFloatValue("ExtraOneGPPrice"));
				ispSession.setNotification(record.getStringValue("DealerNotification"));
				ispSession.setCompanyVatNumber(record.getStringValue("CompanyVatNumber"));
				ispSession.setCanChangeUserAccount(record.getBooleanValue("CanChangeAccountType"));
				ispSession.setCanDeleteUser(record.getBooleanValue("DealerCanDeleteUser"));
				InvoiceNbrGenerated invoiceNbrGenerated = (InvoiceNbrGenerated) AppContext.getBean("invoiceNbrGenerated");
				ispSession.setTva(invoiceNbrGenerated.getTva(ispSession.getId()));
				ispSession.setCanMonitorLog(record.getBooleanValue("UserAsDealerTblCanMonitorLog"));
				ispSession.setNoCharge(record.getBooleanValue("NoCharge"));
				assignSubDealers(ispSession);
			} else if (sessionType.equals(SessionType.ADMIN)) {
				assignSubDealers(ispSession);
			}
			assignSessionLayoutConf(ispSession);
			SessionUtil.registerSession(ispSession);
			ispSession.setSessionDate(new Date());
			IRadiusLicenseManager ispLicenseManager = (IRadiusLicenseManager) AppContext.getBean("lManager");
			ispSession.setV(ispLicenseManager.getValidDateLicense());
			ExcludeIpAddressConf excludeIpAddressConf = (ExcludeIpAddressConf) AppContext.getBean("excludeIPAddressConf");
			if (excludeIpAddressConf != null) {
				ispSession.setExistExcludeIpAddress(excludeIpAddressConf.getExcludeIp());
			}
			return ispSession;
		}
		throw new Exception("Invalid User Name/ Password !");
	}
	
	private void assignSubDealers(Session ispSession) throws Exception {
		DealerConfiguration dealerConfiguration = (DealerConfiguration) AppContext.getBean("dealerConfiguration");
		ispSession.setSybdealers(dealerConfiguration.getDealers(ispSession.getId()));
	}
	
	private void assignSessionLayoutConf(Session ispSession) throws Exception {
		String sql = "SELECT   InterfaceId, RecordPerPage  FROM UserLayoutConf WHERE UserId = " + ispSession.getId();
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet != null) {
			for (Record record : recordSet) {
				ispSession.getLayoutConf().addInterfaceConf(record.getIntegerValue("InterfaceId"), record.getIntegerValue("RecordPerPage"));
			}
		}
	}
	
	public void updateSessionLayoutconf(Integer userId, Integer interfaceId, Integer recPerPage) throws Exception {
		(new QueryEngine()).deleteRecord("UserLayoutConf", "UserId", userId.toString());
		String sqlInsert = "INSERT INTO UserLayoutConf(UserId,InterfaceId , RecordPerPage) Values( " + userId + "," + interfaceId + "," + recPerPage + ")";
		(new QueryEngine()).updateData(sqlInsert);
	}
	
	public Session checkSession(String clientIpAddress) throws Exception {
		IRadiusLicenseManager ispLicenseManager = (IRadiusLicenseManager) AppContext.getBean("lManager");
		if (ispLicenseManager.getValidDateLicense().booleanValue()) {
			String sql = "SELECT UserNas.UserId,    UserNas.ExpiryAccount  FROM UserNas  WHERE IpAddress = " + DbUtils.dblQuotedField(clientIpAddress) + " AND  Online = 1 ";
			RecordSet recordSet = (new QueryEngine()).executeSql(sql);
			if (recordSet != null && recordSet.size() > 0) {
				Record record = (Record) recordSet.get(0);
				Integer userId = record.getIntegerValue("UserId");
				Session session = login(userId, null, null);
				if (session != null) {
					Date date = record.getDateValue("ExpiryAccount");
					session.setSessionExpired(Boolean.valueOf(date.before(new Date())));
					return session;
				}
			}
			return null;
		}
		throw new Exception("Invalid License");
	}
}
