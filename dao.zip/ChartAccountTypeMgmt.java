package me.iradius.server.dao;

import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.record.IntegerValue;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.record.StringValue;
import me.iradius.shared.session.Session;
import me.iradius.shared.session.UserType;

public class ChartAccountTypeMgmt {
	
	private String getFiltertoAdd(UserType userType) {
		String filterToAdd = "";
		switch (userType) {
			case ACTIVE_USERS:
				filterToAdd = " AND UserNas.Active = 1 ";
				break;
			case ONLINE_USERS:
				filterToAdd = " AND UserNas.Online = 1 ";
				break;
			default:
				break;
		}
		return filterToAdd;
	}
	
	private Integer getAccountTypeByDealer(Integer accountTypeId, UserType userType, Integer dealerId) throws Exception {
		Integer count = 0;
		//
		//
		String filterToAdd = getFiltertoAdd(userType);
		String sql = "SELECT  AccountType.Id,  AccountTypeName ,  (Count(UserNas.UserId)) AS Count   " //
				+ "  FROM AccountType " //
				+ " LEFT OUTER JOIN UserNas ON UserNas.AccountTypeId = AccountType.Id " + filterToAdd; //
		sql += " Where AccountType.ParentId = " + accountTypeId;
		if (dealerId != null)
			sql += " AND AccountType.DealerId = " + dealerId;
		sql += " GROUP BY AccountType.Id";
		//
		//
		RecordSet accountTYpeRec = new QueryEngine().executeSql(sql);
		for (Record record : accountTYpeRec) {
			Integer localAcctTypeId = record.getIntegerValue("Id");
			if (localAcctTypeId != null) {
				Integer localcount = record.getIntegerValue("Count");
				if (localcount != null)
					count += localcount;
				count += getAccountTypeByDealer(localAcctTypeId, userType, null);
			}
		}
		return count;
	}
	
	//
	//
	public RecordSet getDealerAccountTypes(Session session, Boolean isAdmin, Integer dealerId, UserType userType) throws Exception {
		//
		//
		RecordSet recordSet = new RecordSet();
		recordSet.getFieldAliases().add("AccountType");
		recordSet.getFieldAliases().add("Count");
		//
		String filterToAdd = getFiltertoAdd(userType);
		String sql = "SELECT  AccountType.Id,  AccountTypeName ,  (Count(UserNas.UserId)) AS Count   " //
				+ "  FROM AccountType " //
				+ " LEFT OUTER JOIN UserNas ON UserNas.AccountTypeId = AccountType.Id " + filterToAdd; //
		//
		//
		Boolean addedWhere = false;
		if (isAdmin) {
			sql += " WHERE AccountType.ParentId IS NULL and AccountType.AdminId = " + session.getId();
			addedWhere = true;
		}
		//
		if (dealerId != null) {
			sql += addedWhere ? " AND " : " WHERE ";
			sql += " AccountType.DealerId = " + dealerId;
		}
		//
		sql += " GROUP BY AccountType.Id";
		//
		//
		RecordSet accountTYpeRec = new QueryEngine().executeSql(sql);
		for (Record record : accountTYpeRec) {
			Integer accountTypeId = record.getIntegerValue("Id");
			String accountTypeName = record.getStringValue("AccountTypeName");
			//
			//
			Integer accountTypeCount = 0;
			// if (!isAdmin) {
			Integer localcount = record.getIntegerValue("Count");
			if (localcount != null)
				accountTypeCount += localcount;
			// }
			//
			//
			accountTypeCount += getAccountTypeByDealer(accountTypeId, userType, isAdmin ? dealerId : null);
			//
			Record newRecord = new Record();
			newRecord.add(new StringValue(accountTypeName));
			newRecord.add(new IntegerValue(accountTypeCount));
			recordSet.add(newRecord);
		}
		//
		return recordSet;
	}
}
