package me.iradius.server.dao;

import java.util.ArrayList;
import me.iradius.server.cfg.InvoiceNbrGenerated;
import me.iradius.server.ctxt.AppContext;
import me.iradius.server.scheduler.Notification;
import me.iradius.server.scheduler.RememberRenewUserAccountScheduler;
import me.iradius.server.socket.RadiusSocketCLient;
import me.iradius.server.socket.SocketDef;
import me.iradius.shared.SharedConst;
import me.iradius.shared.db.Table;






public class InterfaceDaoManagement
{
  protected Integer modifiedUserId;
  protected Integer intefaceCode;
  protected AbstractDaoMgmt abstractDaoMgmt;
  
  public InterfaceDaoManagement(Integer modifiedUserId, Integer intefaceCode) {
    this.modifiedUserId = modifiedUserId;
    this.intefaceCode = intefaceCode;
  }
  
  public void onBeforeUpdate(ArrayList<Table> updateTableDefs) throws Exception {
    if (SharedConst.EXCLUDE_ADJUST_BANDWITH_INTERFACE.equals(this.intefaceCode)) {
      this.abstractDaoMgmt = new ExcludeAdjustBandwidthManagement();
    }
    if (this.abstractDaoMgmt != null)
      this.abstractDaoMgmt.executeBeforeUpdate(updateTableDefs); 
  }
  
  public void onBeforeUpdate(Table updateTableDef) throws Exception {
    if (SharedConst.BATCHCODE_INTERFACE.equals(this.intefaceCode)) {
      this.abstractDaoMgmt = new BatchCodeManagement(updateTableDef);
    } else if (SharedConst.USER_INTERFACE.equals(this.intefaceCode)) {
      this.abstractDaoMgmt = new UserManagement(this.modifiedUserId, updateTableDef);
    } else if (SharedConst.DEALER_INTERFACE.equals(this.intefaceCode)) {
      this.abstractDaoMgmt = new DealerManagement(updateTableDef);
    } else if (SharedConst.ADMIN_USER_INTERFACE.equals(this.intefaceCode) || SharedConst.VIEWER_INTERFACE.equals(this.intefaceCode) || SharedConst.ACCOUNTING_INTERFACE.equals(this.intefaceCode) || SharedConst.COLLECTOR_INTERFACE.equals(this.intefaceCode)) {
      this.abstractDaoMgmt = new PasswordManagement(updateTableDef);
    } 
    
    if (this.abstractDaoMgmt != null) {
      this.abstractDaoMgmt.executeBeforeUpdate();
    }
  }
  
  public void onAfterUpdate(Integer modifiedUserId, Integer pkFieldValue, Table updateTableDef) throws Exception {
    if (this.abstractDaoMgmt != null) {
      this.abstractDaoMgmt.executeAfterUpdate(modifiedUserId, updateTableDef, pkFieldValue);
    }
    
    if (SharedConst.ADJUST_BANDWIDTH_INTERFACE.equals(this.intefaceCode) && !updateTableDef.getInsertMode().booleanValue()) {
      (new ExcludeAdjustBandwidthManagement()).deleteExclude(pkFieldValue);
    } else if (SharedConst.EXCLUDE_ADJUST_BANDWITH_INTERFACE.equals(this.intefaceCode)) {
      (new RadiusSocketCLient(getSocketDef())).refreshDictionnary(RadiusSocketCLient.RefreshType.ADJUSTBANDWITH);
    } else if (SharedConst.NAS_INTERFACE.equals(this.intefaceCode)) {
      (new RadiusSocketCLient(getSocketDef())).refreshDictionnary("2:" + pkFieldValue);
    } else if (SharedConst.RADIUS_SETTING_INTERFACE.equals(this.intefaceCode)) {
      
      Notification notification = (Notification)AppContext.getBean("notification");
      notification.refresh();
      
      (new RadiusSocketCLient(getSocketDef())).refreshDictionnary(RadiusSocketCLient.RefreshType.RADIUS_SETTINGS);
    } else if (SharedConst.DEALER_INTERFACE.equals(this.intefaceCode) && updateTableDef.getTableName().equalsIgnoreCase("Dealer")) {
      RememberRenewUserAccountScheduler renewUserAccountScheduler = (RememberRenewUserAccountScheduler)AppContext.getBean("rememberToNewUserAccountScheduler");
      
      String SmsSenderId = (String)updateTableDef.getFieldValues().get("SmsSenderId");
      renewUserAccountScheduler.updateSmsSenderIdDealerInfo(pkFieldValue, SmsSenderId);
    }
    else if (SharedConst.UPDATE_DEALER_NOTIFICATION_INTERFACE.equals(this.intefaceCode)) {
      RememberRenewUserAccountScheduler renewUserAccountScheduler = (RememberRenewUserAccountScheduler)AppContext.getBean("rememberToNewUserAccountScheduler");
      Boolean CanSendMail = (Boolean)updateTableDef.getFieldValues().get("CanSendMail");
      Boolean CanSendSMS = (Boolean)updateTableDef.getFieldValues().get("CanSendSMS");
      Boolean NotifyBefore3Days = (Boolean)updateTableDef.getFieldValues().get("NotifyBefore3Days");
      Boolean NotifyBefore2Days = (Boolean)updateTableDef.getFieldValues().get("NotifyBefore2Days");
      Boolean NotifyBefore1Day = (Boolean)updateTableDef.getFieldValues().get("NotifyBefore1Day");
      
      Integer dealerId = updateTableDef.getPkFieldValue();
      renewUserAccountScheduler.updateDealerInfo(dealerId, CanSendMail, CanSendSMS, NotifyBefore3Days, NotifyBefore2Days, NotifyBefore1Day);
    } else if (SharedConst.ACCOUNTING_CONFIG_INTERFACE.equals(this.intefaceCode)) {
      InvoiceNbrGenerated invoiceNbrGenerated = (InvoiceNbrGenerated)AppContext.getBean("invoiceNbrGenerated");
      invoiceNbrGenerated.refresh();
    } else if (SharedConst.EXCLUDE_IP_ADDRESS_INTERFACE.equals(this.intefaceCode)) {
      (new RadiusSocketCLient(getSocketDef())).refreshDictionnary(RadiusSocketCLient.RefreshType.REFRESH_EXCLUDE_IPADDRESS);
    } 
  }
  
  private SocketDef getSocketDef() {
    return (SocketDef)AppContext.getBean("socket");
  }
  
  public void onBeforeUpdate(Table updateTableDef, Table updateDetailTableDef) throws Exception {
    onBeforeUpdate(updateTableDef);
    if (updateDetailTableDef != null)
      onBeforeUpdate(updateDetailTableDef); 
  }
  
  public void onAfterUpdate(Integer modifiedUserId, Integer pkFieldValue, Table updateTableDef, Table updateDetailTableDef) throws Exception {
    onAfterUpdate(modifiedUserId, pkFieldValue, updateTableDef);
    if (updateDetailTableDef != null)
      onAfterUpdate(modifiedUserId, pkFieldValue, updateDetailTableDef); 
  }
  
  public void onAfterEmpty() throws Exception {
    if (SharedConst.EXCLUDE_ADJUST_BANDWITH_INTERFACE.equals(this.intefaceCode))
      (new RadiusSocketCLient(getSocketDef())).refreshDictionnary(RadiusSocketCLient.RefreshType.ADJUSTBANDWITH); 
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\InterfaceDaoManagement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */