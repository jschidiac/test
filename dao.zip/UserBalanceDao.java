package me.iradius.server.dao;

import java.util.ArrayList;
import java.util.Date;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.db.Table;


public class UserBalanceDao
{
  public static String getInvoicesId(ArrayList<Integer> invoices) {
    String result = "";
    
    for (Integer userId : invoices) {
      if (!result.isEmpty())
        result = String.valueOf(result) + " , "; 
      result = String.valueOf(result) + userId;
    } 
    if (!result.isEmpty()) {
      result = "( " + result + " )";
    }
    return result;
  }
  
  public void paidInvoices(ArrayList<Integer> invoices) throws Exception {
    String sql = "Insert Into ClientActivity (InvoiceId, ClientId, OperationDate, CreditMode)  Select Id, ClientId, now(), 1 From Invoice WHERE Id  IN  " + 
      getInvoicesId(invoices);
    (new QueryEngine()).executeUpdateDelete(sql);
  }
  
  public void unPaidInvoices(ArrayList<Integer> invoices) throws Exception {
    String sql = " Delete From  ClientActivity Where CreditMode = 1 AND  InvoiceId IN " + getInvoicesId(invoices);
    (new QueryEngine()).deleteSql(sql);
  }
  
  public void receivedAmountFromClient(Integer id, Integer clientId, Float amount, Boolean amountInDollar, Float dollarRate) throws Exception {
    Table table = new Table("ClientActivity", "Id", Boolean.valueOf(true));
    table.addFieldValue("ClientId", clientId);
    table.addFieldValue("Credit", amount);
    table.addFieldValue("AmountInDollar", amountInDollar);
    table.addFieldValue("DollarRate", dollarRate);
    table.addFieldValue("OperationDate", new Date());
    
    (new QueryEngine()).updateData(table);
  }
  
  public void addInvoice(Integer invoiceId, Integer clientId) throws Exception {
    Table table = new Table("ClientActivity", "Id", Boolean.valueOf(true));
    table.addFieldValue("ClientId", clientId);
    table.addFieldValue("InvoiceId", invoiceId);
    table.addFieldValue("OperationDate", new Date());
    
    (new QueryEngine()).updateData(table);
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\UserBalanceDao.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */