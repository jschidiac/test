package me.iradius.server.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;

public class RadiusServerDao {
	
	public static String convertStreamToStr(InputStream is) throws IOException {
		if (is != null) {
			Writer writer = new StringWriter();
			char[] buffer = new char[1024];
			try {
				Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
				int n;
				while ((n = reader.read(buffer)) != -1) {
					writer.write(buffer, 0, n);
				}
			} finally {
				is.close();
			}
			return writer.toString();
		}
		return "";
	}
	
	public void restartRadiusServer() throws Exception {
		ProcessBuilder pb = new ProcessBuilder(new String[] { "bash", "-c", "/etc/init.d/RadiusServer restart" });
		pb.redirectErrorStream(true);
		try {
			Process shell = pb.start();
			InputStream shellIn = shell.getInputStream();
			shell.waitFor();
			String response = convertStreamToStr(shellIn);
			System.out.println(response);
			shellIn.close();
		} catch (IOException e) {
			throw new Exception("Error occured while executing Linux command. Error Description: " + e.getMessage());
		} catch (InterruptedException e) {
			throw new Exception("Error occured while executing Linux command. Error Description: " + e.getMessage());
		}
	}
	
	public void stopRadiusServer() throws Exception {
		ProcessBuilder pb = new ProcessBuilder(new String[] { "bash", "-c", "/etc/init.d/RadiusServer stop" });
		pb.redirectErrorStream(true);
		try {
			Process shell = pb.start();
			InputStream shellIn = shell.getInputStream();
			shell.waitFor();
			String response = convertStreamToStr(shellIn);
			System.out.println(response);
			shellIn.close();
		} catch (IOException e) {
			throw new Exception("Error occured while executing Linux command. Error Description: " + e.getMessage());
		} catch (InterruptedException e) {
			throw new Exception("Error occured while executing Linux command. Error Description: " + e.getMessage());
		}
	}
}
/*
 * Location:
 * C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server
 * \dao\RadiusServerDao.class Java compiler version: 7 (51.0) JD-Core Version:
 * 1.1.3
 */