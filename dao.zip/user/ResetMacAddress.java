package me.iradius.server.dao.user;

import me.iradius.server.engine.QueryEngine;


public class ResetMacAddress
{
  public void resetMacAddress(Integer userId, Integer dealerId, String userName) throws Exception {
    String sqlUpdate = "UPDATE UserNas set MacAddress = null WHERE UserId = " + userId;
    (new QueryEngine()).updateData(sqlUpdate);
    
    (new TraceUserLog()).traceUserLog(userId, dealerId, userName, "5", "Reset Mac Address");
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\da\\user\ResetMacAddress.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */