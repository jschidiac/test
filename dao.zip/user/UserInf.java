package me.iradius.server.dao.user;

import java.util.Date;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;

public class UserInf {
	
	public Integer	userId;
	public String	userName;
	public Float	deductMoney;
	public Integer	parentAccountType;
	public Integer	accountTypeId;
	public String	accountTypeName;
	public Integer	accountTypeCategory;
	public Integer	validityPeriod;
	public Integer	validityPeriodTypeId;
	public Double	accountRate;
	public Double	accountCommision;
	public Double	dealerCommision;
	public Integer	dealerCommisionId;
	public Boolean	refundable;
	public Integer	maxUsers;
	public Boolean	dealerNoCharge;
	public Integer	dealerId;
	public Double	dealerCredit;
	public String	fullName;
	public Date		activatedAccount;
	public Date		expiryAccount;
	public Float	currentUserMonthUp;
	public Float	currentUserMonthDown;
	public Integer	CombinedMaxMonthlyUpAndDown;
	public Integer	SeperateMaxMonthlyUp;
	public Integer	SeperateMaxMonthlyDown;
	public Boolean	AutoGenerateInvoice;
	public String	MOF;
	public Integer	UserCategoryId;
	public Double	AccountPrice;
	public Double	Discount;
	public Integer	FinancialCategoryId;
	public Integer	FinancialCategoryTaxValue;
	public Boolean	displayFinancialInfoOnInvoice;
	public Boolean	ForceOverrideImmediatlyRecharge;
	public Boolean	OverrideImmediatlyRecharge;
	public Boolean	ChargeIfNotExpiry;
	public Float	dealerFupResetPrice;
	
	public static UserInf getAccountTypeByUser(Integer userId) throws Exception {
		String sqlCode = "SELECT AccountTypeId , AccountTypeCategory, ValidityPeriod, ValidityPeriodTypeId, AccountType.DealerId , \t\tAccountType.ParentId as ParentAccountType, AccountType.Rate, AccountType.AccountTypeName, AccountType.Commision, Refundable,  MaxUsers,  ActivatedAccount, ExpiryAccount ,     AccountType.CombinedMaxMonthlyUpAndDown , AccountType.SeperateMaxMonthlyUp  , AccountType.SeperateMaxMonthlyDown ,     cast( COALESCE( sum( UserNas.DownloadBytes), 0) / (1024*1024) AS DECIMAL (14,2) )  as  DownloadBytes,      cast( COALESCE( sum( UserNas.UploadBytes), 0) / (1024*1024) AS DECIMAL (14,2) )  as  UploadBytes, \t\tUser.ParentId, User.UserName,  User.FirstName, User.LastName ,UserNas.DeductMoney, \t\tUser.AutoGenerateInvoice, User.MOF, User.UserCategoryId, User.Discount,      IFNULL( User.AccountPrice , AccountType.SellingPrice) as AccountPrice ,     UserNas.ForceOverrideImmediatlyRecharge, UserNas.OverrideImmediatlyRecharge, \t\tDealer.ChargeIfNotExpiry, Dealer.Credit, Dealer.NoCharge, UserDealer.ParentId , Dealer.FupResetPrice, FinancialCategory.Id as FinancialCategoryId, FinancialCategory.TaxValue as FinancialCategoryTaxValue , FinancialCategory.DisplayFinancialInfoOnInvoice  from UserNas  LEFT OUTER JOIN User on User.Id = UserNas.UserId  LEFT OUTER JOIN AccountType on AccountType.Id = UserNas.AccountTypeId  LEFT OUTER JOIN Dealer on Dealer.UserId = AccountType.DealerId  LEFT OUTER JOIN User UserDealer on UserDealer.Id = Dealer.UserId   LEFT OUTER JOIN FinancialCategory on FinancialCategory.Id = User.FinancialCategoryId  WHERE UserNas.UserId = "
				+ userId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sqlCode);
		if (recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			UserInf userInf = new UserInf();
			userInf.userId = userId;
			userInf.dealerId = record.getIntegerValue("DealerId");
			userInf.dealerCommisionId = record.getIntegerValue("ParentId");
			userInf.accountTypeId = record.getIntegerValue("AccountTypeId");
			userInf.parentAccountType = record.getIntegerValue("ParentAccountType");
			userInf.accountTypeName = record.getStringValue("AccountTypeName");
			userInf.accountTypeCategory = record.getIntegerValue("AccountTypeCategory");
			userInf.validityPeriod = record.getIntegerValue("ValidityPeriod");
			userInf.validityPeriodTypeId = record.getIntegerValue("ValidityPeriodTypeId");
			userInf.ForceOverrideImmediatlyRecharge = record.getBooleanValue("ForceOverrideImmediatlyRecharge");
			userInf.OverrideImmediatlyRecharge = record.getBooleanValue("OverrideImmediatlyRecharge");
			userInf.dealerCredit = record.getDoubleValue("Credit");
			userInf.accountRate = record.getDoubleValue("Rate");
			userInf.accountCommision = record.getDoubleValue("Commision");
			userInf.dealerCommision = record.getDoubleValue("Commision");
			userInf.refundable = record.getBooleanValue("Refundable");
			userInf.maxUsers = record.getIntegerValue("MaxUsers");
			userInf.activatedAccount = record.getDateValue("ActivatedAccount");
			userInf.expiryAccount = record.getDateValue("ExpiryAccount");
			userInf.dealerNoCharge = record.getBooleanValue("NoCharge");
			userInf.deductMoney = record.getFloatValue("DeductMoney");
			userInf.userName = record.getStringValue("UserName");
			userInf.fullName = String.valueOf(userInf.userName) + " : [" + record.getStringValue("LastName") + ", " + record.getStringValue("FirstName") + "]";
			userInf.currentUserMonthUp = record.getFloatValue("UploadBytes");
			userInf.currentUserMonthDown = record.getFloatValue("DownloadBytes");
			userInf.CombinedMaxMonthlyUpAndDown = record.getIntegerValue("CombinedMaxMonthlyUpAndDown");
			userInf.SeperateMaxMonthlyUp = record.getIntegerValue("SeperateMaxMonthlyUp");
			userInf.SeperateMaxMonthlyDown = record.getIntegerValue("SeperateMaxMonthlyDown");
			userInf.AutoGenerateInvoice = record.getBooleanValue("AutoGenerateInvoice");
			userInf.MOF = record.getStringValue("MOF");
			userInf.UserCategoryId = record.getIntegerValue("UserCategoryId");
			userInf.AccountPrice = record.getDoubleValue("AccountPrice");
			userInf.Discount = record.getDoubleValue("Discount");
			userInf.FinancialCategoryId = record.getIntegerValue("FinancialCategoryId");
			userInf.FinancialCategoryTaxValue = record.getIntegerValue("FinancialCategoryTaxValue");
			userInf.displayFinancialInfoOnInvoice = record.getBooleanValue("DisplayFinancialInfoOnInvoice");
			userInf.dealerFupResetPrice = record.getFloatValue("FupResetPrice");
			userInf.ChargeIfNotExpiry = record.getBooleanValue("ChargeIfNotExpiry");
			return userInf;
		}
		return null;
	}
} 