package me.iradius.server.dao.user;

import java.util.Calendar;
import java.util.Date;
import me.iradius.server.ctxt.AppContext;
import me.iradius.server.dao.DealerManagement;
import me.iradius.server.dao.UserManagement;
import me.iradius.server.dao.account.AccountTypeUtils;
import me.iradius.server.dao.account.ChangeAccountTypeDao;
import me.iradius.server.dao.account.RenewUserDate;
import me.iradius.server.dao.invoice.InvoiceDao;
import me.iradius.server.engine.QueryEngine;
import me.iradius.server.socket.RadiusSocketCLient;
import me.iradius.server.socket.SocketDef;
import me.iradius.shared.db.Table;
import me.iradius.shared.invoice.InvoiceDef;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.Session;

public class RenewUser {
	
	protected SocketDef getSocketDef() {
		return (SocketDef) AppContext.getBean("socket");
	}
	
	public Date renewUser(Integer modifiedUserId, Integer userId, String prefixDescription, Boolean addMode, Integer days) throws Exception {
		UserInf userInf = UserInf.getAccountTypeByUser(userId);
		if (userInf != null) {
			if (userInf.expiryAccount != null && userInf.ChargeIfNotExpiry != null && userInf.ChargeIfNotExpiry.booleanValue() && userInf.expiryAccount != null) {
				Date maxDateCanRenew = new Date();
				Calendar cal = Calendar.getInstance();
				cal.setTime(maxDateCanRenew);
				cal.add(5, 1);
				maxDateCanRenew = new Date(cal.getTime().getTime());
				if (userInf.expiryAccount.after(maxDateCanRenew)) {
					throw new Exception("An error has occured, Please check your administrator.");
				}
			}
			Boolean accountIsExpired = Boolean.valueOf(true);
			if (userInf.expiryAccount != null) {
				accountIsExpired = Boolean.valueOf(userInf.expiryAccount.before(new Date()));
			}
			Double accountRate = userInf.accountRate;
			accountRate = Double.valueOf((accountRate != null) ? accountRate.doubleValue() : 0.0D);
			DealerManagement dealerManagement = new DealerManagement(null);
			if (!userInf.dealerNoCharge.booleanValue()) {
				accountRate = Double.valueOf((userInf.deductMoney != null) ? (accountRate.doubleValue() + userInf.deductMoney.floatValue()) : accountRate.doubleValue());
				dealerManagement.checkDealerCredit(userInf.dealerId, (accountRate != null) ? Float.valueOf(accountRate.floatValue()) : null);
			}
			RenewUserDate renewUserDate = (new ChangeAccountTypeDao()).updateUserExpiryAccountDate(userId, userInf.accountTypeId, days, userInf.ForceOverrideImmediatlyRecharge, userInf.OverrideImmediatlyRecharge);
			Date newExpiryDate = (renewUserDate != null) ? renewUserDate.getExpiryDate() : null;
			if (newExpiryDate != null) {
				Date sqlnewExpiryDate = (newExpiryDate != null) ? new Date(newExpiryDate.getTime()) : null;
				if (!userInf.dealerNoCharge.booleanValue()) {
					String addInfo = "";
					if (userInf.deductMoney != null && userInf.deductMoney.floatValue() > 0.0F) {
						addInfo = "/  [Deduct Money : " + userInf.deductMoney + "]";
					}
					dealerManagement.removeCreditBasedOnrechargeAccount(modifiedUserId, userInf.dealerId, userId, (accountRate != null) ? Float.valueOf(accountRate.floatValue()) : null, sqlnewExpiryDate,
							addMode.booleanValue() ? "NEW USER" : "RENEW", String.valueOf(prefixDescription) + userInf.fullName + addInfo);
					(new DealerManagement(null)).onUpdateDealerCommission(modifiedUserId, userId, userInf.accountTypeId, newExpiryDate, addMode.booleanValue() ? "NEW USER" : "RENEW", String.valueOf(prefixDescription) + userInf.fullName,
							Boolean.valueOf(false));
				}
				prefixDescription = String.valueOf(prefixDescription) + " Modifield By  " + UserManagement.getModifiedUserName(modifiedUserId) + "  [Account type : " + userInf.accountTypeName + "]  ";
				String strNewExpiryDate = (newExpiryDate != null) ? ("[Expiry Date = " + newExpiryDate.toLocaleString() + "]") : "";
				(new TraceUserLog()).traceUserLog(userId, userInf.dealerId, userInf.userName, "2", String.valueOf(prefixDescription) + strNewExpiryDate);
				if (userInf.AutoGenerateInvoice.booleanValue()) {
					Double accountPrice = (userInf.AccountPrice != null) ? userInf.AccountPrice : accountRate;
					accountPrice = Double.valueOf((userInf.deductMoney != null) ? (accountRate.doubleValue() + userInf.deductMoney.floatValue()) : accountPrice.doubleValue());
					InvoiceDef invoiceDef = (new InvoiceDao()).generateInvoice(modifiedUserId, userInf.dealerId, userId, userInf.UserCategoryId, userInf.FinancialCategoryId, userInf.FinancialCategoryTaxValue, userInf.displayFinancialInfoOnInvoice,
							userInf.MOF, accountPrice, userInf.Discount, new Date(), newExpiryDate);
					if (days != null && days.intValue() > 0) {
						(new InvoiceDao()).addInvoiceItem(invoiceDef.getId(), renewUserDate);
						String description = "Modifield By  " + UserManagement.getModifiedUserName(modifiedUserId) + "  Override Expiry Account : Days " + days;
						(new DealerManagement(null)).traceDealerBillingLog(modifiedUserId, userInf.dealerId, userId, null, "2", Double.valueOf(0.0D), null, null, description);
					}
				}
				(new RadiusSocketCLient(getSocketDef())).notifyRadiusByResetQuota(userInf.userId, userInf.userName);
			}
			return newExpiryDate;
		}
		return null;
	}
	
	public void resetOverrideExpiryAccountBasedOnUserPaid(Session session, Integer invoiceId, Integer userId) throws Exception {
		String sql = "SELECT  ExpiryAccount , OverrideExpiryAccount, ForceExpiryAfterDays  FROM UserNas  Where UserId = " + userId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			Date ExpiryAccount = record.getDateValue("ExpiryAccount");
			Date OverrideExpiryAccount = record.getDateValue("OverrideExpiryAccount");
			if (OverrideExpiryAccount != null) {
				Date now = new Date();
				if (now.before(ExpiryAccount)) {
					String sqlUpdate = "Update UserNas  SET OverrideExpiryAccount = null,  ForceExpiryAfterDays = null  where  UserId = " + userId;
					(new QueryEngine()).delete(sqlUpdate);
				} else {
					extendUserExpiryAccountBasedOnUnpaidAccount(userId);
				}
			}
		}
	}
	
	private void extendUserExpiryAccountBasedOnUnpaidAccount(Integer userId) throws Exception {
		String sql = "SELECT ImmediateRecharge, PreventBeforeRecharge, AddedHours,   ExtraDaysToAddWhenRefill, ExtraDaysToDeductWhenRefill, ValidityPeriod, ValidityPeriodTypeId,  ExpiryAccount , OverrideExpiryAccount, ForceExpiryAfterDays, AccountTypeCategory  FROM  UserNas  LEFT OUTER JOIN AccountType ON AccountType.Id = UserNas.AccountTypeId  WHERE  UserNas.UserId = "
				+ userId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet != null && recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			Integer validityPeriod = record.getIntegerValue("ValidityPeriod");
			Integer validityPeriodTypeId = record.getIntegerValue("ValidityPeriodTypeId");
			Integer ForceExpiryAfterDays = record.getIntegerValue("ForceExpiryAfterDays");
			if (ForceExpiryAfterDays != null) {
				Date refillRenewDate = new Date();
				Date expiryDate = AccountTypeUtils.getExpiryAccount(refillRenewDate, validityPeriod, validityPeriodTypeId);
				if (expiryDate != null) {
					Calendar cal = Calendar.getInstance();
					cal.setTime(expiryDate);
					cal.add(5, -ForceExpiryAfterDays.intValue());
					expiryDate = cal.getTime();
					Table tableDef = new Table("UserNas", "UserId", Boolean.valueOf(false));
					tableDef.setPkFieldValue(userId);
					tableDef.addFieldValue("ExpiryAccount", expiryDate);
					tableDef.addFieldValue("OverrideExpiryAccount", null);
					tableDef.addFieldValue("ForceExpiryAfterDays", null);
					(new QueryEngine()).updateData(tableDef);
				}
			}
		}
	}
	
	public void extendOverrideExpiryAccount(Integer sessionIid, Integer userId, Integer days) throws Exception {
		if (days != null && days.intValue() > 0) {
			UserInf userInf = UserInf.getAccountTypeByUser(userId);
			if (userInf != null) {
				String sql = "SELECT ExpiryAccount, OverrideExpiryAccount, ForceExpiryAfterDays  FROM UserNas  WHERE UserNas.UserId = " + userId;
				RecordSet recordSet = (new QueryEngine()).executeSql(sql);
				if (recordSet != null && recordSet.size() > 0) {
					Record record = (Record) recordSet.get(0);
					Date dbOverrideExpiryAccount = record.getDateValue("OverrideExpiryAccount");
					if (dbOverrideExpiryAccount != null) {
						Calendar cal = Calendar.getInstance();
						cal.setTime(dbOverrideExpiryAccount);
						cal.add(5, days.intValue());
						Date newOverrideExpiryAccount = cal.getTime();
						Integer dbForceExpiryAfterDays = record.getIntegerValue("ForceExpiryAfterDays");
						dbForceExpiryAfterDays = Integer.valueOf((dbForceExpiryAfterDays != null) ? dbForceExpiryAfterDays.intValue() : 0);
						dbForceExpiryAfterDays = Integer.valueOf(dbForceExpiryAfterDays.intValue() + days.intValue());
						Table tableDef = new Table("UserNas", "UserId", Boolean.valueOf(false));
						tableDef.setPkFieldValue(userId);
						tableDef.addFieldValue("OverrideExpiryAccount", newOverrideExpiryAccount);
						tableDef.addFieldValue("ForceExpiryAfterDays", dbForceExpiryAfterDays);
						(new QueryEngine()).updateData(tableDef);
						RenewUserDate renewUserDate = new RenewUserDate();
						renewUserDate.setForceExpiryAfterDays(days);
						renewUserDate.setOverrideExpiryAccount(newOverrideExpiryAccount);
						(new InvoiceDao()).addUnPaidRenewInvoiceItem(userId, renewUserDate);
						String description = "Modifield By  " + UserManagement.getModifiedUserName(sessionIid) + "  Override Expiry Account : Days [" + days + "] Total Days : [" + dbForceExpiryAfterDays + "]";
						(new DealerManagement(null)).traceDealerBillingLog(sessionIid, userInf.dealerId, userId, null, "2", Double.valueOf(0.0D), null, null, description);
					}
				}
			}
		}
	}
}
/*
 * Location:
 * C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server
 * \da\\user\RenewUser.class Java compiler version: 7 (51.0) JD-Core Version:
 * 1.1.3
 */