package me.iradius.server.dao.user;

import java.util.Date;
import me.iradius.server.dao.DealerManagement;
import me.iradius.server.dao.account.AccountTypeUtils;
import me.iradius.server.dao.dealer.DealerCommistionMgmt;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.db.Table;




public class DeleteUserMgmt
{
  private void addRecordToUserDeleted(Integer userId, String userName, String password) throws Exception {
    Table tableDef = new Table("UserDeleted", "Id", Boolean.valueOf(true));
    tableDef.setPkFieldValue(userId);
    tableDef.addFieldValue("UserName", userName);
    tableDef.addFieldValue("Password", password);
    (new QueryEngine()).updateData(tableDef);
  }
  
  public void deleteUser(Integer modifiedUserId, String modifiedUserName, Integer userId, String userName, String password) throws Exception {
    UserInf userInf = UserInf.getAccountTypeByUser(userId);
    if (userInf != null) {
      
      (new TraceUserLog()).traceUserLog(userId, userInf.dealerId, userInf.userName, "3", "Delete User By " + modifiedUserName);
      
      addRecordToUserDeleted(userId, userName, password);
      
      (new QueryEngine()).deleteRecord("User", "Id", userId.toString());
      
      Boolean canRefund = Boolean.valueOf((userInf.refundable != null && userInf.refundable.booleanValue()));
      canRefund = Boolean.valueOf((canRefund.booleanValue() && !userInf.dealerNoCharge.booleanValue() && userInf.dealerCredit != null));
      canRefund = Boolean.valueOf((canRefund.booleanValue() && userInf.expiryAccount != null && userInf.expiryAccount.after(new Date())));


      
      if (canRefund.booleanValue()) {
        
        Double refundCredit = AccountTypeUtils.getRefundableCredit(userInf);
        
        if (refundCredit != null && refundCredit.doubleValue() > 0.0D) {
          String routerName = userInf.fullName;
          (new DealerManagement(null)).removeCreditBasedOnrechargeAccount(modifiedUserId, userInf.dealerId, userId, Float.valueOf(-refundCredit.floatValue()), null, 
              "REFUND", 
              "Refund Credits From Delete User : " + routerName);


          
          (new DealerCommistionMgmt()).commissionMgmt(modifiedUserId, userInf.accountTypeId, userInf.accountRate, userInf.accountCommision, refundCredit, "REFUND", "Refund Credits From Delete User : " + routerName);
        } 
      } 
    } 
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\da\\user\DeleteUserMgmt.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */