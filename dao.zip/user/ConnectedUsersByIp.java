package me.iradius.server.dao.user;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.db.DbUtils;
import me.iradius.shared.record.RecordSet;


public class ConnectedUsersByIp
{
  public RecordSet getConnectedUserB1Ip(Date fromDate, Date toDate, String ipAddress) throws Exception {
    if (fromDate != null && toDate != null && ipAddress != null) {
      String format = "MM/dd/yyyy HH:mm:ss";
      String dbFormat = "%m/%d/%Y %H:%i:%s";
      DateFormat df = new SimpleDateFormat(format);
      String strFromDate = df.format(fromDate);
      String strToDate = df.format(toDate);
      strFromDate = "STR_TO_DATE( '" + strFromDate + "', '" + dbFormat + "' )";
      strToDate = "STR_TO_DATE( '" + strToDate + "', '" + dbFormat + "' )";

      
      String sql = "SELECT DISTINCT UserName , FirstName , LastName,  Mobile  FROM UserNasSession  LEFT OUTER JOIN User on User.Id = UserNasSession.UserId  WHERE  ( ( StartSession <= " + 





        
        strToDate + "  AND  EndSession >= " + strFromDate + "  ) " + 

        
        " OR " + 
        "( StartSession >= " + strFromDate + " AND StartSession <= " + strToDate + "  AND  EndSession IS NULL ) " + 

        
        " ) " + 
        " AND UserNasSession.IpAddress = " + DbUtils.dblQuotedField(ipAddress);




      
      return (new QueryEngine()).executeSql(sql);
    } 
    return null;
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\da\\user\ConnectedUsersByIp.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */