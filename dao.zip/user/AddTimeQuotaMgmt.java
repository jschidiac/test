package me.iradius.server.dao.user;

import java.util.Calendar;
import java.util.Date;
import me.iradius.server.ctxt.AppContext;
import me.iradius.server.dao.DealerManagement;
import me.iradius.server.dao.MikrotikApiDao;
import me.iradius.server.dao.account.AccountTypeUtils;
import me.iradius.server.dao.invoice.InvoiceDao;
import me.iradius.server.engine.QueryEngine;
import me.iradius.server.socket.RadiusSocketCLient;
import me.iradius.server.socket.SocketDef;
import me.iradius.shared.db.Table;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;

public class AddTimeQuotaMgmt {
	
	private SocketDef getSocketDef() {
		return (SocketDef) AppContext.getBean("socket");
	}
	
	public void addDayHourForExpiryAccount(Integer modifiedUserId, Integer userId, Integer days, Integer hours, Boolean manageDealerAccount, Boolean adjustTime, Boolean addMode) throws Exception {
		String sql = "SELECT User.UserName,  User.ParentId,  ExpiryAccount, ValidityPeriod, ValidityPeriodTypeId, Rate  FROM  UserNas  LEFT OUTER JOIN User on User.Id = UserNas.userId    LEFT OUTER JOIN AccountType on AccountType.Id = UserNas.AccountTypeId    WHERE UserId = "
				+ userId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet != null && recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			Date expiryAccount = record.getDateValue("ExpiryAccount");
			if (addMode.booleanValue() && (expiryAccount == null || expiryAccount.before(new Date()))) {
				expiryAccount = new Date();
			}
			if (expiryAccount != null) {
				String userName = record.getStringValue("UserName");
				Integer baseDays = days;
				Integer baseHours = hours;
				Calendar cal = Calendar.getInstance();
				cal.setTime(expiryAccount);
				Integer AddedHours = null;
				if (days != null && days.intValue() > 0) {
					AddedHours = Integer.valueOf(24 * days.intValue());
					if (!addMode.booleanValue())
						days = Integer.valueOf(-days.intValue());
					cal.add(7, days.intValue());
				}
				if (hours != null && hours.intValue() > 0) {
					AddedHours = hours;
					if (!addMode.booleanValue())
						hours = Integer.valueOf(-hours.intValue());
					cal.add(10, hours.intValue());
				}
				Date date = cal.getTime();
				Date newExpiryDate = new Date(date.getTime());
				String description = addMode.booleanValue() ? "Add " : "Remove ";
				description = String.valueOf(description) + " [ ";
				if (baseDays != null && baseDays.intValue() > 0) {
					description = String.valueOf(description) + baseDays + " Day(s) ";
				}
				if (baseHours != null && baseHours.intValue() > 0) {
					description = String.valueOf(description) + baseHours + " Hour(s) ";
				}
				description = String.valueOf(description) + " ] ";
				description = String.valueOf(description) + " For ExpiryAccount For User : " + userName;
				Integer dealerId = record.getIntegerValue("ParentId");
				if (manageDealerAccount.booleanValue() && AddedHours != null) {
					Date now = new Date();
					Integer validityPeriod = record.getIntegerValue("ValidityPeriod");
					Integer validityPeriodTypeId = record.getIntegerValue("ValidityPeriodTypeId");
					Float rate = record.getFloatValue("Rate");
					Date expiryDate = AccountTypeUtils.getExpiryAccount(now, validityPeriod, validityPeriodTypeId);
					long diff = expiryDate.getTime() - now.getTime();
					Long diffHours = Long.valueOf(diff / 1000L / 60L / 60L);
					Float dollars = Float.valueOf(AddedHours.intValue() * rate.floatValue() / (float) diffHours.longValue());
					if (!addMode.booleanValue()) {
						dollars = Float.valueOf(-dollars.floatValue());
					}
					(new DealerManagement(null)).removeDealerCredit(modifiedUserId, dealerId, userId, dollars, new Date(newExpiryDate.getTime()), "ADD EXTRA TIME", description);
				} else {
					(new TraceUserLog()).traceUserLog(userId, dealerId, userName, "7", description);
				}
				Table tableDef = new Table("UserNas", "UserId", Boolean.valueOf(false));
				tableDef.setPkFieldValue(userId);
				tableDef.addFieldValue("ExpiryAccount", newExpiryDate);
				if (addMode.booleanValue() && adjustTime.booleanValue()) {
					tableDef.addFieldValue("AddedHours", AddedHours);
				}
				(new QueryEngine()).updateData(tableDef);
				(new RadiusSocketCLient(getSocketDef())).refreshDictionnary("5:" + userName);
				if (expiryAccount.before(new Date())) {
					(new MikrotikApiDao()).disconnectUser(userId);
				}
			}
		}
	}
	
	public void addExtraUserGB(Integer modifiedUserId, Integer userId, Integer download, Integer upload) throws Exception {
		String sql = " SELECT Dealer.UserId, Dealer.ExtraGB, Dealer.ExtraOneGPPrice, User.UserName, UserNas.ExtraDownloadGB, UserNas.ExtraUploadGB , User.AutoGenerateInvoice, User.UserCategoryId, User.FinancialCategoryId , FinancialCategory.TaxValue as FinancialCategoryTaxValue , FinancialCategory.DisplayFinancialInfoOnInvoice ,User.MOF  From Dealer  left outer join User on User.ParentId = Dealer.UserId  left outer join UserNas on UserNas.UserId = User.Id  LEFT OUTER JOIN FinancialCategory on FinancialCategory.Id = User.FinancialCategoryId  where User.Id = "
				+ userId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet != null && recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			Integer totalGB = Integer.valueOf(0);
			download = Integer.valueOf((download != null) ? download.intValue() : 0);
			upload = Integer.valueOf((upload != null) ? upload.intValue() : 0);
			totalGB = Integer.valueOf(totalGB.intValue() + download.intValue());
			totalGB = Integer.valueOf(totalGB.intValue() + upload.intValue());
			if (totalGB.intValue() > 0) {
				Float extraGBPrice = record.getFloatValue( "ExtraOneGPPrice");
				extraGBPrice = extraGBPrice != null ? extraGBPrice : 0L ;
				Integer dealerId = record.getIntegerValue("UserId");
				Float totalGBPrice = Float.valueOf(totalGB.intValue() * extraGBPrice);
				String userName = record.getStringValue("UserName");
				String description = "Add Extra " + totalGB + " GB For User : " + userName;
				(new DealerManagement(null)).removeDealerCredit(modifiedUserId, dealerId, userId, Float.valueOf(totalGBPrice.floatValue()), null, "ADD EXTRA GB", description);
				if (record.getBooleanValue("AutoGenerateInvoice").booleanValue() && totalGB != null && extraGBPrice != null) {
					Integer UserCategoryId = record.getIntegerValue("UserCategoryId");
					Integer FinancialCategoryId = record.getIntegerValue("FinancialCategoryId");
					Integer FinancialCategoryTaxValue = record.getIntegerValue("FinancialCategoryTaxValue");
					Boolean DisplayFinancialInfoOnInvoice = record.getBooleanValue("DisplayFinancialInfoOnInvoice");
					String MOF = record.getStringValue("MOF");
					(new InvoiceDao()).generateInvoiceForExtraGB(modifiedUserId, dealerId, userId, UserCategoryId, FinancialCategoryId, FinancialCategoryTaxValue, DisplayFinancialInfoOnInvoice, MOF, totalGB, extraGBPrice, new Date());
				}
				Integer oldExtraDownloadGB = record.getIntegerValue("ExtraDownloadGB");
				if (oldExtraDownloadGB != null) {
					download = Integer.valueOf(download.intValue() + oldExtraDownloadGB.intValue());
				}
				Integer oldExtraUploadGB = record.getIntegerValue("ExtraUploadGB");
				if (oldExtraUploadGB != null) {
					upload = Integer.valueOf(upload.intValue() + oldExtraUploadGB.intValue());
				}
				Table tableDef = new Table("UserNas", "UserId", Boolean.valueOf(false));
				tableDef.setPkFieldValue(userId);
				tableDef.addFieldValue("ExtraDownloadGB", download);
				tableDef.addFieldValue("ExtraUploadGB", upload);
				(new QueryEngine()).updateData(tableDef);
				(new DealerManagement(null)).updateDealerExtraGBCommission(modifiedUserId, userId, dealerId, totalGB);
				(new RadiusSocketCLient(getSocketDef())).refreshDictionnary("5:" + userName);
			}
		}
	}
}
/*
 * Location:
 * C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server
 * \da\\user\AddTimeQuotaMgmt.class Java compiler version: 7 (51.0) JD-Core
 * Version: 1.1.3
 */