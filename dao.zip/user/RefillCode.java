package me.iradius.server.dao.user;

import java.util.Calendar;
import java.util.Date;
import me.iradius.server.ctxt.SessionUtil;
import me.iradius.server.dao.DealerManagement;
import me.iradius.server.dao.account.AccountTypeUtils;
import me.iradius.server.dao.account.ChangeAccountTypeDao;
import me.iradius.server.dao.account.RenewUserDate;
import me.iradius.server.divers.ServerUtils;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.db.DbUtils;
import me.iradius.shared.db.Table;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.Session;




public class RefillCode
{
  private void updateCodeTable(Integer userId, String newCode) throws Exception {
    String sql = " UPDATE Codes set UserId = " + userId + ", " + 
      "Activated = 1 , ActivatedDate = now() WHERE RefGuid = " + DbUtils.dblQuotedField(newCode);
    (new QueryEngine()).updateData(sql);
  }



  
  private Integer traceRefillCodeLog(Integer userId, String newCode, String comment) throws Exception {
    String sql = "SELECT User.ParentId, User.UserName  FROM User User  WHERE Id = " + 
      
      userId;
    RecordSet recordSet = (new QueryEngine()).executeSql(sql);
    if (recordSet != null && recordSet.size() > 0) {
      Record record = (Record)recordSet.get(0);
      Integer dealerId = (Integer)record.getValue("ParentId");
      String UserName = record.getStringValue("UserName");
      
      Session ispSession = SessionUtil.getSession();
      String fullName = (ispSession != null) ? ispSession.getFullName() : (" userId " + userId);
      String descrption = "Refilled By " + fullName + " [New Code = " + newCode + "] " + comment;

      
      (new TraceUserLog()).traceUserLog(userId, dealerId, UserName, "1", descrption);
      return dealerId;
    } 


    
    return null;
  }
  
  private void checkAndUpadteDealerMoneyBasedOnDeductValues(Integer modifiedUserId, Integer userId, Integer dealerId, Double dealerCredit, Double deductMoney, String userfullName, String addInfo) throws Exception {
    if (dealerCredit.doubleValue() < deductMoney.doubleValue()) {
      throw new Exception("Not Ennough Credit For This Operation, \n\n Please Contact your Provider.");
    }
    DealerManagement dealerManagement = new DealerManagement(null);
    dealerManagement.removeCreditBasedOnrechargeAccount(modifiedUserId, dealerId, userId, Float.valueOf((deductMoney != null) ? deductMoney.floatValue() : 0.0F), null, "DEDUCT MONEY", String.valueOf(addInfo) + " / Deduct Money From : " + userfullName);
  }



  
  private void updateUserExpiryAccountBasedOnnewAccountType(Date olfActivatedAccount, Date oldExpiryAccount, Integer userId, Integer oldAccountTypeId, String oldAccName, Double oldRate, Integer oldValidityPeriod, Integer oldValidityPeriodTypeId, Integer newAccountTypeId, String newAccName, Double newRate, Integer newValidityPeriod, Integer newValidityPeriodTypeId) throws Exception {
    Double oldAccountDayPrice = AccountTypeUtils.getAccountPricePerDay(oldRate, oldValidityPeriod, oldValidityPeriodTypeId);
    Double newAccountDayPrice = AccountTypeUtils.getAccountPricePerDay(newRate, newValidityPeriod, newValidityPeriodTypeId);
    if (newAccountDayPrice != null && newAccountDayPrice.doubleValue() > 0.0D) {
      
      Date newExpiryDate = null;
      Date now = new Date((new Date()).getTime());
      Boolean accountIsExpired = Boolean.valueOf(oldExpiryAccount.before(now));
      
      if (!accountIsExpired.booleanValue()) {


        
        int remainingAccountDays = ServerUtils.daysBetween((new Date()).getTime(), oldExpiryAccount.getTime());


        
        Double relatedAccountCredit = Double.valueOf(oldAccountDayPrice.doubleValue() * remainingAccountDays);
        Integer newAccountDay = Integer.valueOf((int)(relatedAccountCredit.doubleValue() / newAccountDayPrice.doubleValue()));






        
        Calendar cal = Calendar.getInstance();
        
        cal.setTime(new Date());
        cal.add(5, newAccountDay.intValue());
        newExpiryDate = new Date(cal.getTime().getTime());
        
        System.out.println("updateUserExpiryAccountBasedOnnewAccountType ==> oldExpiryAccount :: " + oldExpiryAccount.toString() + "--- newAccountDay :: " + newAccountDay + "   NOW ::" + (new Date()).toString());
      } else {
        newExpiryDate = oldExpiryAccount;
      } 

      
      Table tableDef = new Table("UserNas", "UserId", Boolean.valueOf(false));
      tableDef.setPkFieldValue(userId);
      tableDef.addFieldValue("AccountTypeId", newAccountTypeId);
      tableDef.addFieldValue("ExpiryAccount", newExpiryDate);
      
      (new QueryEngine()).updateData(tableDef);
    } 
  }

  
  public boolean refillCode(Integer modifiedUserId, Integer userId, String newCode) throws Exception {
    Integer ForwardAccountTypeId = null;
    Integer ConditionAccountTypeId = null;
    Double deductMoney = null;
    Double dealerCredit = null;
    Integer dealerId = null;
    String userfullName = null;

    
    String sqlUser = "SELECT DeductMoney,  ForwardAccountTypeId, ConditionAccountTypeId, Dealer.Credit, Dealer.UserId, User.FirstName, User.LastName From UserNas  LEFT OUTER JOIN User ON UserNas.UserId = User.Id  LEFT OUTER JOIN Dealer Dealer ON User.ParentId = Dealer.UserId where UserNas.UserId = " + 


      
      userId;
    RecordSet RecordSet = (new QueryEngine()).executeSql(sqlUser);
    if (RecordSet.size() > 0) {
      Record record = (Record)RecordSet.get(0);
      deductMoney = record.getDoubleValue("DeductMoney");
      dealerCredit = record.getDoubleValue("Credit");
      dealerId = record.getIntegerValue("UserId");
      userfullName = String.valueOf(record.getStringValue("LastName")) + ", " + record.getStringValue("FirstName");
      
      ForwardAccountTypeId = record.getIntegerValue("ForwardAccountTypeId");
      ConditionAccountTypeId = record.getIntegerValue("ConditionAccountTypeId");
    } 

    
    Integer newAccountTypeId = null;
    String codeId = null;
    String sqlCode = "SELECT AccountTypeId, RefId , AccountTypeName,  Rate, ValidityPeriod, ValidityPeriodTypeId from Codes  LEFT OUTER JOIN AccountType ON AccountType.Id = Codes.AccountTypeId WHERE RefGuid = " + 

      
      DbUtils.dblQuotedField(newCode) + " AND Activated IS NULL AND ActivatedDate IS NULL ";
    RecordSet accrecordSet = (new QueryEngine()).executeSql(sqlCode);
    
    String newAccName = null;
    Double newRate = null;
    Integer newValidityPeriod = null;
    Integer newValidityPeriodTypeId = null;
    
    String oldAccName = null;

    
    if (accrecordSet.size() > 0) {
      Record record = (Record)accrecordSet.get(0);
      codeId = record.getStringValue("RefId");
      newAccountTypeId = record.getIntegerValue("AccountTypeId");
      
      newAccName = record.getStringValue("AccountTypeName");
      newRate = record.getDoubleValue("Rate");
      newValidityPeriod = record.getIntegerValue("ValidityPeriod");
      newValidityPeriodTypeId = record.getIntegerValue("ValidityPeriodTypeId");
    } 

    
    if (newAccountTypeId == null) {
      throw new Exception("Invalid Code");
    }
    if (ConditionAccountTypeId != null && ForwardAccountTypeId != null && ConditionAccountTypeId.equals(newAccountTypeId)) {
      
      String sqlForward = "SELECT    AccountTypeName,  Rate, ValidityPeriod, ValidityPeriodTypeId  From AccountType Where AccountType.Id =  " + 
        ForwardAccountTypeId;
      RecordSet forwardRecordSet = (new QueryEngine()).executeSql(sqlForward);
      if (forwardRecordSet.size() > 0) {
        Record record = (Record)forwardRecordSet.get(0);
        codeId = record.getStringValue("RefId");
        newAccountTypeId = ForwardAccountTypeId;
        
        newAccName = record.getStringValue("AccountTypeName");
        newRate = record.getDoubleValue("Rate");
        newValidityPeriod = record.getIntegerValue("ValidityPeriod");
        newValidityPeriodTypeId = record.getIntegerValue("ValidityPeriodTypeId");
      } 
    } 
    
    Boolean ForceOverrideImmediatlyRecharge = Boolean.valueOf(false);
    Boolean OverrideImmediatlyRecharge = Boolean.valueOf(false);
    
    String sqlAcc = "SELECT AccountTypeId ,ActivatedAccount, ExpiryAccount, AccountTypeName, PreventBeforeRecharge ,  Rate, ValidityPeriod, ValidityPeriodTypeId ,  ForceOverrideImmediatlyRecharge, UserNas.OverrideImmediatlyRecharge from UserNas  LEFT OUTER JOIN AccountType ON AccountType.Id = UserNas.AccountTypeId where UserId = " + 


      
      userId;
    RecordSet oldrecordSet = (new QueryEngine()).executeSql(sqlAcc);
    if (oldrecordSet.size() > 0) {
      Record record = (Record)oldrecordSet.get(0);
      Integer oldAccountTypeId = record.getIntegerValue("AccountTypeId");
      oldAccName = record.getStringValue("AccountTypeName");
      Date expiryAccount = record.getDateValue("ExpiryAccount");
      
      if (oldAccountTypeId != null && !oldAccountTypeId.equals(newAccountTypeId)) {
        Boolean preventBeforeRecharge = record.getBooleanValue("PreventBeforeRecharge");
        AccountTypeUtils.checkIfAccountIsExpired(null, preventBeforeRecharge, expiryAccount);
      } 

      
      if (!newAccountTypeId.equals(oldAccountTypeId)) {
        Date oldExpiryAccount = record.getDateValue("ExpiryAccount");
        Date olfActivatedAccount = record.getDateValue("ActivatedAccount");



        
        Double oldRate = record.getDoubleValue("Rate");
        Integer oldValidityPeriod = record.getIntegerValue("ValidityPeriod");
        Integer oldValidityPeriodTypeId = record.getIntegerValue("ValidityPeriodTypeId");
        
        ForceOverrideImmediatlyRecharge = record.getBooleanValue("ForceOverrideImmediatlyRecharge");
        OverrideImmediatlyRecharge = record.getBooleanValue("OverrideImmediatlyRecharge");
        updateUserExpiryAccountBasedOnnewAccountType(olfActivatedAccount, oldExpiryAccount, userId, oldAccountTypeId, oldAccName, oldRate, oldValidityPeriod, oldValidityPeriodTypeId, newAccountTypeId, newAccName, newRate, newValidityPeriod, 
            newValidityPeriodTypeId);
      } 
    } 


    
    RenewUserDate renewUserDate = (new ChangeAccountTypeDao()).updateUserExpiryAccountDate(userId, newAccountTypeId, null, ForceOverrideImmediatlyRecharge, OverrideImmediatlyRecharge);
    
    Date newExpiryDate = (renewUserDate != null) ? renewUserDate.getExpiryDate() : null;
    if (newExpiryDate != null) {


      
      updateCodeTable(userId, newCode);

      
      String comment = "  [Old Acccount = " + oldAccName + "]  [New Account = " + newAccName + "] [Expiry Date = " + newExpiryDate.toLocaleString() + "] ";

      
      traceRefillCodeLog(userId, newCode, comment);
      
      String sql = "SELECT AccountType.Commision  from AccountType  where Id = " + 
        
        newAccountTypeId;
      RecordSet recordSet = (new QueryEngine()).executeSql(sql);
      if (recordSet.size() > 0) {
        Record record = (Record)recordSet.get(0);
        Float dealerCommision = record.getFloatValue("Commision");
        if (dealerCommision != null && dealerCommision.floatValue() > 0.0F) {
          (new DealerManagement(null)).onUpdateDealerCommission(modifiedUserId, userId, newAccountTypeId, newExpiryDate, "REFILL", "Refill Code : [ " + newCode + " ]  Id : [ " + codeId + " ]", Boolean.valueOf(true));
        }
      } 

      
      if (deductMoney != null && deductMoney.doubleValue() > 0.0D) {
        checkAndUpadteDealerMoneyBasedOnDeductValues(modifiedUserId, userId, dealerId, dealerCredit, deductMoney, userfullName, "Refill Code ");
      }

      
      return true;
    } 
    throw new Exception("A Problem Has Occured, New Expiry Date Is Empty.");
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\da\\user\RefillCode.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */