package me.iradius.server.dao.user;

import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.db.DbUtils;


public class TraceUserLog
{
  public void traceUserLog(Integer userId, Integer dealerId, String userName, String operationType, String descrption) throws Exception {
    try {
      String sqlInsert = "INSERT INTO UserLog (UserId, DealerId, UserName,  OperationTypeId, Description, Logdate ) values( " + 
        userId + " , " + 
        dealerId + " , " + 
        DbUtils.dblQuotedField(userName) + " , " + 
        operationType + "," + 
        DbUtils.dblQuotedField(descrption) + 
        ", now() )";
      (new QueryEngine()).updateData(sqlInsert);
    } catch (Exception e) {
      
      throw new Exception(e.getMessage());
    } 
  }
  
  public void traceUserLog(Integer userId, Integer dealerId, String userName, Boolean newActive) throws Exception {
    String descrption = "User Enable = " + newActive;
    traceUserLog(userId, dealerId, userName, "8", descrption);
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\da\\user\TraceUserLog.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */