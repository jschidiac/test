package me.iradius.server.dao.user;

import me.iradius.server.ctxt.AppContext;
import me.iradius.server.dao.DealerManagement;
import me.iradius.server.dealer.DealerConfiguration;
import me.iradius.server.engine.QueryEngine;
import me.iradius.server.socket.RadiusSocketCLient;
import me.iradius.server.socket.SocketDef;
import me.iradius.shared.session.Session;

public class ResetUser {
	
	protected SocketDef getSocketDef() {
		return (SocketDef) AppContext.getBean("socket");
	}
	
	public void resetAccount(Session session, Integer userId, String userName) throws Exception {
		UserInf userInf = UserInf.getAccountTypeByUser(userId);
		if (userInf.dealerFupResetPrice != null && userInf.dealerFupResetPrice.floatValue() > 0.0F) {
			DealerManagement dealerManagement = new DealerManagement(null);
			dealerManagement.checkDealerCredit(userInf.dealerId, userInf.dealerFupResetPrice);
			DealerConfiguration dealerConfiguration = (DealerConfiguration) AppContext.getBean("dealerConfiguration");
			dealerConfiguration.updateDealerCredit(session.getId(), userInf.dealerId, userId, new Double(-userInf.dealerFupResetPrice.floatValue()), null, "RESET FUP", "Reset FUP");
			(new TraceUserLog()).traceUserLog(userId, userInf.dealerId, userInf.userName, "2", "Reset FUP By " + session.getUserName());
		}
		String sqlUpdate = "UPDATE UserNasSessionDetails SET  DownloadBytes = 0 ,UploadBytes = 0 ,FreeDownloadBytes = 0  ,FreeUploadBytes = 0  ,ExcludeDownloadBytes = 0  ,ExcludeUploadBytes = 0  WHERE DATE(OperationDate) = DATE(now()) AND  UserId = "
				+ userId;
		(new QueryEngine()).updateData(sqlUpdate);
		sqlUpdate = "UPDATE UserNasSession Set DownloadBytes = 0,UploadBytes = 0, FreeDownloadBytes = 0, FreeUploadBytes = 0  Where UserId  =  " + userId + " AND EndSession is null ";
		//
		(new QueryEngine()).updateData(sqlUpdate);
		//
		sqlUpdate = "UPDATE  UserNas set  DailyDownloadBytes =  0, DailyUploadBytes = 0 WHERE UserId = " + userId;
		(new QueryEngine()).updateData(sqlUpdate);
		//
		(new RadiusSocketCLient(getSocketDef())).refreshDictionnary("9:" + userId + ":" + userName);
	}
}
/*
 * Location:
 * C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server
 * \da\\user\ResetUser.class Java compiler version: 7 (51.0) JD-Core Version:
 * 1.1.3
 */