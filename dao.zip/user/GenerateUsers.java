package me.iradius.server.dao.user;

import java.util.Date;
import me.iradius.server.dao.DealerManagement;
import me.iradius.server.divers.ServerUtils;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.db.Table;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;



public class GenerateUsers
{
  private String generateText(Integer length) {
    return ServerUtils.generateRefGuid(length);
  }
  
  private void generateUser(Integer dealerId, String prefixUser, String userName, String password, Integer accountTypeId) throws Exception {
    Table tableDef = new Table("User", "id", Boolean.valueOf(true));
    tableDef.addFieldValue("ParentId", dealerId);
    tableDef.addFieldValue("ProfileId", "4");
    tableDef.addFieldValue("UserName", userName);
    tableDef.addFieldValue("Password", password);
    tableDef.addFieldValue("FirstName", (prefixUser != null) ? (String.valueOf(prefixUser) + userName) : userName);
    tableDef.addFieldValue("CreationDate", new Date());
    
    Integer userId = (new QueryEngine()).updateData(tableDef);

    
    Table userNasTableDef = new Table("UserNas", "UserId", Boolean.valueOf(true));
    userNasTableDef.addFieldValue("UserId", userId);
    userNasTableDef.addFieldValue("AccountTypeId", accountTypeId);
    userNasTableDef.addFieldValue("Active", Boolean.valueOf(false));
    userNasTableDef.addFieldValue("CanShowTraficDetails", Boolean.valueOf(false));
    userNasTableDef.addFieldValue("AutomaticRenew", Boolean.valueOf(false));
    userNasTableDef.addFieldValue("ActivatedAccount", new Date());
    userNasTableDef.addFieldValue("TempUser", Boolean.valueOf(true));
    (new QueryEngine()).updateData(userNasTableDef);


    
    UserInf userInf = UserInf.getAccountTypeByUser(userId);
    if (userInf != null) {
      
      Double accountRate = userInf.accountRate;

      
      DealerManagement dealerManagement = new DealerManagement(null);
      if (!userInf.dealerNoCharge.booleanValue()) {
        accountRate = Double.valueOf((userInf.deductMoney != null) ? (accountRate.doubleValue() + userInf.deductMoney.floatValue()) : accountRate.doubleValue());
        
        dealerManagement.checkDealerCredit(userInf.dealerId, (accountRate != null) ? Float.valueOf(accountRate.floatValue()) : null);
      } 

      
      String prefixDescription = "Generate User ";
      if (!userInf.dealerNoCharge.booleanValue()) {
        String addInfo = "";
        if (userInf.deductMoney != null && userInf.deductMoney.floatValue() > 0.0F) {
          addInfo = "/  [Deduct Money : " + userInf.deductMoney + "]";
        }
        dealerManagement.removeCreditBasedOnrechargeAccount(dealerId, userInf.dealerId, userId, (accountRate != null) ? Float.valueOf(accountRate.floatValue()) : null, null, "NEW USER", String.valueOf(prefixDescription) + userInf.fullName + addInfo);
        
        (new DealerManagement(null)).onUpdateDealerCommission(dealerId, userId, userInf.accountTypeId, null, "NEW USER", String.valueOf(prefixDescription) + userInf.fullName, Boolean.valueOf(false));
      } 
      
      prefixDescription = String.valueOf(prefixDescription) + "  [Account type : " + userInf.accountTypeName + "]  ";
      (new TraceUserLog()).traceUserLog(userId, userInf.dealerId, userInf.userName, "2", prefixDescription);
    } 
  }


  
  private void onBeforeGenerateUsers(Integer dealerId, Integer accountTypeId, Integer userCount) throws Exception {
    String sql = "SELECT AccountType.Rate, Dealer.Credit, Dealer.NoCharge FROM AccountType     LEFT OUTER JOIN Dealer ON AccountType.DealerId = Dealer.UserId WHERE Dealer.UserId = " + 

      
      dealerId + " and AccountType.Id =   " + accountTypeId;
    RecordSet recordSet = (new QueryEngine()).executeSql(sql);
    if (recordSet.size() > 0) {
      Record record = (Record)recordSet.get(0);
      
      Boolean noCharge = record.getBooleanValue("NoCharge");
      if (noCharge == null || !noCharge.booleanValue()) {
        Float accountTypeRate = record.getFloatValue("Rate");
        Double dealerCredit = record.getDoubleValue("Credit");
        
        accountTypeRate = Float.valueOf((accountTypeRate == null) ? 0.0F : accountTypeRate.floatValue());
        dealerCredit = Double.valueOf((dealerCredit == null) ? 0.0D : dealerCredit.doubleValue());
        
        if (!noCharge.booleanValue() && (userCount.intValue() * accountTypeRate.floatValue()) > dealerCredit.doubleValue()) {
          throw new Exception("Not ennough Credit for this operation.");
        }
      } 
    } 
  }


  
  public void generateBatchCodes(Integer dealerId, String prefixUser, Integer maxUserNameChar, Integer maxPwChar, Integer userCount, Integer accountTypeId) throws Exception {
    onBeforeGenerateUsers(dealerId, accountTypeId, userCount);
    
    for (int i = 0; i < userCount.intValue(); i++) {
      String userName = generateText(maxUserNameChar);
      String password = generateText(maxPwChar);
      
      generateUser(dealerId, prefixUser, userName, password, accountTypeId);
    } 
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\da\\user\GenerateUsers.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */