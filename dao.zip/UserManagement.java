package me.iradius.server.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import me.iradius.server.ctxt.AppContext;
import me.iradius.server.ctxt.SessionUtil;
import me.iradius.server.dao.user.RenewUser;
import me.iradius.server.dao.user.TraceUserLog;
import me.iradius.server.engine.QueryEngine;
import me.iradius.server.scheduler.RenewUserAccountScheduler;
import me.iradius.server.system.IRadiusSecurity;
import me.iradius.shared.db.DbUtils;
import me.iradius.shared.db.Table;
import me.iradius.shared.record.IntegerValue;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.Session;

public class UserManagement extends AbstractDaoMgmt {
	
	protected Integer	modifiedUserId;
	
	public UserManagement(Integer modifiedUserId) {
		super(null);
		this.modifiedUserId = modifiedUserId;
	}
	
	public UserManagement(Integer modifiedUserId, Table updateTableDef) {
		super(updateTableDef);
		this.modifiedUserId = modifiedUserId;
	}
	
	public static String getModifiedUserName(Integer modifiedUserId) throws Exception {
		String modifiedUserName = null;
		String sql = "SELECT UserName From User Where Id = " + modifiedUserId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet.size() > 0) {
			modifiedUserName = ((Record) recordSet.get(0)).getStringValue("UserName");
		}
		return modifiedUserName;
	}
	
	public void executeBeforeUpdate() throws Exception {
		if (this.updateTableDef != null && !this.updateTableDef.getInsertMode().booleanValue() && "User".equalsIgnoreCase(this.updateTableDef.getTableName())) {
			Integer userId = this.updateTableDef.getPkFieldValue();
			String sql = "SELECT UserName From User Where Id = " + userId;
			RecordSet recordSet = (new QueryEngine()).executeSql(sql);
			String oldUserName = null;
			if (recordSet.size() > 0) {
				oldUserName = ((Record) recordSet.get(0)).getStringValue("UserName");
			}
			String modifiedUserName = getModifiedUserName(this.modifiedUserId);
			String newUserName = (String) this.updateTableDef.getFieldValues().get("UserName");
			if (newUserName != null && !newUserName.equals(oldUserName)) {
				Integer dealerId = null;
				try {
					Session session = SessionUtil.getSession();
					dealerId = session.getDealerId();
					if (dealerId == null)
						dealerId = this.modifiedUserId;
				} catch (Exception exception) {
				}
				String descrption = "Change UserName OldUserName = " + oldUserName + " Newer One = " + newUserName + " Modified By = " + modifiedUserName;
				(new TraceUserLog()).traceUserLog(this.modifiedUserId, dealerId, newUserName, "9", descrption);
			}
		}
	}
	
	public void executeAfterUpdate(Integer modifiedUserId, Table updateTableDef, final Integer pkFieldValue) throws Exception {
		if ("UserNas".equalsIgnoreCase(updateTableDef.getTableName())) {
			try {
				if (updateTableDef.getInsertMode().booleanValue()) {
					Date ExpiryAccount = (Date) updateTableDef.getFieldValues().get("ExpiryAccount");
					if (ExpiryAccount == null) {
						(new RenewUser()).renewUser(modifiedUserId, pkFieldValue, "Add User : ", Boolean.valueOf(true), null);
					}
				} else {
					Boolean active = (Boolean) updateTableDef.getFieldValues().get("Active");
					Boolean canDisocnnect = updateTableDef.getExtraInfos();
					if ((canDisocnnect != null && canDisocnnect.booleanValue()) || active == null || !active.booleanValue()) {
						new Thread(new Runnable() {
							
							@Override
							public void run() {
								try {
									(new MikrotikApiDao()).disconnectUser(pkFieldValue);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}).start();
					}
				}
				RenewUserAccountScheduler renewUserAccountScheduler = (RenewUserAccountScheduler) AppContext.getBean("renewUserAccountScheduler");
				renewUserAccountScheduler.startSchedule();
			} catch (Exception e) {
				String sql = "DELETE FROM User WHERE Id = " + pkFieldValue;
				(new QueryEngine()).updateData(sql);
				throw e;
			}
		}
	}
	
	public static String getUsers(ArrayList<Integer> selectedUsers) {
		String result = "";
		for (Integer userId : selectedUsers) {
			if (!result.isEmpty())
				result = String.valueOf(result) + " , ";
			result = String.valueOf(result) + userId;
		}
		if (!result.isEmpty()) {
			result = "( " + result + " )";
		}
		return result;
	}
	
	public void assignUsersToCollectors(Integer collectorId, ArrayList<Integer> selectedUsers) throws Exception {
		if (selectedUsers.size() > 0) {
			String sqlUpdate = "UPDATE User SET CollectorId =  " + collectorId + "  WHERE Id  IN  " + getUsers(selectedUsers);
			(new QueryEngine()).updateData(sqlUpdate);
		}
	}
	
	public void assignUsersTouserGroups(Integer userGroupId, ArrayList<Integer> selectedUsers) throws Exception {
		if (selectedUsers.size() > 0) {
			String sqlUpdate = "UPDATE User SET UserGroupId =  " + userGroupId + "  WHERE Id  IN  " + getUsers(selectedUsers);
			(new QueryEngine()).updateData(sqlUpdate);
		}
	}
	
	public void archivedUsers(Session session, ArrayList<Integer> selectedUsers) throws Exception {
		if (selectedUsers.size() > 0) {
			String sqlUpdate = "UPDATE User SET Archived =  1 WHERE Id  IN  " + getUsers(selectedUsers);
			(new QueryEngine()).updateData(sqlUpdate);
		}
	}
	
	public void ucp(Integer id, String pw) throws Exception {
		if (pw != null && !pw.isEmpty()) {
			pw = IRadiusSecurity.encode(pw);
			String sql = "UPDATE User set Password = " + DbUtils.dblQuotedField(pw) + " WHERE Id = " + id;
			(new QueryEngine()).delete(sql);
		}
	}
	
	public void changeAccountTypeWithoutBitlling(Session session, Integer dealerId, Integer userId, String userName, Integer newAccountTypeId, String modifiedUserName) throws Exception {
		Table table = new Table("UserNas", "UserId", Boolean.valueOf(false));
		table.setPkFieldValue(userId);
		table.addFieldValue("AccountTypeId", newAccountTypeId);
		(new QueryEngine()).updateData(table);
		String descrption = " Change Account Type Without Billing By : " + modifiedUserName;
		(new TraceUserLog()).traceUserLog(userId, dealerId, userName, "6", descrption);
	}
	
	public void resetMackAddressesForSelectedUsers(Session session, ArrayList<Integer> users) throws Exception {
		if (users.size() > 0) {
			String sqlUpdate = "UPDATE UserNas SET MacAddress =  NULL WHERE UserId  IN  " + getUsers(users);
			(new QueryEngine()).updateData(sqlUpdate);
		}
	}
	
	public void activeSelectedUsers(Session session, ArrayList<Integer> users, boolean active) throws Exception {
		if (users.size() > 0) {
			String sqlUpdate = "UPDATE UserNas SET Active =  " + (active ? "1" : "0") + " WHERE UserId  IN  " + getUsers(users);
			(new QueryEngine()).updateData(sqlUpdate);
			//
			for (Integer userId : users) {
				try {
					(new MikrotikApiDao()).disconnectUser(userId);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public RecordSet getNewVsDeletedUsers(Integer dealerId, Date fromDate, Date toDate) throws Exception {
		RecordSet recordSet = new RecordSet();
		recordSet.getFieldAliases().add("New Users");
		recordSet.getFieldAliases().add("Deleted Users");
		String sqlNew = " SELECT Count(Id) FROM User WHERE (User.ProfileId = 4) AND (User.Archived IS NULL OR User.Archived = 0) ";
		if (dealerId != null) {
			sqlNew = String.valueOf(sqlNew) + " AND User.ParentId = " + dealerId;
		}
		if (fromDate != null && toDate != null) {
			String format = "MM/dd/yyyy";
			String dbFormat = "'%m/%d/%Y'";
			DateFormat df = new SimpleDateFormat(format);
			String strFromDate = df.format(fromDate);
			String strToDate = df.format(toDate);
			strFromDate = "STR_TO_DATE('" + strFromDate + "',  " + dbFormat + "  )";
			strToDate = "STR_TO_DATE( '" + strToDate + "',  " + dbFormat + "  )";
			sqlNew = String.valueOf(sqlNew) + " AND (DATE(User.CreationDate ) >= " + strFromDate + " )";
			sqlNew = String.valueOf(sqlNew) + " AND (DATE(User.CreationDate ) <= " + strToDate + " )";
		}
		String sqlDeleted = " SELECT Count(UserId)  FROM UserLog ";
		sqlDeleted = String.valueOf(sqlDeleted) + " WHERE (OperationTypeId = 3)";
		if (dealerId != null) {
			sqlDeleted = String.valueOf(sqlDeleted) + " AND (DealerId = " + dealerId + ")";
		}
		if (fromDate != null && toDate != null) {
			String format = "MM/dd/yyyy";
			String dbFormat = "'%m/%d/%Y'";
			DateFormat df = new SimpleDateFormat(format);
			String strFromDate = df.format(fromDate);
			String strToDate = df.format(toDate);
			strFromDate = "STR_TO_DATE('" + strFromDate + "',  " + dbFormat + "  )";
			strToDate = "STR_TO_DATE( '" + strToDate + "',  " + dbFormat + "  )";
			sqlDeleted = String.valueOf(sqlDeleted) + " AND (DATE(UserLog.Logdate ) >= " + strFromDate + " )";
			sqlDeleted = String.valueOf(sqlDeleted) + " AND (DATE(UserLog.Logdate ) <= " + strToDate + " )";
		}
		String sql = "Select  (" + sqlNew + ")  as New , " + " (" + sqlDeleted + ") as Deleted ";
		RecordSet recordSet2 = (new QueryEngine()).executeSql(sql);
		for (Record record : recordSet2) {
			Record newRecord = new Record();
			newRecord.add(new IntegerValue(record.getIntegerValue("New")));
			newRecord.add(new IntegerValue(record.getIntegerValue("Deleted")));
			recordSet.add(newRecord);
		}
		recordSet.setTotalRecords(1);
		return recordSet;
	}
	
	public void readOnlyUsers(Session session, ArrayList<Integer> selectedUsers, boolean readonly) throws Exception {
		if (selectedUsers.size() > 0) {
			String sqlUpdate = "UPDATE User SET ReadOnly =  " + (readonly ? 1 : 0) + " WHERE Id  IN  " + getUsers(selectedUsers);
			(new QueryEngine()).updateData(sqlUpdate);
		}
	}
	
	public void updateAccountPriceToAllUsers(Session session, Integer dealerId, Integer accountTypeId, Double accountPrice) throws Exception {
		String sqlUpdate = "UPDATE User set AccountPrice = " + accountPrice //
				+ " WHERE ProfileId = 4 and ParentId = " + dealerId + " AND Id IN " //
				+ " ( Select UserId from UserNas where AccountTypeId = " + accountTypeId + " )  ";
		(new QueryEngine()).updateData(sqlUpdate);
	}
	
	public static void main(String[] args) {
		System.out.println(IRadiusSecurity.encode("admin"));
	}
	
	public boolean resetUserStationAccessPoint(Session session, Integer modifiedUserId2, Integer userId) throws Exception {
		//
		String sqlUpdate = "UPDATE UserNas set StationId = NULL, AccessPointId = NULL WHERE UserId = " + userId;
		(new QueryEngine()).updateData(sqlUpdate);
		return false;
	}
}