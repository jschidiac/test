package me.iradius.server.dao;

import java.net.InetAddress;
import java.util.Date;
import net.jradius.client.RadiusClient;
import net.jradius.packet.DisconnectRequest;
import net.jradius.packet.DisconnectResponse;
import net.jradius.packet.attribute.AttributeDescription;
import net.jradius.packet.attribute.AttributeFactory;
import net.jradius.packet.attribute.AttributeList;
import net.jradius.packet.attribute.RadiusAttribute;



public class MikrotikDisconnectUtils
{
  private static int port = 1700;
  static {
    AttributeFactory.loadAttributeDictionary("net.jradius.dictionary.AttributeDictionaryImpl");
  }

  
  private void disconnectLogTrace(String message) {}
  
  public void disconnectMikrotikByRadiusClient(String nasHost, String sharedSecret, String userName) throws Exception {
    Boolean success = Boolean.valueOf(false);


    
    try {
      String command = "echo \"User-Name='" + userName + "', NAS-IP-Address=" + nasHost + "\" | radclient  " + nasHost + ":1700 disconnect " + sharedSecret;
      ProcessBuilder pb = new ProcessBuilder(new String[] { "bash", "-c", command });
      Process shell = pb.start();
      shell.waitFor();
      success = Boolean.valueOf(true);
    } catch (Exception exception) {}



    
    if (!success.booleanValue()) {
      System.out.println("User cannot disconnect using RadClient");
      InetAddress address = InetAddress.getByName(nasHost);
      
      RadiusClient client = new RadiusClient(address, sharedSecret, port, port, 3);
      
      try {
        client.setAcctPort(port);
        client.setAuthPort(port);
        
        AttributeList attributes = new AttributeList();
        
        AttributeDescription userNameDescription = new AttributeDescription();
        userNameDescription.setName("User-Name");
        userNameDescription.setOp("=");
        userNameDescription.setValue(userName);
        RadiusAttribute userRadiusAttribute = AttributeFactory.newAttribute(userNameDescription);
        attributes.add(userRadiusAttribute);

        
        DisconnectRequest aRequest = new DisconnectRequest(client, attributes);

        
        disconnectLogTrace(String.valueOf(nasHost) + "  --- Before Disconnect User :: [" + userName + "] ");
        synchronized (this) {
          DisconnectResponse response = client.disconnect(aRequest, 0);
          
          if (response instanceof net.jradius.packet.DisconnectNAK) {
            throw new Exception("HotSpot user");
          }
          String errorCause = (String)response.getAttributeValue("Error-Cause");
          if (errorCause != null) {
            throw new Exception("HotSpot user");
          }
        } 
        
        disconnectLogTrace(String.valueOf(nasHost) + "  --- Disconnect User :: [" + userName + "] SuccessFully By RadiusClient " + (new Date()).toString());
      } finally {
        if (client != null)
          client.close(); 
      } 
    } 
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\MikrotikDisconnectUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */