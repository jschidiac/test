package me.iradius.server.dao;

import me.iradius.server.system.IRadiusSecurity;
import me.iradius.shared.db.Table;

public class PasswordManagement
  extends AbstractDaoMgmt {
  public PasswordManagement(Table updateTableDef) {
    super(updateTableDef);
  }



  
  public void executeBeforeUpdate() throws Exception {
    String password = (String)this.updateTableDef.getFieldValues().get("Password");
    if (password != null && !password.isEmpty()) {
      
      password = IRadiusSecurity.encode(password);
      
      this.updateTableDef.addFieldValue("Password", password);
    } 
  }
  
  public void executeAfterUpdate(Integer modifiedUserId, Table updateTableDef, Integer pkFieldValue) throws Exception {}
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\PasswordManagement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */