package me.iradius.server.dao;

import java.util.ArrayList;
import java.util.List;

import me.iradius.mikrotik.ssh.SSHApi;
import me.iradius.server.ctxt.AppContext;
import me.iradius.server.engine.QueryEngine;
import me.iradius.server.scheduler.Notification;
import me.iradius.server.socket.RadiusSocketCLient;
import me.iradius.server.socket.SocketDef;
import me.iradius.shared.db.Table;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;

import org.apache.commons.net.util.SubnetUtils;

public class ExcludeIpRulesDao {
	
	public void applyExcludeNasIpRules(Integer nasId) throws Exception {
		List<String> errors = new ArrayList<String>();
		try {
			Notification notification = (Notification) AppContext.getBean("notification");
			String sql = " SELECT Host, SSHPort, SSHUserName, SSHPassword   FROM Nas ";
			if (nasId != null) {
				sql = String.valueOf(sql) + " Where Id = " + nasId;
			}
			RecordSet recordSet = (new QueryEngine()).executeSql(sql);
			for (Record record : recordSet) {
				String host = record.getStringValue("Host");
				Integer sshPort = record.getIntegerValue("SSHPort");
				String sshUserName = record.getStringValue("SSHUserName");
				String sshPassword = record.getStringValue("SSHPassword");
				try {
					addNetFlowRuleToPPP(host, sshPort, sshUserName, sshPassword, notification.getExcludeIpAddressHost(), notification.getExcludeIpAddressPort());
				} catch (Exception e) {
					System.out.println(host + " Error [" + e.getMessage() + "] \n");
					errors.add(host + " Error [" + e.getMessage() + "] \n");
				}
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		if (errors.size() > 0) {
			String buffer = "";
			for (String error : errors) {
				buffer += error;
			}
			throw new Exception(buffer);
		}
	}
	
	public void applyExcludeIpRules() throws Exception {
		applyExcludeNasIpRules(null);
	}
	
	private void addNetFlowRuleToPPP(String host, Integer sshPort, String sshUserName, String sshPassword, String targetHost, Integer targetPort) throws Exception {
		SSHApi sshApi = new SSHApi(host, sshPort, sshUserName, sshPassword);
		sshApi.executeCommand("/ip traffic-flow set interfaces=all active-flow-timeout=1m enabled=yes");
		sshApi.executeCommand("/ip traffic-flow target add dst-address=" + targetHost + " port=" + targetPort + " v9-template-timeout=1m");
	}
	
	public static void main(String[] args) throws Exception {
		SSHApi sshApi = new SSHApi("172.25.35.13", Integer.valueOf(22), "radius", "r@dius");
		sshApi.executeCommand("/ip traffic-flow set enabled=yes");
		sshApi.disconnect();
	}
	
	private SocketDef getSocketDef() {
		return (SocketDef) AppContext.getBean("socket");
	}
	
	public void addSubnet(String name, String subnet) throws Exception {
		try {
			SubnetUtils utils = new SubnetUtils(subnet);
			SubnetUtils.SubnetInfo info = utils.getInfo();
			String[] allAddresses = info.getAllAddresses();
			for (int i = 0; i < allAddresses.length; i++) {
				Table tableDef = new Table("ExcludeIpAddresses", "Id", Boolean.valueOf(true));
				tableDef.addFieldValue("Name", name);
				tableDef.addFieldValue("IPAddress", allAddresses[i]);
				(new QueryEngine()).updateData(tableDef);
			}
		} finally {
			(new RadiusSocketCLient(getSocketDef())).refreshDictionnary(RadiusSocketCLient.RefreshType.REFRESH_EXCLUDE_IPADDRESS);
		}
	}
	
	public void deleteSubnet(String subnet) throws Exception {
		try {
			SubnetUtils utils = new SubnetUtils(subnet);
			SubnetUtils.SubnetInfo info = utils.getInfo();
			String[] allAddresses = info.getAllAddresses();
			for (int i = 0; i < allAddresses.length; i++) {
				String sqlDelete = "DELETE FROM ExcludeIpAddresses WHERE IPAddress = '" + allAddresses[i] + "' ";
				(new QueryEngine()).delete(sqlDelete);
			}
		} finally {
			(new RadiusSocketCLient(getSocketDef())).refreshDictionnary(RadiusSocketCLient.RefreshType.REFRESH_EXCLUDE_IPADDRESS);
		}
	}
}
