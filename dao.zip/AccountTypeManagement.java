package me.iradius.server.dao;

import java.util.ArrayList;
import me.iradius.server.ctxt.AppContext;
import me.iradius.server.engine.QueryEngine;
import me.iradius.server.socket.RadiusSocketCLient;
import me.iradius.server.socket.SocketDef;
import me.iradius.shared.acctype.AutoFallBackinf;
import me.iradius.shared.acctype.ExtraSpeedDailyInf;
import me.iradius.shared.db.DbUtils;
import me.iradius.shared.db.Table;
import me.iradius.shared.divers.NasDef;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;

public class AccountTypeManagement extends AbstractDaoMgmt {
	
	private Double	oldAccountRate;
	
	public AccountTypeManagement(Table tableDef) {
		super(tableDef);
	}
	
	public void executeBeforeUpdate() throws Exception {
		if (this.updateTableDef != null && !this.updateTableDef.getInsertMode().booleanValue()) {
			String sql = "Select Rate from AccountType where Id = " + this.updateTableDef.getPkFieldValue();
			RecordSet recordSet = (new QueryEngine()).executeSql(sql);
			if (recordSet != null && recordSet.size() > 0) {
				Record record = (Record) recordSet.get(0);
				this.oldAccountRate = record.getDoubleValue("Rate");
			}
		}
	}
	
	private void updateRateForAllRelatedAccounts(int accountId, Double rateToUpdate) throws Exception {
		String sql = "Select Id, Rate from AccountType  where ParentId = " + accountId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet != null) {
			for (Record record : recordSet) {
				Integer accId = record.getIntegerValue("Id");
				Double rate = record.getDoubleValue("Rate");
				Double newRate = Double.valueOf(rate.doubleValue() + rateToUpdate.doubleValue());
				String sqlUpdate = "UPDATE  AccountType  set Rate = " + newRate + " where Id = " + accId;
				(new QueryEngine()).updateData(sqlUpdate);
				updateRateForAllRelatedAccounts(accId.intValue(), rateToUpdate);
			}
		}
	}
	
	public void executeAfterUpdate(Integer modifiedUserId, Table updateTableDef, Integer pkFieldValue) throws Exception {
	}
	
	private void updateLimitNasServers(Integer value, ArrayList<NasDef> serverList) throws Exception {
		if (serverList != null) {
			(new QueryEngine()).deleteRecord("AccoutTypeLimitNasServers", "AccountTypeId", value.toString());
			for (NasDef nasDef : serverList) {
				if (nasDef.getSelected().booleanValue()) {
					String sqlInsert = "INSERT INTO AccoutTypeLimitNasServers (  AccountTypeId, NasHost ) VALUES (" + value + "," + DbUtils.dblQuotedField(nasDef.getHost()) + "  ) ";
					(new QueryEngine()).updateData(sqlInsert);
				}
				for (String server : nasDef.getServers()) {
					String sqlInsert = "INSERT INTO AccoutTypeLimitNasServers (  AccountTypeId, NasHost, NasServer ) VALUES (" + value + "," + DbUtils.dblQuotedField(nasDef.getHost()) + "," + DbUtils.dblQuotedField(server) + "  ) ";
					(new QueryEngine()).updateData(sqlInsert);
				}
			}
		}
	}
	
	private void updateDailyExtraSpeed(Integer value, ArrayList<ExtraSpeedDailyInf> extraSpeedDailyInfs) throws Exception {
		if (extraSpeedDailyInfs != null) {
			(new QueryEngine()).deleteRecord("AccountTypeDailyExtraSpeed", "AccountTypeId", value.toString());
			for (ExtraSpeedDailyInf extraSpeedDailyInf : extraSpeedDailyInfs) {
				Table tableDef = new Table("AccountTypeDailyExtraSpeed", "AccountTypeId", Boolean.valueOf(true));
				tableDef.addFieldValue("AccountTypeId", value);
				tableDef.addFieldValue("FromTime", extraSpeedDailyInf.getFromTime());
				tableDef.addFieldValue("ToTime", extraSpeedDailyInf.getToTime());
				tableDef.addFieldValue("CanOverride", extraSpeedDailyInf.getCanOverride());
				tableDef.addFieldValue("RateUpload", extraSpeedDailyInf.getRateUpload());
				tableDef.addFieldValue("RateDownload", extraSpeedDailyInf.getRateDownload());
				(new QueryEngine()).updateData(tableDef);
			}
		}
	}
	
	private void updateAutoFallBack(Boolean dailyMode, Integer value, ArrayList<AutoFallBackinf> dailyAutoFallBackinfs) throws Exception {
		if (dailyAutoFallBackinfs != null) {
			String tableName = dailyMode.booleanValue() ? "AccountTypeDailyAutoFallBack" : "AccountTypeMonthlyAutoFallBack";
			(new QueryEngine()).deleteRecord(tableName, "AccountTypeId", value.toString());
			for (AutoFallBackinf dailyAutoFallBackinf : dailyAutoFallBackinfs) {
				Table tableDef = new Table(tableName, "AccountTypeId", Boolean.valueOf(true));
				tableDef.addFieldValue("AccountTypeId", value);
				tableDef.addFieldValue("AboveMB", dailyAutoFallBackinf.getAboveMB());
				tableDef.addFieldValue("BasicSpeedUp", dailyAutoFallBackinf.getBasicSpeedUp());
				tableDef.addFieldValue("BasicSpeedDown", dailyAutoFallBackinf.getBasicSpeedDown());
				tableDef.addFieldValue("BurstSpeedUp", dailyAutoFallBackinf.getBurstSpeedUp());
				tableDef.addFieldValue("BurstSpeedDown", dailyAutoFallBackinf.getBurstSpeedDown());
				tableDef.addFieldValue("BurstThreSholdUp", dailyAutoFallBackinf.getBurstThreSholdUp());
				tableDef.addFieldValue("BurstThreSholdDown", dailyAutoFallBackinf.getBurstThreSholdDown());
				tableDef.addFieldValue("BurstTimeUp", dailyAutoFallBackinf.getBurstTimeUp());
				tableDef.addFieldValue("BurstTimeDown", dailyAutoFallBackinf.getBurstTimeDown());
				(new QueryEngine()).updateData(tableDef);
			}
		}
	}
	
	public void executeAfterUpdate(Table updateTableDef, Integer value, ArrayList<NasDef> serverList, ArrayList<ExtraSpeedDailyInf> extraSpeedDailyInfs, ArrayList<AutoFallBackinf> dailyAutoFallBackinfs,
			ArrayList<AutoFallBackinf> monthlyAutoFallBackinfs, Boolean recursivelyChange, Boolean mainAccount) throws Exception {
		if (mainAccount.booleanValue()) {
			updateLimitNasServers(value, serverList);
			updateDailyExtraSpeed(value, extraSpeedDailyInfs);
			updateAutoFallBack(Boolean.valueOf(true), value, dailyAutoFallBackinfs);
			updateAutoFallBack(Boolean.valueOf(false), value, monthlyAutoFallBackinfs);
		}
		if (this.updateTableDef != null && !this.updateTableDef.getInsertMode().booleanValue() && this.oldAccountRate != null && updateTableDef.getFieldValues().get("Rate") != null) {
			Double rateDiff = Double.valueOf(((Double) updateTableDef.getFieldValues().get("Rate")).doubleValue() - this.oldAccountRate.doubleValue());
			updateRateForAllRelatedAccounts(this.updateTableDef.getPkFieldValue().intValue(), rateDiff);
		}
		if (recursivelyChange.booleanValue()) {
			recursevilyChangeAccountType(updateTableDef.getPkFieldValue(), updateTableDef, value, serverList, extraSpeedDailyInfs, dailyAutoFallBackinfs, monthlyAutoFallBackinfs);
		}
		(new RadiusSocketCLient(getSocketDef())).refreshDictionnary("1:" + value);
	}
	
	protected SocketDef getSocketDef() {
		return (SocketDef) AppContext.getBean("socket");
	}
	
	private void recursevilyChangeAccountType(Integer accountTypeId, Table updateTableDef, Integer value, ArrayList<NasDef> serverList, ArrayList<ExtraSpeedDailyInf> extraSpeedDailyInfs, ArrayList<AutoFallBackinf> dailyAutoFallBackinfs,
			ArrayList<AutoFallBackinf> monthlyAutoFallBackinfs) throws Exception {
		String sql = "Select Id From AccountType Where ParentId = " + accountTypeId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet != null && recordSet.size() > 0) {
			for (Record record : recordSet) {
				Integer id = record.getIntegerValue("Id");
				Table tableDef = new Table("AccountType", "Id", Boolean.valueOf(false));
				tableDef.setPkFieldValue(id);
				tableDef.addFieldValue("AccountTypeCategory", updateTableDef.getFieldValues().get("AccountTypeCategory"));
				tableDef.addFieldValue("MaxUsers", updateTableDef.getFieldValues().get("MaxUsers"));
				tableDef.addFieldValue("Refundable", updateTableDef.getFieldValues().get("Refundable"));
				tableDef.addFieldValue("AutoBindAccToMac", updateTableDef.getFieldValues().get("AutoBindAccToMac"));
				tableDef.addFieldValue("CanChangeMac", updateTableDef.getFieldValues().get("CanChangeMac"));
				tableDef.addFieldValue("CanChangeUserName", updateTableDef.getFieldValues().get("CanChangeUserName"));
				tableDef.addFieldValue("ImmediateRecharge", updateTableDef.getFieldValues().get("ImmediateRecharge"));
				tableDef.addFieldValue("PreventBeforeRecharge", updateTableDef.getFieldValues().get("PreventBeforeRecharge"));
				tableDef.addFieldValue("ValidityPeriod", updateTableDef.getFieldValues().get("ValidityPeriod"));
				tableDef.addFieldValue("ValidityPeriodTypeId", updateTableDef.getFieldValues().get("ValidityPeriodTypeId"));
				tableDef.addFieldValue("TotalSession", updateTableDef.getFieldValues().get("TotalSession"));
				tableDef.addFieldValue("TotalSessionPeriodTypeId", updateTableDef.getFieldValues().get("TotalSessionPeriodTypeId"));
				tableDef.addFieldValue("CanShowOnUserInterface", updateTableDef.getFieldValues().get("CanShowOnUserInterface"));
				tableDef.addFieldValue("CanExcludeQuotaByIpAddress", updateTableDef.getFieldValues().get("CanExcludeQuotaByIpAddress"));
				if (updateTableDef.getFieldValues().containsKey("UlDlForAutoFallBack")) {
					tableDef.addFieldValue("UlDlForAutoFallBack", updateTableDef.getFieldValues().get("UlDlForAutoFallBack"));
				}
				tableDef.addFieldValue("IpPoolName", updateTableDef.getFieldValues().get("IpPoolName"));
				tableDef.addFieldValue("BasicSpeedUp", updateTableDef.getFieldValues().get("BasicSpeedUp"));
				tableDef.addFieldValue("BasicSpeedDown", updateTableDef.getFieldValues().get("BasicSpeedDown"));
				tableDef.addFieldValue("AutoBindAccToMac", updateTableDef.getFieldValues().get("AutoBindAccToMac"));
				tableDef.addFieldValue("Refundable", updateTableDef.getFieldValues().get("Refundable"));
				tableDef.addFieldValue("MaxUsers", updateTableDef.getFieldValues().get("MaxUsers"));
				tableDef.addFieldValue("CanChangeMac", updateTableDef.getFieldValues().get("CanChangeMac"));
				tableDef.addFieldValue("CanChangeUserName", updateTableDef.getFieldValues().get("CanChangeUserName"));
				//
				if (updateTableDef.getFieldValues().containsKey("ImmediateRecharge"))
					tableDef.addFieldValue("ImmediateRecharge", updateTableDef.getFieldValues().get("ImmediateRecharge"));
				//
				if (updateTableDef.getFieldValues().containsKey("PreventBeforeRecharge"))
					tableDef.addFieldValue("PreventBeforeRecharge", updateTableDef.getFieldValues().get("PreventBeforeRecharge"));
				//
				if (updateTableDef.getFieldValues().containsKey("ValidityPeriod"))
					tableDef.addFieldValue("ValidityPeriod", updateTableDef.getFieldValues().get("ValidityPeriod"));
				//
				if (updateTableDef.getFieldValues().containsKey("ValidityPeriodTypeId"))
					tableDef.addFieldValue("ValidityPeriodTypeId", updateTableDef.getFieldValues().get("ValidityPeriodTypeId"));
				//
				if (updateTableDef.getFieldValues().containsKey("TotalSession"))
					tableDef.addFieldValue("TotalSession", updateTableDef.getFieldValues().get("TotalSession"));
				//
				if (updateTableDef.getFieldValues().containsKey("TotalSessionPeriodTypeId"))
					tableDef.addFieldValue("TotalSessionPeriodTypeId", updateTableDef.getFieldValues().get("TotalSessionPeriodTypeId"));
				//
				if (updateTableDef.getFieldValues().containsKey("CombinedMaxMonthlyUpAndDown"))
					tableDef.addFieldValue("CombinedMaxMonthlyUpAndDown", updateTableDef.getFieldValues().get("CombinedMaxMonthlyUpAndDown"));
				//
				if (updateTableDef.getFieldValues().containsKey("SeperateMaxMonthlyUp"))
					tableDef.addFieldValue("SeperateMaxMonthlyUp", updateTableDef.getFieldValues().get("SeperateMaxMonthlyUp"));
				//
				if (updateTableDef.getFieldValues().containsKey("SeperateMaxMonthlyDown"))
					tableDef.addFieldValue("SeperateMaxMonthlyDown", updateTableDef.getFieldValues().get("SeperateMaxMonthlyDown"));
				//
				if (updateTableDef.getFieldValues().containsKey("UlDlForAutoFallBack"))
					tableDef.addFieldValue("UlDlForAutoFallBack", updateTableDef.getFieldValues().get("UlDlForAutoFallBack"));
				//
				if (updateTableDef.getFieldValues().containsKey("UnlimtedTimeTo"))
					tableDef.addFieldValue("UnlimtedTimeTo", updateTableDef.getFieldValues().get("UnlimtedTimeTo"));
				//
				if (updateTableDef.getFieldValues().containsKey("UmlimitedTimeFrom"))
					tableDef.addFieldValue("UmlimitedTimeFrom", updateTableDef.getFieldValues().get("UmlimitedTimeFrom"));
				//
				if (updateTableDef.getFieldValues().containsKey("NewIpPoolAfterMax"))
					tableDef.addFieldValue("NewIpPoolAfterMax", updateTableDef.getFieldValues().get("NewIpPoolAfterMax"));
				//
				if (updateTableDef.getFieldValues().containsKey("SeperateMaxDailyDown"))
					tableDef.addFieldValue("SeperateMaxDailyDown", updateTableDef.getFieldValues().get("SeperateMaxDailyDown"));
				//
				if (updateTableDef.getFieldValues().containsKey("SeperateMaxDailyUp"))
					tableDef.addFieldValue("SeperateMaxDailyUp", updateTableDef.getFieldValues().get("SeperateMaxDailyUp"));
				//
				if (updateTableDef.getFieldValues().containsKey("CombinedMaxUpAndDown"))
					tableDef.addFieldValue("CombinedMaxUpAndDown", updateTableDef.getFieldValues().get("CombinedMaxUpAndDown"));
				//
				if (updateTableDef.getFieldValues().containsKey("ResetCounterTime"))
					tableDef.addFieldValue("ResetCounterTime", updateTableDef.getFieldValues().get("ResetCounterTime"));
				//
				if (updateTableDef.getFieldValues().containsKey("MonthlyPoolAfterMax"))
					tableDef.addFieldValue("MonthlyPoolAfterMax", updateTableDef.getFieldValues().get("MonthlyPoolAfterMax"));
				//
				if (updateTableDef.getFieldValues().containsKey("ExpiryAccountPool"))
					tableDef.addFieldValue("ExpiryAccountPool", updateTableDef.getFieldValues().get("ExpiryAccountPool"));
				//
				if (updateTableDef.getFieldValues().containsKey("UlDlMonthlyForAutoFallBack"))
					tableDef.addFieldValue("UlDlMonthlyForAutoFallBack", updateTableDef.getFieldValues().get("UlDlMonthlyForAutoFallBack"));
				//
				if (updateTableDef.getFieldValues().containsKey("CanShowOnUserInterface"))
					tableDef.addFieldValue("CanShowOnUserInterface", updateTableDef.getFieldValues().get("CanShowOnUserInterface"));
				//
				if (updateTableDef.getFieldValues().containsKey("CanExcludeQuotaByIpAddress"))
					tableDef.addFieldValue("CanExcludeQuotaByIpAddress", updateTableDef.getFieldValues().get("CanExcludeQuotaByIpAddress"));
				//
				if (updateTableDef.getFieldValues().containsKey("CombinedMaxUpAndDown")) {
					tableDef.addFieldValue("CombinedMaxUpAndDown", updateTableDef.getFieldValues().get("CombinedMaxUpAndDown"));
				}
				if (updateTableDef.getFieldValues().containsKey("SeperateMaxDailyUp")) {
					tableDef.addFieldValue("SeperateMaxDailyUp", updateTableDef.getFieldValues().get("SeperateMaxDailyUp"));
				}
				if (updateTableDef.getFieldValues().containsKey("SeperateMaxDailyDown")) {
					tableDef.addFieldValue("SeperateMaxDailyDown", updateTableDef.getFieldValues().get("SeperateMaxDailyDown"));
				}
				if (updateTableDef.getFieldValues().containsKey("NewIpPoolAfterMax")) {
					tableDef.addFieldValue("NewIpPoolAfterMax", updateTableDef.getFieldValues().get("NewIpPoolAfterMax"));
				}
				if (updateTableDef.getFieldValues().containsKey("UmlimitedTimeFrom")) {
					tableDef.addFieldValue("UmlimitedTimeFrom", updateTableDef.getFieldValues().get("UmlimitedTimeFrom"));
				}
				if (updateTableDef.getFieldValues().containsKey("UnlimtedTimeTo")) {
					tableDef.addFieldValue("UnlimtedTimeTo", updateTableDef.getFieldValues().get("UnlimtedTimeTo"));
				}
				if (updateTableDef.getFieldValues().containsKey("CombinedMaxMonthlyUpAndDown")) {
					tableDef.addFieldValue("CombinedMaxMonthlyUpAndDown", updateTableDef.getFieldValues().get("CombinedMaxMonthlyUpAndDown"));
				}
				if (updateTableDef.getFieldValues().containsKey("SeperateMaxMonthlyUp")) {
					tableDef.addFieldValue("SeperateMaxMonthlyUp", updateTableDef.getFieldValues().get("SeperateMaxMonthlyUp"));
				}
				if (updateTableDef.getFieldValues().containsKey("SeperateMaxMonthlyDown")) {
					tableDef.addFieldValue("SeperateMaxMonthlyDown", updateTableDef.getFieldValues().get("SeperateMaxMonthlyDown"));
				}
				if (updateTableDef.getFieldValues().containsKey("MonthlyPoolAfterMax")) {
					tableDef.addFieldValue("MonthlyPoolAfterMax", updateTableDef.getFieldValues().get("MonthlyPoolAfterMax"));
				}
				if (updateTableDef.getFieldValues().containsKey("UlDlMonthlyForAutoFallBack")) {
					tableDef.addFieldValue("UlDlMonthlyForAutoFallBack", updateTableDef.getFieldValues().get("UlDlMonthlyForAutoFallBack"));
				}
				(new QueryEngine()).updateData(tableDef);
				executeAfterUpdate(tableDef, id, serverList, extraSpeedDailyInfs, dailyAutoFallBackinfs, monthlyAutoFallBackinfs, Boolean.valueOf(true), true); // Boolean.valueOf(false));
			}
		}
	}
	
	private Integer cloneAccountTypeTableByDealer(Integer accountTypeId, String newAccountName, Double commission, Integer dealerId) throws Exception {
		String sql = " SELECT Id, AccountTypeName, DealerId, ParentId, AccountTypeCategory, Rate, SellingPrice, Commision, IpPoolName,  BasicSpeedUp, BasicSpeedDown , CanExcludeQuotaByIpAddress ,   MaxUsers,   AutoBindAccToMac, Refundable, CanChangeMac, CanChangeUserName, ImmediateRecharge, PreventBeforeRecharge, ValidityPeriod,  ValidityPeriodTypeId, TotalSession, TotalSessionPeriodTypeId, CombinedMaxMonthlyUpAndDown, SeperateMaxMonthlyUp,  SeperateMaxMonthlyDown, UlDlForAutoFallBack,  UnlimtedTimeTo, UmlimitedTimeFrom, NewIpPoolAfterMax, UlDlMonthlyForAutoFallBack , SeperateMaxDailyDown, SeperateMaxDailyUp, CombinedMaxUpAndDown, ResetCounterTime, MonthlyPoolAfterMax, ExpiryAccountPool, CanShowOnUserInterface  FROM  AccountType  WHERE Id = "
				+ accountTypeId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet != null && recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			Double rate = Double.valueOf((record.getDoubleValue("Rate") != null) ? record.getDoubleValue("Rate").doubleValue() : 0.0D);
			Table tableDef = new Table("AccountType", "Id", Boolean.valueOf(true));
			tableDef.addFieldValue("AccountTypeName", newAccountName);
			tableDef.addFieldValue("DealerId", dealerId);
			tableDef.addFieldValue("ParentId", accountTypeId);
			tableDef.addFieldValue("Rate", Double.valueOf(rate.doubleValue() + ((commission == null) ? 0.0D : commission.doubleValue())));
			tableDef.addFieldValue("Commision", commission);
			tableDef.addFieldValue("SellingPrice", record.getValue("SellingPrice"));
			tableDef.addFieldValue("AccountTypeCategory", record.getValue("AccountTypeCategory"));
			tableDef.addFieldValue("IpPoolName", record.getValue("IpPoolName"));
			tableDef.addFieldValue("BasicSpeedUp", record.getValue("BasicSpeedUp"));
			tableDef.addFieldValue("BasicSpeedDown", record.getValue("BasicSpeedDown"));
			tableDef.addFieldValue("AutoBindAccToMac", record.getValue("AutoBindAccToMac"));
			tableDef.addFieldValue("Refundable", record.getValue("Refundable"));
			tableDef.addFieldValue("MaxUsers", record.getValue("MaxUsers"));
			tableDef.addFieldValue("CanChangeMac", record.getValue("CanChangeMac"));
			tableDef.addFieldValue("CanChangeUserName", record.getValue("CanChangeUserName"));
			tableDef.addFieldValue("ImmediateRecharge", record.getValue("ImmediateRecharge"));
			tableDef.addFieldValue("PreventBeforeRecharge", record.getValue("PreventBeforeRecharge"));
			tableDef.addFieldValue("ValidityPeriod", record.getValue("ValidityPeriod"));
			tableDef.addFieldValue("ValidityPeriodTypeId", record.getValue("ValidityPeriodTypeId"));
			tableDef.addFieldValue("TotalSession", record.getValue("TotalSession"));
			tableDef.addFieldValue("TotalSessionPeriodTypeId", record.getValue("TotalSessionPeriodTypeId"));
			tableDef.addFieldValue("CombinedMaxMonthlyUpAndDown", record.getValue("CombinedMaxMonthlyUpAndDown"));
			tableDef.addFieldValue("SeperateMaxMonthlyUp", record.getValue("SeperateMaxMonthlyUp"));
			tableDef.addFieldValue("SeperateMaxMonthlyDown", record.getValue("SeperateMaxMonthlyDown"));
			tableDef.addFieldValue("UlDlForAutoFallBack", record.getValue("UlDlForAutoFallBack"));
			tableDef.addFieldValue("UnlimtedTimeTo", record.getValue("UnlimtedTimeTo"));
			tableDef.addFieldValue("UmlimitedTimeFrom", record.getValue("UmlimitedTimeFrom"));
			tableDef.addFieldValue("NewIpPoolAfterMax", record.getValue("NewIpPoolAfterMax"));
			tableDef.addFieldValue("SeperateMaxDailyDown", record.getValue("SeperateMaxDailyDown"));
			tableDef.addFieldValue("SeperateMaxDailyUp", record.getValue("SeperateMaxDailyUp"));
			tableDef.addFieldValue("CombinedMaxUpAndDown", record.getValue("CombinedMaxUpAndDown"));
			tableDef.addFieldValue("ResetCounterTime", record.getValue("ResetCounterTime"));
			tableDef.addFieldValue("MonthlyPoolAfterMax", record.getValue("MonthlyPoolAfterMax"));
			tableDef.addFieldValue("ExpiryAccountPool", record.getValue("ExpiryAccountPool"));
			tableDef.addFieldValue("UlDlMonthlyForAutoFallBack", record.getValue("UlDlMonthlyForAutoFallBack"));
			tableDef.addFieldValue("CanShowOnUserInterface", record.getValue("CanShowOnUserInterface"));
			tableDef.addFieldValue("CanExcludeQuotaByIpAddress", record.getValue("CanExcludeQuotaByIpAddress"));
			return (new QueryEngine()).updateData(tableDef);
		}
		return null;
	}
	
	private void cloneAccoutTypeLimitNasServers(Integer accountTypeId, Integer newAccountTypeId) throws Exception {
		String sql = " SELECT  NasHost, NasServer  FROM  AccoutTypeLimitNasServers WHERE AccountTypeId = " + accountTypeId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet != null && recordSet.size() > 0) {
			for (Record record : recordSet) {
				Table tableDef = new Table("AccoutTypeLimitNasServers", "Id", Boolean.valueOf(true));
				tableDef.addFieldValue("AccountTypeId", newAccountTypeId);
				tableDef.addFieldValue("NasHost", record.getValue("NasHost"));
				tableDef.addFieldValue("NasServer", record.getValue("NasServer"));
				(new QueryEngine()).updateData(tableDef);
			}
		}
	}
	
	private void cloneAccountTypeDailyExtraSpeed(Integer accountTypeId, Integer newAccountTypeId) throws Exception {
		String sql = " SELECT  FromTime, ToTime, CanOverride,  RateUpload, RateDownload  FROM  AccountTypeDailyExtraSpeed  WHERE AccountTypeId = " + accountTypeId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet != null && recordSet.size() > 0) {
			for (Record record : recordSet) {
				Table tableDef = new Table("AccountTypeDailyExtraSpeed", "AccountTypeId", Boolean.valueOf(true));
				tableDef.addFieldValue("AccountTypeId", newAccountTypeId);
				tableDef.addFieldValue("FromTime", record.getValue("FromTime"));
				tableDef.addFieldValue("ToTime", record.getValue("ToTime"));
				tableDef.addFieldValue("CanOverride", record.getValue("CanOverride"));
				tableDef.addFieldValue("RateUpload", record.getValue("RateUpload"));
				tableDef.addFieldValue("RateDownload", record.getValue("RateDownload"));
				(new QueryEngine()).updateData(tableDef);
			}
		}
	}
	
	private void cloneAccountTypeAutoFallBack(String tabelName, Integer accountTypeId, Integer newAccountTypeId) throws Exception {
		String sql = " SELECT AccountTypeId, AboveMB,   BasicSpeedUp, BasicSpeedDown, BurstSpeedUp, BurstSpeedDown, BurstThreSholdUp, BurstThreSholdDown, BurstTimeUp, BurstTimeDown  FROM  " + tabelName + " WHERE AccountTypeId = " + accountTypeId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet != null && recordSet.size() > 0) {
			for (Record record : recordSet) {
				Table tableDef = new Table(tabelName, "AccountTypeId", Boolean.valueOf(true));
				tableDef.addFieldValue("AccountTypeId", newAccountTypeId);
				tableDef.addFieldValue("AboveMB", record.getValue("AboveMB"));
				tableDef.addFieldValue("BasicSpeedUp", record.getValue("BasicSpeedUp"));
				tableDef.addFieldValue("BasicSpeedDown", record.getValue("BasicSpeedDown"));
				tableDef.addFieldValue("BurstSpeedUp", record.getValue("BurstSpeedUp"));
				tableDef.addFieldValue("BurstSpeedDown", record.getValue("BurstSpeedDown"));
				tableDef.addFieldValue("BurstThreSholdUp", record.getValue("BurstThreSholdUp"));
				tableDef.addFieldValue("BurstThreSholdDown", record.getValue("BurstThreSholdDown"));
				tableDef.addFieldValue("BurstTimeUp", record.getValue("BurstTimeUp"));
				tableDef.addFieldValue("BurstTimeDown", record.getValue("BurstTimeDown"));
				(new QueryEngine()).updateData(tableDef);
			}
		}
	}
	
	private void cloneAccountTypeByDealer(SocketDef socketDef, Integer accountTypeId, String newAccountName, Double commission, Integer dealerId) throws Exception {
		Integer newAccountTypeId = cloneAccountTypeTableByDealer(accountTypeId, newAccountName, commission, dealerId);
		if (newAccountTypeId != null) {
			cloneAccountTypeAutoFallBack("AccountTypeDailyAutoFallBack", accountTypeId, newAccountTypeId);
			cloneAccountTypeDailyExtraSpeed(accountTypeId, newAccountTypeId);
			cloneAccoutTypeLimitNasServers(accountTypeId, newAccountTypeId);
			cloneAccountTypeAutoFallBack("AccountTypeMonthlyAutoFallBack", accountTypeId, newAccountTypeId);
			(new RadiusSocketCLient(socketDef)).refreshDictionnary("1:" + newAccountTypeId);
		}
	}
	
	public void cloneAccountTypeByDealers(SocketDef socketDef, Integer accountTypeId, String newAccountName, Double commission, ArrayList<Object> dealers) throws Exception {
		if (dealers != null) {
			for (Object dealer : dealers) {
				Integer dealerId = (Integer) dealer;
				cloneAccountTypeByDealer(socketDef, accountTypeId, newAccountName, commission, dealerId);
			}
		}
	}
	
	public void addDealerAccountType(SocketDef socketDef, Integer accountTypeId, String newAccountName, Double commission, Integer dealerId) throws Exception {
		cloneAccountTypeByDealer(socketDef, accountTypeId, newAccountName, commission, dealerId);
	}
	
	public void checkIfExistLinkedUsers(String accountTypeId) throws Exception {
		String sql = " SELECT count(AccountTypeId) count from UserNas where AccountTypeId = " + accountTypeId;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet != null && recordSet.size() > 0) {
			Integer count = ((Record) recordSet.get(0)).getIntegerValue("count");
			if (count.intValue() > 0) {
				throw new Exception("Account Type is linked to users, Please delete linked users before.");
			}
		}
	}
	
	public void changeAccountTypeCommission(Integer accountTypeId, Double oldCommision, Double newCommission) throws Exception {
		try {
			Double minusnewRate = Double.valueOf(oldCommision.doubleValue() - newCommission.doubleValue());
			String strRate = "";
			if (newCommission.doubleValue() < oldCommision.doubleValue()) {
				strRate = " Rate - " + minusnewRate;
			} else {
				Double plusRate = Double.valueOf(newCommission.doubleValue() - oldCommision.doubleValue());
				strRate = " Rate + " + plusRate;
			}
			String sql = " UPDATE AccountType SET Commision = " + newCommission + " , Rate = " + strRate + "  WHERE   Id = " + accountTypeId;
			(new QueryEngine()).updateData(sql);
			updateRateForAllRelatedAccounts(accountTypeId.intValue(), Double.valueOf(newCommission.doubleValue() - oldCommision.doubleValue()));
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
}
/*
 * Location:
 * C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server
 * \dao\AccountTypeManagement.class Java compiler version: 7 (51.0) JD-Core
 * Version: 1.1.3
 */