package me.iradius.server.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import me.iradius.server.ctxt.AppContext;
import me.iradius.server.engine.QueryEngine;
import me.iradius.server.scheduler.RenewUserAccountScheduler;
import me.iradius.server.socket.RadiusSocketCLient;
import me.iradius.server.socket.SocketDef;
import me.iradius.shared.db.DbUtils;
import me.iradius.shared.db.Query;
import me.iradius.shared.db.Table;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;

public class BulkManagement extends AbstractDaoMgmt {
	
	private HashMap<Integer, String>	users		= new HashMap<>();
	private HashMap<Integer, String>	passwords	= new HashMap<>();
	
	public BulkManagement() {
		super(null);
	}
	
	public BulkManagement(Table updateTableDef) {
		super(updateTableDef);
	}
	
	public void executeBeforeUpdate() throws Exception {
	}
	
	public void executeAfterUpdate(Integer modifiedUserId, Table updateTableDef, Integer pkFieldValue) throws Exception {
	}
	
	private void calculateUsers(Query queryDef) throws Exception {
		this.users.clear();
		this.passwords.clear();
		RecordSet recordSet = (new QueryEngine()).getData(null, queryDef, 0, 0, false);
		for (Record record : recordSet) {
			Integer userId = record.getIntegerValue("Id");
			String userName = record.getStringValue("UserName");
			String password = record.getStringValue("Password");
			this.users.put(userId, userName);
			this.passwords.put(userId, password);
		}
	}
	
	private String getUsers() {
		String result = "";
		for (Integer userId : this.users.keySet()) {
			if (!result.isEmpty())
				result = String.valueOf(result) + " , ";
			result = String.valueOf(result) + userId;
		}
		if (!result.isEmpty()) {
			result = "( " + result + " )";
		}
		return result;
	}
	
	private void traceBulk(Integer accountTypeId, Integer newDealerId, Date expiryDate, Boolean disabled, Boolean deleted) throws Exception {
		Date operationDate = new Date((new Date()).getTime());
		for (Map.Entry<Integer, String> entry : this.users.entrySet()) {
			Integer userId = entry.getKey();
			String userName = entry.getValue();
			Table tableDef = new Table("BulkLog", "Id", Boolean.valueOf(true));
			tableDef.setPkFieldValue(userId);
			tableDef.addFieldValue("UserId", userId);
			tableDef.addFieldValue("UserName", userName);
			tableDef.addFieldValue("AccountTypeId", accountTypeId);
			tableDef.addFieldValue("DealerId", newDealerId);
			tableDef.addFieldValue("ExpiryDate", expiryDate);
			tableDef.addFieldValue("Disabled", disabled);
			tableDef.addFieldValue("Deleted", deleted);
			tableDef.addFieldValue("OperationDate", operationDate);
			(new QueryEngine()).updateData(tableDef);
		}
	}
	
	private void traceUserDeleted() throws Exception {
		for (Map.Entry<Integer, String> entry : this.users.entrySet()) {
			Integer userId = entry.getKey();
			String userName = entry.getValue();
			String password = this.passwords.get(userId);
			Table tableDef = new Table("UserDeleted", "Id", Boolean.valueOf(true));
			tableDef.addFieldValue("UserName", userName);
			tableDef.addFieldValue("Password", password);
			(new QueryEngine()).updateData(tableDef);
		}
	}
	
	private void performNewAccountTypeId(Integer newAccountTypeId) throws Exception {
		String sqlUpdate = "UPDATE UserNas SET AccountTypeId =  " + newAccountTypeId + "  WHERE UserId  IN  " + getUsers();
		(new QueryEngine()).updateData(sqlUpdate);
	}
	
	private void performNewDealer(Integer newDealerId) throws Exception {
		String sqlUpdate = "UPDATE User SET ParentId =  " + newDealerId + "  WHERE Id  IN  " + getUsers();
		(new QueryEngine()).updateData(sqlUpdate);
	}
	
	private void performNewExpiryDate(Date newExpiryDate) throws Exception {
		String format = "MM/dd/yyyy HH:mm:ss";
		String dbFormat = "%m/%d/%Y %H:%i:%s";
		DateFormat df = new SimpleDateFormat(format);
		String strExpiryDate = df.format(newExpiryDate);
		strExpiryDate = "STR_TO_DATE( '" + strExpiryDate + "', '" + dbFormat + "' )";
		String sqlUpdate = "UPDATE UserNas SET ExpiryAccount =  " + strExpiryDate + "  WHERE UserId  IN  " + getUsers();
		(new QueryEngine()).updateData(sqlUpdate);
	}
	
	private void performDisabledAccount(Boolean disabledAccount) throws Exception {
		String sqlUpdate = "UPDATE UserNas   SET Active =  " + (disabledAccount.booleanValue() ? "0" : "1") + "  WHERE UserId  IN  " + getUsers();
		(new QueryEngine()).updateData(sqlUpdate);
	}
	
	private void performDeleteAccounts() throws Exception {
		String sqlDelete = "DELETE FROM User WHERE Id IN  " + getUsers();
		(new QueryEngine()).updateData(sqlDelete);
	}
	
	private void performClearMackAddress() throws Exception {
		String sqlClearMacAddress = "UPDATE UserNas   SET MacAddress = null WHERE UserId  IN  " + getUsers();
		(new QueryEngine()).updateData(sqlClearMacAddress);
	}
	
	private void performResetOverrideExpiry() throws Exception {
		String sqlClearMacAddress = "UPDATE UserNas SET OverrideExpiryAccount  = null , ForceExpiryAfterDays  = null WHERE UserId  IN  " + getUsers();
		(new QueryEngine()).updateData(sqlClearMacAddress);
	}
	
	private void performChangePassword(String password) throws Exception {
		String sqlUpdate = "UPDATE User SET Password =  " + DbUtils.dblQuotedField(password) + "  WHERE Id  IN  " + getUsers();
		(new QueryEngine()).updateData(sqlUpdate);
	}
	
	private void performResetMonthlyQuota() throws Exception {
		String sqlClearMacAddress = "UPDATE UserNas   SET DownloadBytes = 0 ,  UploadBytes = 0,  FreeDownloadBytes = 0,  FreeUploadBytes = 0  WHERE UserId  IN  " + getUsers();
		(new QueryEngine()).updateData(sqlClearMacAddress);
	}
	
	public void performBulk(Query queryDef, Integer newAccountTypeId, Integer newDealerId, Date newExpiryDate, Boolean disabledAccount, Boolean deleteOperation, Boolean clearMacAddressOperation, Boolean resetMontlyQuota, String password,
			Boolean resetOverrideExpiry) throws Exception {
		Boolean refreshRadiusSessions = Boolean.valueOf(false);
		Boolean deleteSessions = Boolean.valueOf(false);
		calculateUsers(queryDef);
		if (newAccountTypeId != null) {
			performNewAccountTypeId(newAccountTypeId);
			traceBulk(newAccountTypeId, null, null, null, null);
		}
		if (newDealerId != null) {
			performNewDealer(newDealerId);
			traceBulk(newAccountTypeId, newDealerId, null, null, null);
		}
		if (newExpiryDate != null) {
			performNewExpiryDate(newExpiryDate);
			traceBulk(null, null, newExpiryDate, null, null);
			refreshRadiusSessions = Boolean.valueOf(true);
		}
		if (disabledAccount != null) {
			performDisabledAccount(disabledAccount);
			traceBulk(null, null, null, disabledAccount, null);
			deleteSessions = Boolean.valueOf(true);
		}
		if (deleteOperation != null && deleteOperation.booleanValue()) {
			disconnectRadiusUsers();
			performDeleteAccounts();
			traceBulk(null, null, null, null, deleteOperation);
			traceUserDeleted();
			deleteSessions = Boolean.valueOf(true);
		}
		if (clearMacAddressOperation != null && clearMacAddressOperation.booleanValue()) {
			performClearMackAddress();
		}
		if (resetOverrideExpiry != null && resetOverrideExpiry.booleanValue()) {
			performResetOverrideExpiry();
		}
		if (resetMontlyQuota != null && resetMontlyQuota.booleanValue()) {
			performResetMonthlyQuota();
			refreshRadiusSessions = Boolean.valueOf(true);
		}
		if (password != null) {
			performChangePassword(password);
			refreshRadiusSessions = Boolean.valueOf(true);
		}
		RenewUserAccountScheduler renewUserAccountScheduler = (RenewUserAccountScheduler) AppContext.getBean("renewUserAccountScheduler");
		renewUserAccountScheduler.startSchedule();
		if (refreshRadiusSessions.booleanValue()) {
			SocketDef socketDef = (SocketDef) AppContext.getBean("socket");
			(new RadiusSocketCLient(socketDef)).refreshDictionnary(RadiusSocketCLient.RefreshType.REFRESH_SESSIONS);
		} else if (deleteSessions.booleanValue()) {
			disconnectRadiusUsersByThread();
		}
	}
	
	private void disconnectRadiusUsers() {
		MikrotikApiDao mikrotikApiDao = new MikrotikApiDao();
		for (Integer userId : this.users.keySet()) {
			try {
				mikrotikApiDao.disconnectUser(userId);
			} catch (Exception exception) {
			}
		}
	}
	
	private void disconnectRadiusUsersByThread() throws Exception {
		(new Thread(new Runnable() {
			
			public void run() {
				BulkManagement.this.disconnectRadiusUsers();
			}
		})).start();
	}
}
/*
 * Location:
 * C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server
 * \dao\BulkManagement.class Java compiler version: 7 (51.0) JD-Core Version:
 * 1.1.3
 */