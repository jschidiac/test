package me.iradius.server.dao;

import java.util.ArrayList;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.db.Table;

public class ExcludeAdjustBandwidthManagement
  extends AbstractDaoMgmt
{
  public ExcludeAdjustBandwidthManagement() {
    super(null);
  }





  
  public void executeBeforeUpdate(ArrayList<Table> updateTableDefs) throws Exception {}





  
  public void deleteExclude(Integer adjustBandwidthId) throws Exception {
    (new QueryEngine()).deleteRecord("ExcludeAdjustBandwidth", "AdjustBandwidthId", adjustBandwidthId.toString());
    
    (new QueryEngine()).deleteRecord("AdjustBandwidthDays", "AdjustBandwidthId", adjustBandwidthId.toString());
  }
  
  public void executeBeforeUpdate() throws Exception {}
  
  public void executeAfterUpdate(Integer modifiedUserId, Table updateTableDef, Integer pkFieldValue) throws Exception {}
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\ExcludeAdjustBandwidthManagement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */