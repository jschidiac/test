package me.iradius.server.dao;

import java.util.ArrayList;
import me.iradius.server.ctxt.AppContext;
import me.iradius.server.db.DataSource;
import me.iradius.server.socket.SocketDef;
import me.iradius.shared.db.Table;





public abstract class AbstractDaoMgmt
{
  protected Table updateTableDef;
  protected Integer pkFieldValue;
  private DataSource dataSource;
  
  public abstract void executeBeforeUpdate() throws Exception;
  
  public abstract void executeAfterUpdate(Integer paramInteger1, Table paramTable, Integer paramInteger2) throws Exception;
  
  public AbstractDaoMgmt(Table updateTableDef) {
    this.updateTableDef = updateTableDef;
  }
  
  protected SocketDef getSocketDef() {
    return (SocketDef)AppContext.getBean("socket");
  }

  
  public void executeBeforeUpdate(ArrayList<Table> updateTableDefs) throws Exception {}
  
  public Table getUpdateTableDef() {
    return this.updateTableDef;
  }
  
  public void setUpdateTableDef(Table updateTableDef) {
    this.updateTableDef = updateTableDef;
  }
  
  public Integer getPkFieldValue() {
    return this.pkFieldValue;
  }
  
  public void setPkFieldValue(Integer pkFieldValue) {
    this.pkFieldValue = pkFieldValue;
  }
  
  public DataSource getDataSource() {
    return this.dataSource;
  }
  
  public void setDataSource(DataSource dataSource) {
    this.dataSource = dataSource;
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\AbstractDaoMgmt.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */