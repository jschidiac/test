package me.iradius.server.dao.dashboard;

import java.io.File;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import me.iradius.server.ctxt.AppContext;
import me.iradius.server.dealer.DealerConfiguration;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.dashboard.DashboardAccountsInfo;
import me.iradius.shared.dashboard.DashboardKpiInfo;
import me.iradius.shared.dashboard.DashboardSystemType;
import me.iradius.shared.dashboard.DashboardTopDealersInfo;
import me.iradius.shared.dashboard.DashboardTransactionInfo;
import me.iradius.shared.dashboard.DashboardUsersInfo;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.Session;

import com.jezhumble.javasysmon.CpuTimes;
import com.jezhumble.javasysmon.JavaSysMon;

public class DashboardDao {
	
	// "OnlineOffline"
	// "ActiveInactive"
	// "NewTotal"
	// "Expired"
	// "Dealers"
	// "FUP"
	private String sqlByType(Session session, String type) {
		//
		String sqlFilter = "";
		if (session.isDealer()) {
			sqlFilter = "AND User.ParentId IN " + session.getDealers();
		} else if (!session.isAdmin()) {
			sqlFilter = "AND User.ParentId = " + session.getDealerId();
		}
		//
		String sql = "";
		if (type.equalsIgnoreCase("ActiveInactive")) {
			sql = " SELECT "//
					+ " 'ِACTIVE' as TITLE1, "//
					+ "(SELECT CAST( COUNT(*) AS UNSIGNED) FROM User left outer join UserNas on User.Id = UserNas.UserId where ProfileId = 4 and IFNULL(Archived,0) = 0 and  Active = 1 " + sqlFilter + " ) as VALUE1, "//
					+ " 'INACTIVE' as TITLE2, "//
					+ "(SELECT CAST( COUNT(*)AS UNSIGNED) FROM User left outer join UserNas on User.Id = UserNas.UserId where ProfileId = 4 and IFNULL(Archived,0) = 0 and  IFNULL(Active,0) = 0 " + sqlFilter + ") as VALUE2 ";//
		} else if (type.equalsIgnoreCase("NewTotal")) {
			sql = " SELECT "//
					+ " 'NEW' as TITLE1, "//
					+ "(SELECT CAST(  COUNT(*) AS UNSIGNED) FROM User left outer join UserNas on User.Id = UserNas.UserId where ProfileId = 4 and IFNULL(Archived,0) = 0 and  YEAR(CreationDate) = YEAR(NOW()) AND MONTH(CreationDate) = MONTH(NOW()) and Active = 1 "
					+ sqlFilter + ") as VALUE1, "//
					+ " 'TOTAL' as TITLE2, "//
					+ "(SELECT CAST(  COUNT(*)AS UNSIGNED)  FROM User left outer join UserNas on User.Id = UserNas.UserId where ProfileId = 4 and IFNULL(Archived,0) = 0 and Active = 1 " + sqlFilter + ") as VALUE2 ";//
		} else if (type.equalsIgnoreCase("Expired")) {
			sql = " SELECT "//
					+ " 'EXPIRED' as TITLE1, "//
					+ "(SELECT CAST( COUNT(*) AS UNSIGNED) FROM User left outer join UserNas on User.Id = UserNas.UserId where ProfileId = 4 and IFNULL(Archived,0) = 0 and  ExpiryAccount < NOW() and Active = 1 " + sqlFilter + " ) as VALUE1, "//
					+ " 'FUP' as TITLE2, "//
					+ "(SELECT CAST( COUNT(*) AS UNSIGNED) FROM User left outer join UserNas on User.Id = UserNas.UserId where ProfileId = 4 and IFNULL(Archived,0) = 0 AND FupMode = 1 and Active = 1 " + sqlFilter + " ) as VALUE2 ";//
		} else if (type.equalsIgnoreCase("Dealers")) {
			//
			if (session.isAdmin()) {
				String sqlDealerFlters = session.getDealers();
				//
				sql = " SELECT "//
						+ " 'DEALERS' as TITLE1, "//
						+ "(SELECT CAST(  COUNT(*) AS UNSIGNED) FROM Dealer left outer join User on User.Id = Dealer.UserId where User.ParentId = 1 ) as VALUE1, "//
						+ " 'TOTAL' as TITLE2, "//
						+ " concat(CAST( (SELECT Sum(if(DealerAccount.Credit IS NULL, 0, DealerAccount.Credit) - if(DealerAccount.Debit IS NULL, 0, DealerAccount.Debit) ) FROM DealerAccount left outer join User on User.Id = DealerAccount.DealerId WHERE DealerAccount.DealerId IN "
						+ sqlDealerFlters + " ) AS CHAR), '$' ) as VALUE2 ";//
			} else {
				//
				sql = " SELECT "//
						+ " 'CREDIT' as TITLE1, "//
						+ "concat( CAST( CAST( (SELECT IFNULL(Credit,0)  FROM Dealer Where UserId = " + (session.isDealer() ? session.getId() : session.getDealerId()) + ")AS UNSIGNED)AS CHAR), '$' ) as VALUE1, "//
						+ " 'COMMISSION' as TITLE2, "//
						+ "concat( CAST(CAST( (SELECT IFNULL(Commision,0)  FROM Dealer Where UserId = " + (session.isDealer() ? session.getId() : session.getDealerId()) + ")AS UNSIGNED)AS CHAR), '$' ) as VALUE2 ";//
			}
		} else if (type.equalsIgnoreCase("Archviedِ")) {
			sql = " SELECT "//
					+ " 'ARCHIVED' as TITLE1, "//
					+ "(SELECT CAST( COUNT(*) AS UNSIGNED) FROM User left outer join UserNas on User.Id = UserNas.UserId where ProfileId = 4 and IFNULL(Archived,0) = 1 " + sqlFilter + ") as VALUE1, "//
					+ (!session.isAdmin() ? //
					(" 'BALANCE' as TITLE2,  "//
							+ " concat( CAST( CAST( (SELECT FLOOR( Sum(if(Credit IS NULL, 0, Credit) - if(Debit IS NULL, 0, Debit) ) ) " //
							+ "FROM DealerAccount WHERE DealerAccount.DealerId =" + (session.isDealer() ? session.getId() : session.getDealerId()) + " ) AS UNSIGNED) AS CHAR), '$' ) as VALUE2 ")
							: //
								//
							" 'DEBIT' as TITLE2, "//
									+ " concat(CAST( CAST( (SELECT FLOOR( case when SUM(ifNULL(Credit, 0)) - SUM(ifNULL(Debit, 0)) < 0 then SUM(ifNULL(Credit, 0)) - SUM(ifNULL(Debit, 0))  else 0 end ) " //
									+ "FROM DealerAccount )AS UNSIGNED)AS CHAR), '$' ) as VALUE2 ");
		} else {
			sql = " SELECT "//
					+ " 'ONLINE' as TITLE1, "//
					+ "(SELECT CAST( COUNT(*) AS UNSIGNED) FROM User left outer join UserNas on User.Id = UserNas.UserId where ProfileId = 4 and IFNULL(Archived,0) = 0 and  Online = 1 and Active = 1 " + sqlFilter + ") as VALUE1, "//
					+ " 'OFFLINE' as TITLE2, "//
					+ "(SELECT CAST( COUNT(*) AS UNSIGNED) FROM User left outer join UserNas on User.Id = UserNas.UserId where ProfileId = 4 and IFNULL(Archived,0) = 0 and  IFNULL(Online, 0) = 0 and Active = 1 " + sqlFilter + " ) as VALUE2 ";//
		}
		//
		// System.out.println(sql);
		return sql;
	}
	
	public DashboardKpiInfo dashboardKPI(Session session, String type) throws Exception {
		DashboardKpiInfo dashboardKpiInfo = new DashboardKpiInfo();
		String sql = sqlByType(session, type);
		RecordSet recordSet = new QueryEngine().executeSql(sql);
		if (recordSet != null && recordSet.size() > 0) {
			Record record = recordSet.get(0);
			dashboardKpiInfo.setTitle1(record.getStringValue("TITLE1"));
			dashboardKpiInfo.setValue1(record.getStringValue("VALUE1"));
			dashboardKpiInfo.setTitle2(record.getStringValue("TITLE2"));
			String value2 = record.getStringValue("VALUE2");
			dashboardKpiInfo.setValue2(value2);
		}
		return dashboardKpiInfo;
	}
	
	public String calculateTime(long seconds) {
		int day = (int) TimeUnit.SECONDS.toDays(seconds);
		long hours = TimeUnit.SECONDS.toHours(seconds);
		long tempSec = seconds - TimeUnit.HOURS.toSeconds(hours);
		long minute = TimeUnit.SECONDS.toMinutes(tempSec);
		if (tempSec > TimeUnit.MINUTES.toSeconds(minute)) {
			tempSec -= TimeUnit.MINUTES.toSeconds(minute);
		} else {
			tempSec = TimeUnit.MINUTES.toSeconds(minute) - tempSec;
		}
		long second = TimeUnit.SECONDS.toSeconds(tempSec);
		return String.valueOf(day) + " Day(s) " + hours + " Hour(s) " + minute + " Minute(s) " + second + " Seconds ";
	}
	
	public DashboardSystemType dashboardSystemTime(Session session) {
		//
		JavaSysMon javaSysMon = new JavaSysMon();
		DashboardSystemType dashboardSystemType = new DashboardSystemType();
		dashboardSystemType.setUpTime(calculateTime(javaSysMon.uptimeInSeconds()));
		//
		SimpleDateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
		// Set the timezone to EET (Eastern European Time)
		dateFormat.setTimeZone(TimeZone.getTimeZone("EET"));
		String formattedDate = dateFormat.format(new Date());
		dashboardSystemType.setServerTime(formattedDate);
		//
		return dashboardSystemType;
	}
	
	public List<DashboardTransactionInfo> dashboardTransactionInfo(Session session) throws Exception {
		String sql = "SELECT dl.OperationDate, u.UserName, d.UserName as DealerName, dl.Type, Credit, Debit " //
				+ " FROM DealerBillingLog dl " //
				+ " left outer join User u on u.id =dl.UserId" //
				+ " left outer join User d on d.id =dl.DealerId" //
				+ (session.isAdmin() ? " WHERE dl.UserId IS NULL and dl.Type in ('CREDIT', 'DEBIT') " : "") //
				+ (!session.isAdmin() ? " WHERE dl.DealerId = " + (session.isDealer() ? session.getId() : session.getDealerId()) : "") //
				+ " Order by dl.Id Desc limit 10 ";
		RecordSet recordSet = new QueryEngine().executeSql(sql);
		List<DashboardTransactionInfo> list = new ArrayList<DashboardTransactionInfo>();
		//
		DecimalFormat df = new DecimalFormat("0.00");
		for (Record record : recordSet) {
			//
			DashboardTransactionInfo dashboardTransactionInfo = new DashboardTransactionInfo();
			list.add(dashboardTransactionInfo);
			dashboardTransactionInfo.setUser(session.isAdmin() ? record.getStringValue("DealerName") : record.getStringValue("UserName"));
			dashboardTransactionInfo.setType(record.getStringValue("Type"));
			//
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date OperationDate = record.getDateValue("OperationDate");
			dashboardTransactionInfo.setDate(dateFormat.format(OperationDate));
			//
			Double credit = record.getDoubleValue("Credit");
			Double debit = record.getDoubleValue("Debit");
			Double amnt = credit != null && credit > 0 ? credit : debit;
			amnt = amnt != null ? amnt : 0.0;
			dashboardTransactionInfo.setAmount(df.format(amnt));
		}
		//
		return list;
	}
	
	public List<DashboardTopDealersInfo> dashboardTopResellerData(Session session) throws Exception {
		String sql = " SELECT * "//
				+ "   FROM (SELECT u.UserName, "//
				+ "                (SELECT COUNT(*) "//
				+ "                   FROM User " + "                   left outer join UserNas on UserNas.UserId = User.Id  "//
				+ "                  WHERE User.ParentId = d.UserId AND User.ProfileId = 4 and Active = 1) "//
				+ "                   AS TOTALUSERS, "//
				+ "                (SELECT COUNT(*) "//
				+ "                   FROM User "//
				+ "                   left outer join UserNas on UserNas.UserId = User.Id  "//
				+ "                  WHERE     User.ParentId = d.UserId "//
				+ "                        AND User.ProfileId = 4 and Active = 1 "//
				+ "                        AND Year(CreationDate) = Year(now()) "//
				+ "                        AND MONTH(CreationDate) = MONTH(now())) "//
				+ "                   AS NEWUSERS "//
				+ "           FROM Dealer d " //
				+ "           LEFT OUTER JOIN User u ON d.UserId = u.Id "//
				+ (!session.isAdmin() ? " WHERE d.UserId IN " + session.getDealers() : "")//
				+ "  ) SUB " //
				+ " ORDER BY NEWUSERS DESC"//
				+ " LIMIT 5 ";// ;
		//
		RecordSet recordSet = new QueryEngine().executeSql(sql);
		List<DashboardTopDealersInfo> list = new ArrayList<DashboardTopDealersInfo>();
		//
		for (Record record : recordSet) {
			DashboardTopDealersInfo dashboardTopDealersInfo = new DashboardTopDealersInfo();
			list.add(dashboardTopDealersInfo);
			dashboardTopDealersInfo.setUser(record.getStringValue("UserName"));
			//
			Integer totalUsers = record.getIntegerValue("TOTALUSERS");
			Integer newUsers = record.getIntegerValue("NEWUSERS");
			//
			String percValue = totalUsers != null && totalUsers > 0 ? newUsers + "/" + totalUsers : "0";
			int perc = totalUsers != null && totalUsers > 0 ? newUsers * 100 / totalUsers : 0;
			//
			dashboardTopDealersInfo.setUser(record.getStringValue("UserName"));
			dashboardTopDealersInfo.setPercValue(percValue);
			dashboardTopDealersInfo.setPerc(perc);
		}
		//
		return list;
	}
	
	@SuppressWarnings("deprecation")
	public List<DashboardTopDealersInfo> dashboardTopUsersData(Session session) throws Exception {
		//
		Integer dealerId = session.isDealer() ? session.getId() : session.getDealerId();
		//
		Date fromDate = new Date();
		fromDate.setHours(0);
		fromDate.setMinutes(0);
		fromDate.setSeconds(0);
		//
		Date toDate = new Date();
		toDate.setHours(23);
		toDate.setMinutes(59);
		toDate.setSeconds(59);
		//
		String format = "MM/dd/yyyy";
		String dbFormat = "'%m/%d/%Y'";
		DateFormat df = new SimpleDateFormat(format);
		String strFromDate = df.format(fromDate);
		String strToDate = df.format(toDate);
		strFromDate = "STR_TO_DATE('" + strFromDate + "',  " + dbFormat + "  )";
		strToDate = "STR_TO_DATE( '" + strToDate + "',  " + dbFormat + "  )";
		//
		String sql = " 	SELECT `User`.`UserName` AS `UserName`, "//
				+ "        (cast( "//
				+ "            SUM( "//
				+ "                 (  UserNasSession.DownloadBytes "//
				+ "                  + UserNasSession.FreeDownloadBytes "//
				+ "                  + UserNasSession.UploadBytes "//
				+ "                  + UserNasSession.FreeUploadBytes) "//
				+ "               / (1024 * 1024)) AS DECIMAL(14, 2))) "//
				+ "           AS `Total` "//
				+ "   FROM `User` "//
				+ "        LEFT OUTER JOIN `UserNas` `UserNas` "//
				+ "           ON `UserNas`.`UserId` = `User`.`Id` "//
				+ "        LEFT OUTER JOIN `UserNasSession` `UserNasSession` "//
				+ "           ON `UserNasSession`.`UserId` = `User`.`Id` "//
				+ "  WHERE     UserNas.Active = 1 "//
				+ "        AND User.ParentId = " + dealerId//
				+ "        AND UserNasSession.StartSession >= " + strFromDate//
				+ "        AND (   UserNasSession.EndSession IS NULL "//
				+ "             OR (UserNasSession.EndSession <= " + strToDate //
				+ "           )) "//
				+ " GROUP BY `User`.`Id` "//
				+ " ORDER BY (cast( "//
				+ "              SUM( "//
				+ "                   (  UserNasSession.DownloadBytes "//
				+ "                    + UserNasSession.FreeDownloadBytes "//
				+ "                    + UserNasSession.UploadBytes "//
				+ "                    + UserNasSession.FreeUploadBytes) "//
				+ "                 / (1024 * 1024)) AS DECIMAL(14, 2))) DESC "//
				+ "  LIMIT 0, 5 "; //
		//
		RecordSet recordSet = new QueryEngine().executeSql(sql);
		List<DashboardTopDealersInfo> list = new ArrayList<DashboardTopDealersInfo>();
		//
		for (Record record : recordSet) {
			DashboardTopDealersInfo dashboardTopDealersInfo = new DashboardTopDealersInfo();
			list.add(dashboardTopDealersInfo);
			dashboardTopDealersInfo.setUser(record.getStringValue("UserName"));
			//
			Integer totalUsers = record.getIntegerValue("Total");
			//
			//
			dashboardTopDealersInfo.setUser(record.getStringValue("UserName"));
			dashboardTopDealersInfo.setPerc(totalUsers);
		}
		//
		// DashboardTopDealersInfo dashboardTopDealersInfo = new
		// DashboardTopDealersInfo();
		// list.add(dashboardTopDealersInfo);
		// dashboardTopDealersInfo.setUser("jchidiac");
		// dashboardTopDealersInfo.setPerc(2120);
		// //
		//
		// list.add(dashboardTopDealersInfo);
		// list.add(dashboardTopDealersInfo);
		// list.add(dashboardTopDealersInfo);
		// list.add(dashboardTopDealersInfo);
		return list;
	}
	
	public List<DashboardAccountsInfo> dashboardAccountsInfo(Session session, Integer dealerId) throws Exception {
		//
		String strToReplace = "";
		String sqlDealer = "SELECT UserName from User where Id = " + dealerId;
		RecordSet dearlRecordSet = new QueryEngine().executeSql(sqlDealer);
		if (dearlRecordSet != null && dearlRecordSet.size() > 0) {
			strToReplace = dearlRecordSet.get(0).getStringValue("UserName") + "-";
		}
		//
		String sql = "select  AccountTypeName, " //
				+ " ( Select count(*) from UserNas left outer join User on User.Id = UserNas.UserId where UserNas.AccountTypeId = AccountType.Id and Active = 1 ) as CNT " //
				+ " from AccountType " //
				+ (dealerId != null && dealerId > 0 ? " where DealerId = " + dealerId + " " : "where DealerId IS NULL ");
		RecordSet recordSet = new QueryEngine().executeSql(sql);
		//
		List<DashboardAccountsInfo> list = new ArrayList<DashboardAccountsInfo>();
		//
		for (Record record : recordSet) {
			DashboardAccountsInfo dashboardAccountsInfo = new DashboardAccountsInfo();
			list.add(dashboardAccountsInfo);
			String name = record.getStringValue("AccountTypeName");
			name = name.replace(strToReplace, "");
			dashboardAccountsInfo.setName(name);
			dashboardAccountsInfo.setCount(record.getIntegerValue("CNT"));
		}
		//
		return list;
	}
	
	public String getDealers(ArrayList<Integer> dealers) {
		String result = "";
		for (Integer userId : dealers) {
			if (!result.isEmpty())
				result = String.valueOf(result) + " , ";
			result = String.valueOf(result) + userId;
		}
		if (!result.isEmpty()) {
			result = "( " + result + " )";
		}
		return result;
	}
	
	public List<DashboardUsersInfo> DashboardUsersInfo(Session session, Integer dealerId, Boolean includeDealers) throws Exception {
		List<DashboardUsersInfo> list = new ArrayList<DashboardUsersInfo>();
		//
		includeDealers = includeDealers != null ? includeDealers : false;
		//
		if (dealerId == null && !session.isAdmin()) {
			if (session.isDealer()) {
				dealerId = session.getId();
			} else {
				dealerId = session.getDealerId();
			}
		}
		String sqlFilter = "";
		String sqlDeletedFilter = "";
		if (!includeDealers) {
			if (dealerId != null && dealerId > 0) {
				sqlFilter += " AND User.ParentId = " + dealerId;
				sqlDeletedFilter = " AND DealerId = " + dealerId;
			}
		} else if (!session.isAdmin()) {
			DealerConfiguration dealerConfiguration = (DealerConfiguration) AppContext.getBean("dealerConfiguration");
			ArrayList<Integer> dealers = dealerConfiguration.getDealers(dealerId);
			String sqlDealerFlters = getDealers(dealers);
			sqlFilter += " AND ( ";
			sqlFilter += " User.ParentId IN " + sqlDealerFlters;
			sqlDeletedFilter = " AND (  DealerId IN " + sqlDealerFlters;
			if (dealerId != null && dealerId > 0) {
				sqlFilter += " OR User.ParentId = " + dealerId;
				sqlDeletedFilter = " OR DealerId = " + dealerId;
			}
			sqlFilter += " ) ";
			sqlDeletedFilter = ")";
		}
		//
		String sql = " SELECT DATE_FORMAT(StartDate, '%b %Y') AS MonthYear  , "//
				+ "(SELECT COUNT(*) FROM User " //
				+ "               left outer join UserNas on User.Id = UserNas.UserId "//
				+ "               where IFNULL(Archived,0) = 0 AND ProfileId = 4 and  YEAR(CreationDate) = YEAR( StartDate ) "//
				+ "               AND MONTH(CreationDate) = MONTH( StartDate ) and Active = 1 " + sqlFilter + " ) as NEWUSERS, "//
				+ "(SELECT COUNT(*) FROM User " //
				+ "               left outer join UserNas on User.Id = UserNas.UserId "//
				+ "               where IFNULL(Archived,0) = 0 AND ProfileId = 4 and ExpiryAccount < NOW() and  YEAR(ExpiryAccount) = YEAR( StartDate ) "//
				+ "               AND MONTH(ExpiryAccount) = MONTH( StartDate ) "//
				+ "               " + sqlFilter + ") as EXPIRED, " //
				+ " ( SELECT Count(UserId)  FROM UserLog  WHERE (OperationTypeId = 3) " //
				+ sqlDeletedFilter //
				+ " AND YEAR(UserLog.Logdate) = YEAR( StartDate ) AND MONTH(UserLog.Logdate) = MONTH( StartDate ) " //
				+ " )  as DELETED " //
				+ " FROM TempDates " //
				+ " where date(StartDate) between DATE_SUB(NOW(), INTERVAL 10 MONTH) and date ( NOW()) " + " order by StartDate asc";//
		RecordSet recordSet = new QueryEngine().executeSql(sql);
		//
		for (Record record : recordSet) {
			DashboardUsersInfo dashboardUsersInfo = new DashboardUsersInfo();
			list.add(dashboardUsersInfo);
			dashboardUsersInfo.setDate(record.getStringValue("MonthYear"));
			dashboardUsersInfo.setNewUsers(record.getIntegerValue("NEWUSERS"));
			dashboardUsersInfo.setExpiredUsers(record.getIntegerValue("EXPIRED"));
			dashboardUsersInfo.setDeletedUsers(record.getIntegerValue("DELETED"));
		}
		//
		return list;
	}
	
	public List<DashboardAccountsInfo> dashboardMemory(Session session) {
		JavaSysMon javaSysMon = new JavaSysMon();
		List<DashboardAccountsInfo> list = new ArrayList<DashboardAccountsInfo>();
		DashboardAccountsInfo dashboardAccountsInfo = new DashboardAccountsInfo();
		list.add(dashboardAccountsInfo);
		//
		Integer totalMemory = Float.valueOf((float) (javaSysMon.physical().getTotalBytes() / 1048576L)).intValue();
		Integer freeMemory = Float.valueOf((float) (javaSysMon.physical().getFreeBytes() / 1048576L)).intValue();
		Integer usedMemory = totalMemory - freeMemory;
		//
		dashboardAccountsInfo.setName("Used Memory");
		dashboardAccountsInfo.setCount(usedMemory);
		//
		DashboardAccountsInfo dashboardAccountsInfo1 = new DashboardAccountsInfo();
		list.add(dashboardAccountsInfo1);
		dashboardAccountsInfo1.setName("Free Memory");
		dashboardAccountsInfo1.setCount(freeMemory);
		//
		return list;
	}
	
	public List<DashboardAccountsInfo> dashboardSwap(Session session) {
		// JavaSysMon javaSysMon = new JavaSysMon();
		List<DashboardAccountsInfo> list = new ArrayList<DashboardAccountsInfo>();
		//
		// DashboardAccountsInfo dashboardAccountsInfo = new
		// DashboardAccountsInfo();
		// list.add(dashboardAccountsInfo);
		// //
		// Integer totalMemory = Float.valueOf((float)
		// (javaSysMon.physical().getTotalBytes() / 1048576L)).intValue();
		// dashboardAccountsInfo.setName("Total Memory GB");
		// dashboardAccountsInfo.setCount(totalMemory);
		//
		File root = new File("/");
		long totalSpace = root.getTotalSpace() / (1024 * 1024 * 1024);
		long freeSpace = root.getFreeSpace() / (1024 * 1024 * 1024); //
		long usedSpace = totalSpace - freeSpace; //
		//
		DashboardAccountsInfo totalDashboardAccountsInfo2 = new DashboardAccountsInfo();
		list.add(totalDashboardAccountsInfo2);
		totalDashboardAccountsInfo2.setName("Usable Space GB");
		totalDashboardAccountsInfo2.setCount(new Integer((int) usedSpace));
		DashboardAccountsInfo dashboardAccountsInfo2 = new DashboardAccountsInfo();
		list.add(dashboardAccountsInfo2);
		dashboardAccountsInfo2.setName("Free Space GB");
		dashboardAccountsInfo2.setCount(new Integer((int) freeSpace));
		//
		//
		return list;
	}
	
	public List<DashboardAccountsInfo> dashboardCpu(Session session) {
		JavaSysMon javaSysMon = new JavaSysMon();
		List<DashboardAccountsInfo> list = new ArrayList<DashboardAccountsInfo>();
		//
		DashboardAccountsInfo dashboardAccountsInfo = new DashboardAccountsInfo();
		list.add(dashboardAccountsInfo);
		//
		dashboardAccountsInfo.setName("CPU %");
		// Retrieve the total CPU usage
		// Take an initial CPU sample
		CpuTimes initialTimes = javaSysMon.cpuTimes();
		// Wait for 1 second to measure the difference
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
		}
		// Take a second CPU sample
		CpuTimes finalTimes = javaSysMon.cpuTimes();
		// Calculate CPU usage percentage
		Double cpuUsage = (double) finalTimes.getCpuUsage(initialTimes) * 100;
		//
		dashboardAccountsInfo.setCount(cpuUsage.intValue());
		//
		//
		//
		return list;
	}
}