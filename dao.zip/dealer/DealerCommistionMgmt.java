package me.iradius.server.dao.dealer;

import me.iradius.server.ctxt.AppContext;
import me.iradius.server.dealer.DealerConfiguration;



public class DealerCommistionMgmt
{
  public void commissionMgmt(Integer modifiedUserId, Integer accountTypeId, Double accountRate, Double commision, Double refundCredit, String type, String description) throws Exception {
    DealerConfiguration dealerConfiguration = (DealerConfiguration)AppContext.getBean("dealerConfiguration");
    
    Float refundCommissionPercentage = new Float(refundCredit.doubleValue() / accountRate.doubleValue());
    dealerConfiguration.updateDealerCommisionBasedOnaccount(modifiedUserId, null, accountTypeId, refundCommissionPercentage, null, type, description, Boolean.valueOf(true));
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\dealer\DealerCommistionMgmt.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */