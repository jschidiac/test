package me.iradius.server.dao.dealer;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import me.iradius.server.ctxt.AppContext;
import me.iradius.server.dealer.DealerConfiguration;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;
import me.iradius.shared.session.NotificationInfo;
import me.iradius.shared.session.Session;

public class NotificationDao {
	
	public String getDealers(ArrayList<Integer> dealers) {
		String result = "";
		for (Integer userId : dealers) {
			if (!result.isEmpty())
				result = String.valueOf(result) + " , ";
			result = String.valueOf(result) + userId;
		}
		if (!result.isEmpty()) {
			result = "( " + result + " )";
		}
		return result;
	}
	
	public NotificationInfo getNotification(Session session, Integer userId) throws Exception {
		String fupSelect = " SELECT count(UserId)  FROM UserNas  LEFT OUTER JOIN User ON User.Id = UserNas.UserId  Where FupMode = 1  and  Online = 1 ";
		String dealersId = "";
		DealerConfiguration dealerConfiguration = (DealerConfiguration) AppContext.getBean("dealerConfiguration");
		if (userId != null) {
			ArrayList<Integer> dealers = dealerConfiguration.getDealers(userId);
			dealersId = getDealers(dealers);
		} else {
			ArrayList<Integer> dealers = dealerConfiguration.getDealers(session.getId());
			dealersId = getDealers(dealers);
		}
		String sqlAll = " ( select count(UserId) from UserNas  LEFT Outer join User On User.Id = UserNas.UserId  Where User.ParentId IN " + dealersId + "  and ( User.Archived  IS NULL OR User.Archived = 0) ) as \"ALL\" ";
		String sqlOnline = " ( select count(UserId) from UserNas LEFT Outer join User On User.Id = UserNas.UserId  Where Online = 1  and User.ParentId IN " + dealersId + " and ( User.Archived  IS NULL OR User.Archived = 0)) as \"ONLINE\"  ";
		String sqlActive = " ( select count(UserId) from UserNas LEFT Outer join User On User.Id = UserNas.UserId  Where Active = 1  and User.ParentId IN " + dealersId + " and ( User.Archived  IS NULL OR User.Archived = 0)) as \"ACTIVE\"  ";
		String sqlExpired = "( select count(UserId) from UserNas LEFT Outer join User On User.Id = UserNas.UserId  WHERE (User.Archived IS NULL OR User.Archived = 0) and UserNas.Active = 1 AND  (now() >  UserNas.ExpiryAccount) and User.ParentId IN "
				+ dealersId + " )  as \"EXPIRED\" ";
		String sqlArchived = "( select count(UserId) from UserNas LEFT Outer join User On User.Id = UserNas.UserId  WHERE (User.Archived = 1) and User.ParentId IN " + dealersId + " )  as \"ARCHIVED\" ";
		fupSelect = String.valueOf(fupSelect) + "  and User.ParentId IN " + dealersId;
		fupSelect = " (  " + fupSelect + " ) as \"FUP\"  ";
		String sql = "Select " + sqlAll + " , " + sqlOnline + "  , " + sqlActive + "  ," + sqlExpired + "  ," + sqlArchived + "  ," + fupSelect;
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet.size() > 0) {
			Record record = (Record) recordSet.get(0);
			NotificationInfo notificationInfo = new NotificationInfo();
			notificationInfo.setAllUsers(record.getIntegerValue("ALL"));
			notificationInfo.setOnlineUsers(record.getIntegerValue("ONLINE"));
			notificationInfo.setActiveUsers(record.getIntegerValue("ACTIVE"));
			notificationInfo.setExpiredUsers(record.getIntegerValue("EXPIRED"));
			notificationInfo.setFupUsers(record.getIntegerValue("FUP"));
			notificationInfo.setArchivedUsers(record.getIntegerValue("ARCHIVED"));
			return notificationInfo;
		}
		return null;
	}
	
	public Double getQuota(Integer userId, Date disConnectTime, Date connectTime, String tableName) throws Exception {
		Calendar rightNow = Calendar.getInstance();
		rightNow.setTime(connectTime);
		Integer fromHour = Integer.valueOf(rightNow.get(10));
		rightNow.setTime(disConnectTime);
		Integer toHour = Integer.valueOf(rightNow.get(10));
		String format = "MM/dd/yyyy";
		String dbFormat = "'%m/%d/%Y'";
		DateFormat df = new SimpleDateFormat(format);
		String strFromDate = df.format(connectTime);
		String strToDate = df.format(disConnectTime);
		String fieldFormat = "STR_TO_DATE( DATE_FORMAT(OperationDate, " + dbFormat + ") ,  " + dbFormat + "  )";
		strFromDate = "STR_TO_DATE('" + strFromDate + "',  " + dbFormat + "  )";
		strToDate = "STR_TO_DATE( '" + strToDate + "',  " + dbFormat + "  )";
		String filter = "";
		if (connectTime.getDate() == disConnectTime.getDate()) {
			filter = "(" + fieldFormat + "  =  " + strFromDate + ")  AND  (OperationHour >= " + fromHour + ") AND  (OperationHour <= " + toHour + ") ";
		} else {
			filter = "  ( ((" + fieldFormat + "  =  " + strFromDate + ")  AND  (OperationHour >= " + fromHour + ") ) OR (" + fieldFormat + "  >  " + strFromDate + ") ) ";
			filter = String.valueOf(filter) + "  AND ( ((" + fieldFormat + "  =  " + strToDate + ")  AND  (OperationHour <= " + toHour + ") ) OR (" + fieldFormat + "  <  " + strToDate + ") ) ";
		}
		String sql = "SELECT cast((  COALESCE(sum(DownloadBytes), 0) + COALESCE(sum(UploadBytes), 0)) / (1024 * 1024) AS DECIMAL(14, 2)) as QUOTA FROM " + tableName + " WHERE UserId = " + userId + " AND ( " + filter + " )";
		RecordSet recordSet = (new QueryEngine()).executeSql(sql);
		if (recordSet.size() > 0) {
			Double quota = ((Record) recordSet.get(0)).getDoubleValue("QUOTA");
			return quota;
		}
		return null;
	}
	
	public String calculateQuota(Integer userId, Date disConnectTime, Date connectTime) throws Exception {
		Double quota = getQuota(userId, disConnectTime, connectTime, "UserNasSessionDetails");
		Date now = new Date();
		if (now.getMonth() > connectTime.getMonth()) {
			String tableName = "UserNasSessionDetails_" + (connectTime.getYear() + 1900) + "_" + connectTime.getMonth();
			try {
				Double prevQuota = getQuota(userId, disConnectTime, connectTime, tableName);
				quota = Double.valueOf(quota.doubleValue() + prevQuota.doubleValue());
			} catch (Exception exception) {
			}
		}
		NumberFormat formatter = new DecimalFormat("#,##0.0#");
		return String.valueOf((quota != null) ? formatter.format(quota) : "") + " MB";
	}
}
