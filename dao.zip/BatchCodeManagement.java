package me.iradius.server.dao;

import java.util.ArrayList;
import me.iradius.server.ctxt.SessionUtil;
import me.iradius.server.divers.ServerUtils;
import me.iradius.server.engine.QueryEngine;
import me.iradius.shared.db.DbUtils;
import me.iradius.shared.db.Table;
import me.iradius.shared.record.Record;
import me.iradius.shared.record.RecordSet;


public class BatchCodeManagement
  extends AbstractDaoMgmt
{
  private Integer accountTypeId;
  private Integer codeCount;
  private Integer dealerId;
  private Float accountTypeRate;
  private Double dealerCredit;
  private Double newCredit;
  private Boolean noCharge = Boolean.valueOf(false);
  private Integer LastCodeNbr = Integer.valueOf(0);
  
  public BatchCodeManagement(Table updateTableDef) {
    super(updateTableDef);
  }

  
  public void executeBeforeUpdate() throws Exception {
    this.accountTypeId = (Integer)this.updateTableDef.getFieldValues().get("AccountTypeId");
    this.codeCount = Integer.valueOf(Integer.parseInt((String)this.updateTableDef.getFieldValues().get("CodeCount")));
    this.dealerId = SessionUtil.getSession().getId();
    
    String sql = "SELECT AccountType.Rate, Dealer.Credit, Dealer.NoCharge FROM AccountType     LEFT OUTER JOIN Dealer ON AccountType.DealerId = Dealer.UserId WHERE Dealer.UserId = " + 

      
      this.dealerId + " and AccountType.Id =   " + this.accountTypeId;
    RecordSet recordSet = (new QueryEngine()).executeSql(sql);
    if (recordSet.size() > 0) {
      Record record = (Record)recordSet.get(0);
      
      if (record.getBooleanValue("NoCharge") != null) {
        this.noCharge = record.getBooleanValue("NoCharge");
      }
      this.accountTypeRate = record.getFloatValue("Rate");
      this.dealerCredit = record.getDoubleValue("Credit");
      
      this.accountTypeRate = Float.valueOf((this.accountTypeRate == null) ? 0.0F : this.accountTypeRate.floatValue());
      this.dealerCredit = Double.valueOf((this.dealerCredit == null) ? 0.0D : this.dealerCredit.doubleValue());
      
      if (!this.noCharge.booleanValue() && (this.codeCount.intValue() * this.accountTypeRate.floatValue()) > this.dealerCredit.doubleValue()) {
        throw new Exception("Not ennough Credit for this operation.");
      }

      
      String prefixCode = (String)this.updateTableDef.getFieldValues().get("PrefixCode");
      sql = "Select LastNumber From CodeRef Where Code = " + DbUtils.dblQuotedField(prefixCode);
      recordSet = (new QueryEngine()).executeSql(sql);
      if (recordSet.size() > 0) {
        record = (Record)recordSet.get(0);
        Integer lastNumberInteger = record.getIntegerValue("LastNumber");
        this.LastCodeNbr = Integer.valueOf(lastNumberInteger.intValue() + 1);
      } 
    } else {
      throw new Exception("Information not found.");
    } 
  }


  
  public void executeAfterUpdate(Integer modifiedUserId, Table updateTableDef, Integer pkFieldValue) throws Exception {
    this.newCredit = Double.valueOf(this.dealerCredit.doubleValue() - (this.codeCount.intValue() * this.accountTypeRate.floatValue()));
    if (!this.noCharge.booleanValue()) {
      String type = (this.dealerCredit.doubleValue() < this.newCredit.doubleValue()) ? "CREDIT" : "DEBIT";
      (new DealerManagement(null)).removeCreditBasedOnrechargeAccount(modifiedUserId, this.dealerId, null, Float.valueOf(this.codeCount.intValue() * this.accountTypeRate.floatValue()), null, type, "Generate Batch Codes.");
    } 
    
    generateCodes(pkFieldValue);
  }
  
  public String generateRefGuid(ArrayList<String> refGuids) {
    String refGuid = ServerUtils.generateRefGuid();
    refGuid = refGuid.toUpperCase();
    if (refGuids.contains(refGuid)) {
      return generateRefGuid(refGuids);
    }
    return refGuid;
  }
  
  private void generateCodes(Integer pkFieldValue) throws Exception {
    if (this.codeCount.intValue() > 0) {
      try {
        String sql = "";
        String prefixCode = (String)this.updateTableDef.getFieldValues().get("PrefixCode");
        
        ArrayList<String> refGuids = new ArrayList<>();
        
        for (int i = 0; i < this.codeCount.intValue(); i++) {
          String refId = String.valueOf(prefixCode) + this.LastCodeNbr;
          
          String refGuid = generateRefGuid(refGuids);
          refGuids.add(refGuid);
          sql = "INSERT INTO  Codes (RefId, RefGuid, \tAccountTypeId, BatchCodeId) VALUES( " + 
            DbUtils.dblQuotedField(refId) + "," + 
            DbUtils.dblQuotedField(refGuid) + "," + 
            this.accountTypeId + "," + 
            pkFieldValue + " ) ";
          (new QueryEngine()).updateData(sql);
          this.LastCodeNbr = Integer.valueOf(this.LastCodeNbr.intValue() + 1);
        } 

        
        this.LastCodeNbr = Integer.valueOf(this.LastCodeNbr.intValue() - 1);
        sql = "INSERT INTO  CodeRef (Code, LastNumber) VALUES( " + DbUtils.dblQuotedField(prefixCode) + "," + this.LastCodeNbr + " ) ";
        (new QueryEngine()).updateData(sql);
      
      }
      catch (Exception e) {
        throw new Exception(e.getMessage());
      } 
    }
  }


  
  public void deleteBatchCodes(Integer batchCodeId) throws Exception {
    String sql = "DELETE FROM Codes WHERE BatchCodeId = " + batchCodeId;
    (new QueryEngine()).updateData(sql);

    
    sql = "DELETE FROM BatchCodes WHERE Id = " + batchCodeId;
    (new QueryEngine()).updateData(sql);
  }
  
  public void assignCodesToPointOfSales(String prefixCode, Integer fromNbr, Integer toNbr, Integer poinOfSale) throws Exception {
    for (int i = fromNbr.intValue(); i <= toNbr.intValue(); i++) {
      String code = String.valueOf(prefixCode) + i;
      
      String sql = "UPDATE Codes SET PointOfSaleId = " + poinOfSale + " WHERE RefId =  " + DbUtils.dblQuotedField(code);
      (new QueryEngine()).updateData(sql);
    } 
  }
}


/* Location:              C:\NewDev\decompile\johnny\latestonserver\classes\!\me\iradius\server\dao\BatchCodeManagement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */