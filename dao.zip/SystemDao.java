package me.iradius.server.dao;

import com.jezhumble.javasysmon.JavaSysMon;
import java.util.concurrent.TimeUnit;
import me.iradius.shared.system.SystemInfo;

public class SystemDao {
	
	public String calculateTime(long seconds) {
		int day = (int) TimeUnit.SECONDS.toDays(seconds);
		long hours = TimeUnit.SECONDS.toHours(seconds);
		long tempSec = seconds - TimeUnit.HOURS.toSeconds(hours);
		long minute = TimeUnit.SECONDS.toMinutes(tempSec);
		if (tempSec > TimeUnit.MINUTES.toSeconds(minute)) {
			tempSec -= TimeUnit.MINUTES.toSeconds(minute);
		} else {
			tempSec = TimeUnit.MINUTES.toSeconds(minute) - tempSec;
		}
		long second = TimeUnit.SECONDS.toSeconds(tempSec);
		return String.valueOf(day) + " Day(s) " + hours + " Hour(s) " + minute + " Minute(s) " + second + " Seconds ";
	}
	
	public SystemInfo getSystemInfo() {
		JavaSysMon javaSysMon = new JavaSysMon();
		SystemInfo systemInfo = new SystemInfo();
		systemInfo.setOsName(javaSysMon.osName());
		systemInfo.setNumCPU(Integer.valueOf(javaSysMon.numCpus()));
		systemInfo.setTotalMemory(Float.valueOf((float) (javaSysMon.physical().getTotalBytes() / 1048576L)));
		systemInfo.setFreeMemory(Float.valueOf((float) (javaSysMon.physical().getFreeBytes() / 1048576L)));
		systemInfo.setTotalSwap(Float.valueOf((float) (javaSysMon.swap().getTotalBytes() / 1048576L)));
		systemInfo.setcCPUFrequency(Long.valueOf(javaSysMon.cpuFrequencyInHz()));
		systemInfo.setUpTime(calculateTime(javaSysMon.uptimeInSeconds()));
		return systemInfo;
	}
}
